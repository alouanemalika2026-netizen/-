import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/teacher/grades")({
  component: () => (
    <DataTablePage
      title="النقاط"
      description="نقاط طلابي"
      addLabel="تسجيل نقطة"
      collection="grades"
      columns={[
  { key: "student", label: "الطالب" },
  { key: "subject", label: "المادة" },
  { key: "grade", label: "النقطة" },
  { key: "max", label: "من" },
  { key: "comment", label: "الملاحظة" },
]}
      filters={[]}
    />
  ),
});
