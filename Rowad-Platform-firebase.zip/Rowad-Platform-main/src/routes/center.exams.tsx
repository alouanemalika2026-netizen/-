import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/exams")({
  component: () => (
    <DataTablePage
      title="الامتحانات"
      description="قائمة الامتحانات"
      addLabel="امتحان جديد"
      collection="exams"
      columns={[
  { key: "title", label: "الامتحان" },
  { key: "subject", label: "المادة" },
  { key: "date", label: "التاريخ" },
  { key: "duration", label: "المدة" },
  { key: "status", label: "الحالة", render: (r) => <StatusBadge value={r.status} /> },
]}
      filters={[{ key: "status", label: "الحالة", options: ["قادم","منجز"] }]}
    />
  ),
});
