import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Link } from "@tanstack/react-router";
import { toast } from "sonner";

const kids = [
  { name: "يوسف الأمين", level: "3 ثانوي — علوم", avg: 16.4, attendance: 96, teacher: "أ. أحمد بن علي", school: "مؤسسة النور" },
  { name: "لينة الأمين", level: "2 متوسط", avg: 15.2, attendance: 92, teacher: "أ. سارة قاسمي", school: "مؤسسة النور" },
];

export const Route = createFileRoute("/parent/children")({
  component: () => (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">قائمة الأبناء</h1>
          <p className="mt-1 text-sm text-muted-foreground">تابع أداء أبنائك في مكان واحد.</p>
        </div>
        <Button className="bg-brand-gradient text-white" onClick={() => toast.success("طلب إضافة تم إرساله للمؤسسة")}>+ ربط ابن جديد</Button>
      </div>
      <div className="grid gap-5 md:grid-cols-2">
        {kids.map((k) => (
          <Card key={k.name} className="overflow-hidden">
            <div className="bg-[#002855] p-5 text-white">
              <div className="flex items-center gap-3">
                <Avatar className="h-14 w-14 border-2 border-white/40">
                  <AvatarFallback className="bg-white/20 text-xl font-black text-white">{k.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <div className="text-lg font-bold">{k.name}</div>
                  <div className="text-sm text-white/85">{k.level}</div>
                </div>
              </div>
            </div>
            <CardContent className="space-y-3 p-5">
              <div className="grid grid-cols-2 gap-3 text-sm">
                <div><div className="text-xs text-muted-foreground">المؤسسة</div><div className="font-semibold">{k.school}</div></div>
                <div><div className="text-xs text-muted-foreground">الأستاذ الرئيسي</div><div className="font-semibold">{k.teacher}</div></div>
              </div>
              <div>
                <div className="flex justify-between text-sm"><span>المعدل</span><span className="font-bold">{k.avg}/20</span></div>
                <Progress value={(k.avg / 20) * 100} className="mt-1 h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm"><span>الحضور</span><span className="font-bold">{k.attendance}%</span></div>
                <Progress value={k.attendance} className="mt-1 h-2" />
              </div>
              <div className="flex flex-wrap gap-1">
                <Badge variant="outline" className="bg-emerald-50 text-emerald-700">منتظم</Badge>
                <Badge variant="outline" className="bg-brand-orange/10 text-brand-orange">أداء جيد</Badge>
              </div>
              <div className="flex gap-2 pt-2">
                <Link to="/parent/grades" className="flex-1"><Button variant="outline" className="w-full">النقاط</Button></Link>
                <Link to="/parent/attendance" className="flex-1"><Button variant="outline" className="w-full">الحضور</Button></Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  ),
});
