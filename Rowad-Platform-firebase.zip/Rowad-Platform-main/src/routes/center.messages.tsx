import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/messages")({
  component: () => (
    <DataTablePage
      title="الرسائل"
      description="مراقبة المراسلات بين الأساتذة وأولياء الأمور"
      collection="messages"
      hideActions
      columns={[
        { key: "fromName", label: "المرسل" },
        { key: "toName", label: "المستلم" },
        { key: "text", label: "الرسالة" },
      ]}
    />
  ),
});
