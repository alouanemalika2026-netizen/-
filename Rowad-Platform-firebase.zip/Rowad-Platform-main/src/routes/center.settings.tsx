import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import logoAsset from "@/assets/rowad-logo.asset.json";

function SettingsPage({ title }: { title: string }) {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">قم بتخصيص إعدادات الحساب والنظام.</p>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>معلومات عامة</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={(e) => { e.preventDefault(); toast.success("تم حفظ الإعدادات"); }} className="grid gap-4">
              <div className="flex items-center gap-4">
                <img src={logoAsset.logo.url} alt="logo" className="h-16 w-16 rounded-xl object-contain bg-muted p-1" />
                <Button type="button" variant="outline" onClick={() => toast.info("تحميل شعار جديد")}>تغيير الشعار</Button>
              </div>
              <div className="grid gap-2 sm:grid-cols-2">
                <div className="grid gap-2"><Label>اسم المؤسسة</Label><Input defaultValue="مؤسسة النور التعليمية" /></div>
                <div className="grid gap-2"><Label>البريد</Label><Input defaultValue="contact@rowad.com" /></div>
                <div className="grid gap-2"><Label>الهاتف</Label><Input defaultValue="+213 555 00 00 00" /></div>
                <div className="grid gap-2"><Label>المدينة</Label><Input defaultValue="الجزائر العاصمة" /></div>
              </div>
              <div className="grid gap-2"><Label>وصف المؤسسة</Label><Textarea rows={3} defaultValue="مؤسسة تعليمية رائدة تقدم دروساً متميزة." /></div>
              <Button type="submit" className="bg-brand-gradient text-white w-fit">حفظ التغييرات</Button>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader><CardTitle>التفضيلات</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {[
              { label: "إشعارات البريد الإلكتروني", def: true },
              { label: "إشعارات SMS", def: true },
              { label: "الإشعارات اللحظية", def: false },
              { label: "تقارير أسبوعية", def: true },
              { label: "الوضع الليلي", def: false },
            ].map((s) => (
              <div key={s.label} className="flex items-center justify-between rounded-lg border p-3">
                <span className="text-sm font-medium">{s.label}</span>
                <Switch defaultChecked={s.def} onCheckedChange={() => toast.success("تم التحديث")} />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export const Route = createFileRoute("/center/settings")({
  component: () => <SettingsPage title="الإعدادات" />,
});
