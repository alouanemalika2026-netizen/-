import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/classes")({
  component: () => (
    <DataTablePage
      title="الأقسام"
      description="الأقسام والقاعات"
      addLabel="إضافة قسم"
      collection="classes"
      columns={[
  { key: "name", label: "القسم" },
  { key: "teacher", label: "الأستاذ" },
  { key: "students", label: "عدد الطلاب" },
  { key: "room", label: "القاعة" },
]}
      filters={[]}
    />
  ),
});
