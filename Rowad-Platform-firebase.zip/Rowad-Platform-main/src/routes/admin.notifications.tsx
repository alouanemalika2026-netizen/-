import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/admin/notifications")({
  component: () => (
    <DataTablePage
      title="الإشعارات"
      description="إدارة إشعارات النظام"
      addLabel="إشعار جديد"
      collection="notifications"
      columns={[
  { key: "title", label: "الإشعار" },
  { key: "time", label: "الوقت" },
  { key: "read", label: "الحالة", render: (r) => <StatusBadge value={r.read ? "منجز" : "قادم"} /> },
]}
      filters={[]}
    />
  ),
});
