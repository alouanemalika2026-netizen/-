import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Upload, FileText, X } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/teacher/upload-exercises")({
  component: UploadExercises,
});

function UploadExercises() {
  const [files, setFiles] = useState([
    { name: "سلسلة تمارين — الفصل 2.pdf", size: "1.8 MB" },
    { name: "تمارين مراجعة.pdf", size: "2.3 MB" },
  ]);
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold">رفع التمارين</h1>
        <p className="mt-1 text-sm text-muted-foreground">أضف تمارين لطلابك مع إمكانية جدولة تاريخ التسليم.</p>
      </div>
      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardContent className="p-6">
            <form onSubmit={(e) => { e.preventDefault(); setFiles((f) => [{ name: `تمرين جديد ${f.length + 1}.pdf`, size: "1.5 MB" }, ...f]); toast.success("تم رفع التمارين"); }} className="grid gap-4">
              <div className="grid gap-2"><Label>عنوان التمرين</Label><Input required placeholder="مثلاً: تمارين المعادلات" /></div>
              <div className="grid gap-2 sm:grid-cols-2">
                <div className="grid gap-2"><Label>القسم</Label><Input defaultValue="3 ثانوي أ" /></div>
                <div className="grid gap-2"><Label>تاريخ التسليم</Label><Input type="date" /></div>
              </div>
              <div className="grid gap-2"><Label>التعليمات</Label><Textarea rows={3} placeholder="تعليمات للطلاب..." /></div>
              <div className="rounded-xl border-2 border-dashed p-6 text-center">
                <Upload className="mx-auto h-6 w-6 text-brand-purple" />
                <div className="mt-2 font-semibold">اسحب ملف التمارين هنا</div>
              </div>
              <Button type="submit" className="bg-brand-gradient text-white">إرسال إلى الطلاب</Button>
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <h3 className="mb-3 font-bold">التمارين الأخيرة</h3>
            <ul className="space-y-2">
              {files.map((f, i) => (
                <li key={i} className="flex items-center gap-2 rounded-lg border p-2 text-sm">
                  <FileText className="h-4 w-4 text-brand-pink" />
                  <div className="min-w-0 flex-1 truncate">{f.name}</div>
                  <Button size="icon" variant="ghost" onClick={() => setFiles((x) => x.filter((_, j) => j !== i))}><X className="h-3.5 w-3.5" /></Button>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
