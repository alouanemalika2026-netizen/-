import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/parent/attendance")({
  component: () => (
    <DataTablePage
      title="الحضور"
      description="سجل حضور وغياب أبنائك"
      collection="attendance"
      mine="parentEmail"
      hideActions
      columns={[
        { key: "name", label: "الطالب" },
        { key: "class", label: "القسم" },
        { key: "date", label: "التاريخ" },
        { key: "status", label: "الحالة", render: (r) => <StatusBadge value={r.status} /> },
      ]}
      filters={[{ key: "status", label: "الحالة", options: ["حاضر", "متأخر", "غائب"] }]}
    />
  ),
});
