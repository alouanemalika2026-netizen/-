import { createFileRoute, Link, useRouter } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import {
  School,
  Building2,
  GraduationCap,
  UserCheck,
  CheckCircle2,
  Lock,
  Mail,
  ArrowRight,
  ArrowLeft,
  ShieldCheck,
} from "lucide-react";
import logoAsset from "@/assets/rowad-logo.asset.json";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { login, resetPassword, authErrorMessage, useAuth, ROLE_HOME } from "@/lib/auth";

export const Route = createFileRoute("/login")({
  component: LoginPage,
});

function LoginPage() {
  const router = useRouter();
  const { ready, user: current } = useAuth();
  useEffect(() => {
    if (ready && current) router.navigate({ to: ROLE_HOME[current.role] });
  }, [ready, current, router]);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [selectedRoleIndex, setSelectedRoleIndex] = useState<number | null>(null);

  // 5 Distinct Role Options with unique colors & metadata
  const roles = [
    {
      id: "superadmin",
      role: "المدير العام",
      title: "لوحة الإدارة المركزية",
      desc: "إشراف شامل على كافة العمليات والفروع والتقارير",
      email: "superadmin@rowad.com",
      pass: "admin123",
      icon: School,
      themeColor: "#C88A2C", // Warm Gold
      activeBg: "bg-[#C88A2C]/10",
      activeBorder: "border-[#C88A2C]",
      activeText: "text-[#C88A2C]",
    },
    {
      id: "center",
      role: "المركز التعليمي",
      title: "إدارة المركز والأفواج",
      desc: "تنظيم الجداول، توزيع القاعات والاشتراكات",
      email: "center@rowad.com",
      pass: "center123",
      icon: Building2,
      themeColor: "#002855", // Deep Navy
      activeBg: "bg-[#002855]/10 dark:bg-white/10",
      activeBorder: "border-[#002855] dark:border-white",
      activeText: "text-[#002855] dark:text-white",
    },
    {
      id: "teacher",
      role: "المدرس والأستاذ",
      title: "فضاء التدريس والحصص",
      desc: "تسجيل الحضور السريع، نشر التمارين ورصد النقاط",
      email: "teacher@rowad.com",
      pass: "teacher123",
      icon: CheckCircle2,
      themeColor: "#0284c7", // Sky/Blue
      activeBg: "bg-sky-500/10",
      activeBorder: "border-sky-600",
      activeText: "text-sky-600 dark:text-sky-400",
    },
    {
      id: "student",
      role: "الطالب",
      title: "بوابة التعلم والواجبات",
      desc: "متابعة الحصص، المقررات، الفروض وتطور المعدل",
      email: "student@rowad.com",
      pass: "student123",
      icon: GraduationCap,
      themeColor: "#059669", // Emerald
      activeBg: "bg-emerald-500/10",
      activeBorder: "border-emerald-600",
      activeText: "text-emerald-600 dark:text-emerald-400",
    },
    {
      id: "parent",
      role: "ولي الأمر",
      title: "المتابعة الأسرية الفورية",
      desc: "إشعارات الوصول الفورية وكشوفات النقاط الدورية",
      email: "parent@rowad.com",
      pass: "parent123",
      icon: UserCheck,
      themeColor: "#d97706", // Amber
      activeBg: "bg-amber-500/10",
      activeBorder: "border-amber-600",
      activeText: "text-amber-600 dark:text-amber-400",
    },
  ];

  const handleRoleSelect = (index: number) => {
    setSelectedRoleIndex(index);
    const selected = roles[index];
    setEmail(selected.email);
    setPassword(selected.pass);
    toast.info(`تم تفعيل حساب ${selected.role}`);
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    try {
      const user = await login(email, password);
      toast.success(`مرحباً بك، ${user.name}`);
      router.navigate({ to: ROLE_HOME[user.role] });
    } catch (err) {
      toast.error(authErrorMessage(err));
    } finally {
      setLoading(false);
    }
  };

  const handleForgot = async () => {
    if (!email.trim()) {
      toast.info("اكتب بريدك الإلكتروني أولاً ثم اضغط «نسيت كلمة المرور»");
      return;
    }
    try {
      await resetPassword(email);
      toast.success("تم إرسال رابط إعادة تعيين كلمة المرور إلى بريدك");
    } catch (err) {
      toast.error(authErrorMessage(err));
    }
  };

  const activeRole = selectedRoleIndex !== null ? roles[selectedRoleIndex] : null;

  return (
    <div className="min-h-screen bg-white dark:bg-[#001428] text-right flex flex-col justify-between py-8 px-4 sm:px-6">
      
      {/* Top Navigation Bar: Simple Return Button */}
      <div className="container max-w-2xl mx-auto flex items-center justify-between pb-4">
        <Link
          to="/"
          className="inline-flex items-center gap-2 text-xs font-bold text-[#002855] dark:text-[#C88A2C] hover:underline transition-colors"
        >
          <ArrowRight className="h-4 w-4" />
          <span>العودة إلى الصفحة الرئيسية</span>
        </Link>
        <span className="text-[11px] font-mono text-slate-400">بوابة الدخول الموحدة</span>
      </div>

      {/* Main Center Container */}
      <div className="container max-w-2xl mx-auto my-auto space-y-8">
        
        {/* Centered Brand Header: Logo at the top (without circle) with Name directly underneath */}
        <div className="text-center space-y-3 flex flex-col items-center justify-center">
          <Link to="/" className="inline-block transition-transform hover:scale-105">
            <img
              src={logoAsset.logo.url}
              alt="شعار روّاد"
              className="h-20 w-auto object-contain mx-auto"
            />
          </Link>
          <div className="space-y-2">
            <h1 className="text-3xl sm:text-4xl font-black text-[#002855] dark:text-white font-display">
              منصة روّاد
            </h1>
            <h2 className="text-xl sm:text-2xl md:text-3xl font-black text-[#001F3F] dark:text-[#C88A2C] font-display tracking-tight leading-snug">
              تسجيل الدخول إلى المنظومة التعليمية الذكية
            </h2>
          </div>
        </div>

        {/* أزرار التعبئة التلقائية: للتطوير فقط */}
        {import.meta.env.DEV && (
        <div className="space-y-3">
          <div className="text-center">
            <span className="text-xs font-bold text-[#C88A2C] uppercase tracking-wider">
              حدد الدور للتعبئة التلقائية
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
            {roles.map((r, idx) => {
              const isSelected = selectedRoleIndex === idx;
              const Icon = r.icon;
              return (
                <button
                  key={r.id}
                  type="button"
                  onClick={() => handleRoleSelect(idx)}
                  className={`p-3.5 rounded-2xl border transition-all flex flex-col items-center justify-center gap-2.5 text-center cursor-pointer ${
                    isSelected
                      ? `${r.activeBg} ${r.activeBorder} shadow-md scale-105 border-2`
                      : "border-slate-200 dark:border-white/10 bg-white dark:bg-[#001F3F] hover:border-slate-300 hover:shadow-sm"
                  }`}
                >
                  <div
                    className={`h-11 w-11 rounded-xl grid place-items-center transition-transform ${
                      isSelected
                        ? "bg-white dark:bg-[#001428] shadow-sm scale-110"
                        : "bg-slate-50 dark:bg-white/5 text-slate-600 dark:text-slate-300"
                    }`}
                    style={{ color: isSelected ? r.themeColor : undefined }}
                  >
                    <Icon className="h-5 w-5" />
                  </div>
                  <div className="space-y-0.5">
                    <div
                      className={`text-xs font-bold transition-colors ${
                        isSelected ? r.activeText : "text-foreground"
                      }`}
                    >
                      {r.role}
                    </div>
                    <div className="text-[10px] text-muted-foreground font-mono">
                      {r.email.split("@")[0]}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Active Role Quick Description Pill */}
          {activeRole && (
            <div className="p-3 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50 dark:bg-[#001F3F] text-center text-xs text-foreground flex items-center justify-center gap-2 transition-all">
              <span className="h-2 w-2 rounded-full" style={{ backgroundColor: activeRole.themeColor }}></span>
              <span className="font-bold">{activeRole.title}:</span>
              <span className="text-muted-foreground">{activeRole.desc}</span>
            </div>
          )}
        </div>
        )}

        {/* Form Card */}
        <Card className="border border-slate-200/90 dark:border-[#002855] bg-white dark:bg-[#001F3F] shadow-2xl shadow-[#002855]/5 rounded-3xl overflow-hidden">
          <CardContent className="p-7 sm:p-9 space-y-6">
            
            <form onSubmit={handleSubmit} className="space-y-4">
              
              {/* Email */}
              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-xs font-bold text-foreground flex items-center justify-between">
                  <span>البريد الإلكتروني</span>
                  <Mail className="h-3.5 w-3.5 text-muted-foreground" />
                </Label>
                <Input
                  id="email"
                  type="email"
                  dir="ltr"
                  value={email}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setEmail(e.target.value)
                  }
                  required
                  placeholder="name@rowad.com"
                  className="text-left font-mono text-xs h-11 rounded-xl border-slate-200 dark:border-white/15 focus-visible:ring-[#002855] bg-slate-50/50 dark:bg-[#001428]"
                />
              </div>

              {/* Password */}
              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password" className="text-xs font-bold text-foreground flex items-center gap-1.5">
                    <span>كلمة المرور</span>
                  </Label>
                  <button
                    type="button"
                    onClick={handleForgot}
                    className="text-[11px] text-[#C88A2C] font-semibold hover:underline cursor-pointer"
                  >
                    نسيت كلمة المرور؟
                  </button>
                </div>
                <Input
                  id="password"
                  type="password"
                  dir="ltr"
                  value={password}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setPassword(e.target.value)
                  }
                  required
                  placeholder="••••••••"
                  className="text-left font-mono text-xs h-11 rounded-xl border-slate-200 dark:border-white/15 focus-visible:ring-[#002855] bg-slate-50/50 dark:bg-[#001428]"
                />
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                disabled={loading}
                className="w-full btn-primary !h-12 !text-sm !font-bold !rounded-xl !bg-[#002855] hover:!bg-[#001F3F] !text-white transition-all shadow-lg shadow-[#002855]/20 mt-2 cursor-pointer"
              >
                {loading ? "جاري التحقق والدخول..." : "دخول إلى لوحة التحكم"}
              </Button>
            </form>

          </CardContent>
        </Card>

      </div>

      {/* Footer */}
      <div className="container max-w-4xl mx-auto text-center pt-6 text-[11px] text-slate-400">
        © 2026 منصة روّاد — نرافق طلاب اليوم... لنصنع روّاد الغد.
      </div>

    </div>
  );
}

export default LoginPage;
