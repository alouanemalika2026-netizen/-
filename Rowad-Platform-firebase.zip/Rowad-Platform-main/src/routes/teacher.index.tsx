import { createFileRoute } from "@tanstack/react-router";
import { GraduationCap, School, CalendarDays, ClipboardCheck } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/dashboard/StatCard";
import { GrowthChart, SubjectPie } from "@/components/dashboard/charts";
import { useCollection } from "@/lib/db";
import { StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/teacher/")({
  component: TeacherDashboard,
});

function TeacherDashboard() {
  const { data: timetable } = useCollection<any>("timetable");
  const { data: homework } = useCollection<any>("homework");
  return (
    <div className="space-y-5">
      <div className="rounded-2xl bg-[#002855] p-6 text-white shadow-sm">
        <div className="text-sm opacity-90">أهلاً بعودتك</div>
        <h1 className="mt-1 text-3xl font-black">أ. أحمد بن علي</h1>
        <p className="mt-2 max-w-2xl text-white/85">لديك 3 حصص اليوم و 12 واجب بحاجة للتصحيح.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={GraduationCap} label="طلابي" value="142" tone="purple" />
        <StatCard icon={School} label="أقسامي" value="5" tone="pink" />
        <StatCard icon={CalendarDays} label="حصص الأسبوع" value="18" tone="blue" />
        <StatCard icon={ClipboardCheck} label="نسبة الحضور" value="94%" tone="teal" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <GrowthChart />
        <SubjectPie />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-2"><CardTitle>حصص اليوم</CardTitle></CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {(timetable[0]?.slots ?? []).map((s, i) => (
                <li key={i} className="flex items-center justify-between rounded-lg border p-3 text-sm">
                  <div>
                    <div className="font-semibold">{s.subject}</div>
                    <div className="text-xs text-muted-foreground">قاعة {s.room}</div>
                  </div>
                  <div className="text-xs font-bold text-brand-purple">{s.time}</div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle>الواجبات الأخيرة</CardTitle></CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {homework.map((h) => (
                <li key={h.id} className="flex items-center justify-between rounded-lg border p-3 text-sm">
                  <div>
                    <div className="font-semibold">{h.title}</div>
                    <div className="text-xs text-muted-foreground">{h.subject} · تسليم {h.due}</div>
                  </div>
                  <StatusBadge value={h.status} />
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
