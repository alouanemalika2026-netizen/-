import { createFileRoute } from "@tanstack/react-router";
import { Users, Building2, GraduationCap, DollarSign, TrendingUp } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/dashboard/StatCard";
import { GrowthChart, RevenueChart, SubjectPie } from "@/components/dashboard/charts";
import { useCollection } from "@/lib/db";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/admin/")({
  component: AdminDashboard,
});

function AdminDashboard() {
  const { data: centers } = useCollection<any>("centers");
  return (
    <div className="space-y-5">
      <div className="rounded-2xl bg-[#002855] p-6 text-white shadow-sm">
        <div className="text-sm opacity-90">لوحة المدير العام</div>
        <h1 className="mt-1 text-3xl font-black">نظرة شاملة على المنصة</h1>
        <p className="mt-2 max-w-2xl text-white/85">
          تابع أداء جميع المؤسسات، الاشتراكات، والمستخدمين في مكان واحد.
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={Building2} label="المؤسسات" value="480" trend="12% هذا الشهر" tone="purple" />
        <StatCard icon={Users} label="المستخدمون" value="74,320" trend="8% نمو" tone="pink" />
        <StatCard icon={GraduationCap} label="الطلاب النشطون" value="68,140" trend="5% نمو" tone="blue" />
        <StatCard icon={DollarSign} label="الإيرادات (شهر)" value="12.4M د.ج" trend="18% نمو" tone="orange" />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <GrowthChart />
        <RevenueChart />
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <SubjectPie />
        <Card className="lg:col-span-2">
          <CardHeader className="pb-2">
            <CardTitle>أفضل المؤسسات أداءً</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="divide-y">
              {centers.map((c) => (
                <li key={c.id} className="flex items-center justify-between py-3">
                  <div>
                    <div className="font-semibold">{c.name}</div>
                    <div className="text-xs text-muted-foreground">{c.city} · {c.teachers} أستاذ · {c.students} طالب</div>
                  </div>
                  <Badge variant="outline" className="bg-brand-purple/10 text-brand-purple">
                    <TrendingUp className="me-1 h-3 w-3" /> {c.plan}
                  </Badge>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
