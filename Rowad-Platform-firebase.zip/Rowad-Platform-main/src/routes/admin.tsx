import { createFileRoute, Outlet } from "@tanstack/react-router";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { adminNav } from "@/components/dashboard/nav-configs";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "المدير العام — منصة رواد" }] }),
  component: () => (
    <DashboardLayout role="admin" roleLabel="المدير العام" nav={adminNav}>
      <Outlet />
    </DashboardLayout>
  ),
});
