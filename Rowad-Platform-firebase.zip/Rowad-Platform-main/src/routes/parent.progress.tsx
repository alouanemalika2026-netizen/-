import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ProgressLine, SubjectPie } from "@/components/dashboard/charts";
import { Progress } from "@/components/ui/progress";
import { useCollection } from "@/lib/db";

export const Route = createFileRoute("/parent/progress")({
  component: () => {
    const { data: grades } = useCollection<any>("grades");
    return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold">التقدم الأكاديمي</h1>
        <p className="mt-1 text-sm text-muted-foreground">تطور مستوى الأبناء عبر الأشهر.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <ProgressLine />
        <SubjectPie />
      </div>
      <Card>
        <CardHeader><CardTitle>نقاط يوسف الأمين حسب المادة</CardTitle></CardHeader>
        <CardContent className="space-y-4">
          {grades.filter((g) => g.student === "يوسف الأمين").map((g) => (
            <div key={g.id}>
              <div className="flex justify-between text-sm">
                <span className="font-semibold">{g.subject}</span>
                <span className="font-bold text-brand-purple">{g.grade}/{g.max}</span>
              </div>
              <Progress value={(g.grade / g.max) * 100} className="mt-1 h-2.5" />
              <div className="mt-1 text-xs text-muted-foreground">{g.comment}</div>
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
    );
  },
});
