import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/dashboard/StatCard";
import { GrowthChart, RevenueChart, SubjectPie } from "@/components/dashboard/charts";
import { Users, Building2, GraduationCap, TrendingUp } from "lucide-react";

function AnalyticsPage({ title }: { title: string }) {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold">{title}</h1>
        <p className="mt-1 text-sm text-muted-foreground">لوحة تحليلات تفصيلية مع مؤشرات الأداء.</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={Building2} label="مؤسسات نشطة" value="452" trend="6% نمو" tone="purple" />
        <StatCard icon={Users} label="مستخدمون شهرياً" value="52,830" trend="14% نمو" tone="pink" />
        <StatCard icon={GraduationCap} label="ساعات تعلم" value="184,500" trend="21% نمو" tone="blue" />
        <StatCard icon={TrendingUp} label="نسبة الاحتفاظ" value="94%" trend="+3%" tone="teal" />
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <GrowthChart />
        <SubjectPie />
      </div>
      <RevenueChart />
      <Card>
        <CardHeader><CardTitle>ملاحظات ذكية</CardTitle></CardHeader>
        <CardContent className="space-y-2 text-sm">
          <div className="rounded-lg border p-3">📈 نمو الطلاب في وهران بنسبة <b>28%</b> — يوصى بحملة إعلانية إضافية.</div>
          <div className="rounded-lg border p-3">🎯 مادة الرياضيات هي الأكثر طلباً — تعزيز عدد الأساتذة يزيد الإيرادات.</div>
          <div className="rounded-lg border p-3">⚠️ نسبة الغياب في قسنطينة أعلى من المعتاد — تنبيه الفرع.</div>
        </CardContent>
      </Card>
    </div>
  );
}

export const Route = createFileRoute("/admin/analytics")({
  component: () => <AnalyticsPage title="التحليلات" />,
});
