import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/admin/plans")({
  component: () => (
    <DataTablePage
      title="خطط الاشتراك"
      description="الخطط المتاحة للمؤسسات"
      addLabel="إضافة خطة"
      collection="plans"
      columns={[
  { key: "name", label: "الخطة" },
  { key: "price", label: "السعر" },
  { key: "centers", label: "عدد المؤسسات" },
  { key: "students", label: "عدد الطلاب" },
  { key: "features", label: "المميزات" },
]}
      filters={[]}
    />
  ),
});
