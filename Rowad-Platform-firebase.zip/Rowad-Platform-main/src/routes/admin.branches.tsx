import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/admin/branches")({
  component: () => (
    <DataTablePage
      title="الفروع"
      description="فروع المؤسسات"
      addLabel="إضافة فرع"
      collection="branches"
      columns={[
  { key: "center", label: "المؤسسة" },
  { key: "name", label: "الفرع" },
  { key: "city", label: "المدينة" },
  { key: "students", label: "الطلاب" },
]}
      filters={[]}
    />
  ),
});
