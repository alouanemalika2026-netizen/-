import { createFileRoute, Outlet } from "@tanstack/react-router";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { centerNav } from "@/components/dashboard/nav-configs";

export const Route = createFileRoute("/center")({
  head: () => ({ meta: [{ title: "لوحة المؤسسة — منصة رواد" }] }),
  component: () => (
    <DashboardLayout role="center" roleLabel="المؤسسة التعليمية" nav={centerNav}>
      <Outlet />
    </DashboardLayout>
  ),
});
