import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/announcements")({
  component: () => (
    <DataTablePage
      title="الإعلانات"
      description="إعلانات المؤسسة"
      addLabel="إعلان جديد"
      collection="announcements"
      columns={[
  { key: "title", label: "الإعلان" },
  { key: "audience", label: "الجمهور" },
  { key: "date", label: "التاريخ" },
]}
      filters={[]}
    />
  ),
});
