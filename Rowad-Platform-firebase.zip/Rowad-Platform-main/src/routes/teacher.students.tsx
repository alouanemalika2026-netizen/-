import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/teacher/students")({
  component: () => (
    <DataTablePage
      title="طلابي"
      description="قائمة طلابي"
      addLabel="إضافة طالب"
      collection="students"
      columns={[
  { key: "name", label: "الاسم" },
  { key: "level", label: "المستوى" },
  { key: "attendance", label: "الحضور" },
  { key: "average", label: "المعدل" },
  { key: "status", label: "الحالة", render: (r) => <StatusBadge value={r.status} /> },
]}
      filters={[]}
    />
  ),
});
