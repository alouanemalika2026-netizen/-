import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/admin/centers")({
  component: () => (
    <DataTablePage
      title="إدارة المؤسسات"
      description="جميع المؤسسات المسجلة"
      addLabel="إضافة مؤسسة"
      collection="centers"
      columns={[
  { key: "name", label: "المؤسسة" },
  { key: "city", label: "المدينة" },
  { key: "teachers", label: "الأساتذة" },
  { key: "students", label: "الطلاب" },
  { key: "plan", label: "الخطة", render: (r) => <StatusBadge value={r.plan} /> },
]}
      filters={[{ key: "plan", label: "الخطط", options: ["أساسي","متقدم","احترافي"] }]}
    />
  ),
});
