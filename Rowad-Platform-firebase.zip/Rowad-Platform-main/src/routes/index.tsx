import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useEffect, useRef } from "react";
import {
  GraduationCap,
  Users,
  CalendarDays,
  ClipboardCheck,
  FileText,
  Bell,
  Video,
  BarChart3,
  Check,
  Menu,
  X,
  Building2,
  Phone,
  Mail,
  MapPin,
  TrendingUp,
  Shield,
  BookOpen,
  LineChart,
  UserCheck,
  MessageSquare,
  Loader2,
  AlertCircle,
  School,
  ChevronDown,
  Layers,
  Clock,
  Send,
  HelpCircle,
  FileSpreadsheet,
  CheckCircle2,
} from "lucide-react";
import { toast } from "sonner";
import logoAsset from "@/assets/rowad-logo.asset.json";
import { HeroProductPreview } from "@/components/landing/HeroProductPreview";
import {
  AdminDashboardMockup,
  TeacherDashboardMockup,
  StudentDashboardMockup,
  ParentDashboardMockup,
} from "@/components/landing/FeatureDashboardMockups";
import {
  EcosystemSection,
  AnalyticsSectionMockup,
  CommunicationMockup,
  MobileExperienceFrames,
} from "@/components/landing/InteractiveSections";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "منصة روّاد — نرافق طلاب اليوم... لنصنع روّاد الغد" },
      {
        name: "description",
        content:
          "منصة تكنولوجية متكاملة لإدارة المؤسسات والمراكز التعليمية والأساتذة والطلاب وأولياء الأمور في مكان واحد.",
      },
      { property: "og:title", content: "روّاد — المنصة التعليمية المتكاملة" },
      {
        property: "og:description",
        content:
          "إدارة الحصص والطلاب والأساتذة والامتحانات والنتائج بتجربة استخدام فائقة الجودة.",
      },
      { property: "og:image", content: logoAsset.logo.url },
      { property: "og:type", content: "website" },
    ],
  }),
  component: LandingPage,
});

function CountUpNumber({ end, duration = 1800, prefix = "+", suffix = "" }: { end: number; duration?: number; prefix?: string; suffix?: string }) {
  const [count, setCount] = useState(0);
  const [hasStarted, setHasStarted] = useState(false);
  const elementRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting && !hasStarted) {
          setHasStarted(true);
        }
      },
      { threshold: 0.15 }
    );

    if (elementRef.current) {
      observer.observe(elementRef.current);
    }

    return () => observer.disconnect();
  }, [hasStarted]);

  useEffect(() => {
    if (!hasStarted) return;

    let startTime: number | null = null;
    let animationFrameId: number;

    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      // easeOutExpo for very fast initial motion that smoothly decelerates to target
      const easeOut = progress === 1 ? 1 : 1 - Math.pow(2, -10 * progress);
      setCount(Math.floor(easeOut * end));

      if (progress < 1) {
        animationFrameId = requestAnimationFrame(step);
      } else {
        setCount(end);
      }
    };

    animationFrameId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(animationFrameId);
  }, [hasStarted, end, duration]);

  return (
    <div ref={elementRef} className="font-mono font-black tracking-tight inline-block">
      {prefix}
      {count.toLocaleString()}
      {suffix}
    </div>
  );
}

function RevealSection({ children, id, className = "" }: { children: React.ReactNode; id?: string; className?: string }) {
  const [isVisible, setIsVisible] = useState(true);
  const ref = useRef<HTMLElement>(null);

  useEffect(() => {
    if (typeof window === "undefined" || !("IntersectionObserver" in window)) {
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.01, rootMargin: "100px 0px 100px 0px" }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <section
      id={id}
      ref={ref}
      className={cn(
        "reveal-visible transition-all duration-500 ease-out opacity-100 translate-y-0",
        className
      )}
    >
      {children}
    </section>
  );
}

function LandingPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Arabic Typewriter State for: "لنصنع روّاد الغد..."
  const fullText = "لنصنع روّاد الغد...";
  const [displayedText, setDisplayedText] = useState("");
  const [isDeleting, setIsDeleting] = useState(false);

  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const y = window.scrollY;
      setScrolled(y > 20);
      setScrollY(y);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Continuous smooth typewriter effect with faster speed
  useEffect(() => {
    let timer: ReturnType<typeof setTimeout>;

    if (!isDeleting && displayedText.length < fullText.length) {
      // Faster typing speed (85ms instead of 130ms)
      timer = setTimeout(() => {
        setDisplayedText(fullText.slice(0, displayedText.length + 1));
      }, 85);
    } else if (!isDeleting && displayedText.length === fullText.length) {
      // Shorter pause when full sentence is completed (1600ms instead of 2200ms)
      timer = setTimeout(() => {
        setIsDeleting(true);
      }, 1600);
    } else if (isDeleting && displayedText.length > 0) {
      // Faster erasing speed (40ms instead of 65ms)
      timer = setTimeout(() => {
        setDisplayedText(fullText.slice(0, displayedText.length - 1));
      }, 40);
    } else if (isDeleting && displayedText.length === 0) {
      // Brief pause before typing again
      timer = setTimeout(() => {
        setIsDeleting(false);
      }, 350);
    }

    return () => clearTimeout(timer);
  }, [displayedText, isDeleting, fullText]);

  return (
    <div className="min-h-screen bg-background text-foreground selection:bg-[#002855]/20 selection:text-[#001F3F] dark:selection:text-[#C88A2C] font-sans">
      
      {/* 1. Modern Sticky Editorial Navbar */}
      <header
        className={cn(
          "sticky top-0 z-50 w-full transition-all duration-300 bg-white/90 dark:bg-[#001428]/90 backdrop-blur-md",
          scrolled
            ? "border-b border-[#002855]/10 shadow-sm py-3"
            : "border-b border-transparent py-4 sm:py-5"
        )}
      >
        <div className="container max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between">
          
          {/* Brand Right Side (RTL) - Natural Logo with Thmanyah Typography, No Circle, No Slogan */}
          <Link to="/" className="flex items-center gap-3.5 group">
            <img
              src={logoAsset.logo.url}
              alt="شعار منصة روّاد"
              className="h-12 w-auto object-contain transition-transform duration-300 group-hover:scale-105"
            />
            <span className="text-2xl font-black tracking-tight text-[#002855] dark:text-white font-display group-hover:text-[#C88A2C] transition-colors">
              منصة روّاد
            </span>
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-7 text-sm font-semibold text-slate-600 dark:text-slate-300">
            <a href="#about" className="hover:text-[#002855] dark:hover:text-white transition-colors">
              الرئيسية
            </a>
            <a href="#features" className="hover:text-[#002855] dark:hover:text-white transition-colors">
              المميزات
            </a>
            <a href="#how-it-works" className="hover:text-[#002855] dark:hover:text-white transition-colors">
              كيف تعمل المنصة
            </a>
            <a href="#roles" className="hover:text-[#002855] dark:hover:text-white transition-colors">
              لمن صُممت؟
            </a>
            <a href="#pricing" className="hover:text-[#002855] dark:hover:text-white transition-colors">
              الأسعار
            </a>
            <a href="#faq" className="hover:text-[#002855] dark:hover:text-white transition-colors">
              الأسئلة الشائعة
            </a>
            <a href="#contact" className="hover:text-[#002855] dark:hover:text-white transition-colors">
              تواصل معنا
            </a>
          </nav>

          {/* Desktop Action Buttons - Unified Design System */}
          <div className="hidden sm:flex items-center gap-3">
            <Link
              to="/login"
              className="btn-secondary !py-2 !px-4 !text-xs !shadow-none"
            >
              تسجيل الدخول
            </Link>
            <a
              href="#pricing"
              className="btn-gold !py-2 !px-4 !text-xs"
            >
              ابدأ الآن
            </a>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden p-2 rounded-lg text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 focus:outline-none"
            aria-label="القائمة"
          >
            {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation Drawer */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-b border-border bg-white dark:bg-[#001F3F] px-4 pt-3 pb-6 space-y-3 text-right">
            <nav className="flex flex-col space-y-2 text-sm font-medium">
              <a
                href="#about"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                الرئيسية
              </a>
              <a
                href="#features"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                المميزات
              </a>
              <a
                href="#how-it-works"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                كيف تعمل المنصة
              </a>
              <a
                href="#roles"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                لمن صُممت؟
              </a>
              <a
                href="#pricing"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                الأسعار
              </a>
              <a
                href="#faq"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                الأسئلة الشائعة
              </a>
              <a
                href="#contact"
                onClick={() => setMobileMenuOpen(false)}
                className="px-3 py-2 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                تواصل معنا
              </a>
            </nav>
            <div className="pt-3 border-t border-border flex flex-col gap-2">
              <Link
                to="/login"
                className="w-full text-center py-2.5 text-sm font-bold rounded-lg border border-border"
              >
                تسجيل الدخول
              </Link>
              <a
                href="#pricing"
                onClick={() => setMobileMenuOpen(false)}
                className="w-full text-center py-2.5 text-sm font-bold text-white bg-[#C88A2C] rounded-lg"
              >
                ابدأ الآن
              </a>
            </div>
          </div>
        )}
      </header>

      {/* 2. Premium Pure White Hero Section with Subtle Modern Dot Grid - Crisp & Zero Shadows */}
      <section id="about" className="relative pt-12 pb-16 md:pt-20 md:pb-24 px-4 sm:px-6 bg-white dark:bg-[#001428] overflow-hidden">
        
        {/* Subtle geometric dot grid pattern behind text */}
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#0028550d_1px,transparent_1px),linear-gradient(to_bottom,#0028550d_1px,transparent_1px)] bg-[size:28px_28px]"></div>
        </div>

        <div
          className="container relative z-10 max-w-5xl mx-auto text-center space-y-8 transition-all duration-300 ease-out"
          style={{
            transform: `translateY(${Math.min(scrollY * 0.14, 40)}px)`,
          }}
        >
          
          {/* Main Headline with High Visual Distinction & Pure Crisp Arabic Text (No Shadows, No Overlays) */}
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black tracking-tight text-[#001F3F] dark:text-white leading-[1.2] max-w-4xl mx-auto font-display animate-fade-in-up">
            نرافق طلاب اليوم...
            <br />
            <span className="relative inline-block mt-3 min-h-[1.3em]">
              <span 
                dir="rtl" 
                className="text-[#C88A2C] inline-block tracking-normal font-bold"
              >
                {displayedText}
                <span className="typewriter-cursor" aria-hidden="true"></span>
              </span>
              {/* Decorative clean stroke under gold text */}
              <svg className="absolute -bottom-3 left-0 w-full h-3 text-[#C88A2C]/50" viewBox="0 0 100 20" preserveAspectRatio="none">
                <path d="M0 15 Q50 0 100 15" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
              </svg>
            </span>
          </h1>

          {/* Supporting Text */}
          <p className="text-base sm:text-lg md:text-xl text-slate-600 dark:text-slate-300 leading-relaxed max-w-2xl mx-auto font-medium animate-fade-in-up delay-100">
            المنصة العربية الموحدة التي تجمع المراكز التعليمية، الأساتذة، الطلاب وأولياء الأمور
            في بيئة رقمية متكاملة تنظم الجداول، تضبط الحضور، وترصد التقدم الأكاديمي بدقة واحترافية.
          </p>

          {/* Call to Action Buttons - Standardized Unified Design System */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-center gap-3 max-w-sm mx-auto animate-fade-in-up delay-200">
            <a
              href="#pricing"
              className="btn-primary w-full sm:w-auto"
            >
              <span>ابدأ تجربتك الآن</span>
            </a>
            <a
              href="#solution"
              className="btn-secondary w-full sm:w-auto"
            >
              <span>استكشف المنصة</span>
            </a>
          </div>

          {/* Floating Feature Badges with Animations - Crisp Borders, No Shadows */}
          <div className="pt-4 flex flex-wrap items-center justify-center gap-3 text-xs font-semibold text-slate-700 dark:text-slate-300">
            <div className="flex items-center gap-2 bg-slate-50 dark:bg-[#001F3F] px-3.5 py-1.5 rounded-full border border-slate-200 dark:border-white/10 animate-float-slow">
              <Check className="h-3.5 w-3.5 text-[#C88A2C] stroke-[3]" />
              <span>إدارة شاملة للمراكز والأفواج</span>
            </div>
            <div className="flex items-center gap-2 bg-slate-50 dark:bg-[#001F3F] px-3.5 py-1.5 rounded-full border border-slate-200 dark:border-white/10 animate-float-reverse">
              <Check className="h-3.5 w-3.5 text-[#002855] dark:text-blue-400 stroke-[3]" />
              <span>حضور ذكي برمز QR فوري</span>
            </div>
            <div className="flex items-center gap-2 bg-slate-50 dark:bg-[#001F3F] px-3.5 py-1.5 rounded-full border border-slate-200 dark:border-white/10 animate-float-slow" style={{ animationDelay: "1.5s" }}>
              <Check className="h-3.5 w-3.5 text-emerald-600 stroke-[3]" />
              <span>تواصل مباشر مع ولي الأمر</span>
            </div>
          </div>

        </div>

        {/* Professional Live Product Dashboard Preview Window - Always 100% Real Crisp Colors */}
        <div className="container relative z-10 max-w-6xl mx-auto px-2 sm:px-4 pt-4">
          <HeroProductPreview />
        </div>

      </section>

      {/* Modern Section Divider */}
      <div className="relative w-full h-px bg-slate-200 dark:border-white/10 flex items-center justify-center">
        <div className="w-16 h-0.5 bg-[#C88A2C]"></div>
      </div>

      {/* 3. Subtle Trust / Social Proof Section */}
      <section className="py-12 border-y border-border/60 bg-white dark:bg-[#001428]">
        <div className="container max-w-6xl mx-auto px-4 sm:px-6 text-center">
          <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-6">
            منظومة رقمية مصممة لمجتمع تعليمي متكامل
          </p>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-3xl mx-auto">
            <div className="flex flex-col items-center gap-2 p-3 rounded-xl">
              <div className="h-10 w-10 rounded-xl bg-[#002855]/10 text-[#002855] dark:text-[#C88A2C] grid place-items-center">
                <Building2 className="h-5 w-5" />
              </div>
              <span className="text-sm font-bold">المراكز التعليمية</span>
            </div>

            <div className="flex flex-col items-center gap-2 p-3 rounded-xl">
              <div className="h-10 w-10 rounded-xl bg-[#C88A2C]/10 text-[#C88A2C] grid place-items-center">
                <Users className="h-5 w-5" />
              </div>
              <span className="text-sm font-bold">المدرسون</span>
            </div>

            <div className="flex flex-col items-center gap-2 p-3 rounded-xl">
              <div className="h-10 w-10 rounded-xl bg-emerald-500/10 text-emerald-600 grid place-items-center">
                <GraduationCap className="h-5 w-5" />
              </div>
              <span className="text-sm font-bold">الطلاب</span>
            </div>

            <div className="flex flex-col items-center gap-2 p-3 rounded-xl">
              <div className="h-10 w-10 rounded-xl bg-amber-500/10 text-amber-600 grid place-items-center">
                <UserCheck className="h-5 w-5" />
              </div>
              <span className="text-sm font-bold">أولياء الأمور</span>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Problem & Story Section */}
      <RevealSection id="problem" className="py-20 px-4 sm:px-6 bg-white dark:bg-[#001428]">
        <div className="container max-w-5xl mx-auto space-y-12 text-center">
          
          <div className="space-y-3 max-w-2xl mx-auto">
            <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase">
              التحديات الواقعية
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-[#001F3F] dark:text-white font-display">
              التعليم لا يحتاج إلى مزيد من التعقيد
            </h2>
            <p className="text-muted-foreground text-sm sm:text-base leading-relaxed">
              تواجه المؤسسات والمدرسون يومياً استنزافاً هائلاً في الوقت والجهد نتيجة
              تشتت الأدوات وغياب حلقة ربط واضحة بين أطراف التجربة التعليمية.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 text-right">
            
            <div className="p-6 rounded-2xl border border-border/80 bg-card space-y-2 card-hover-interactive group">
              <span className="text-xs font-mono font-bold text-[#C88A2C] bg-[#C88A2C]/10 px-2 py-0.5 rounded-md">01</span>
              <h3 className="text-lg font-bold group-hover:text-[#002855] dark:group-hover:text-[#C88A2C] transition-colors">تعدد الأدوات</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                المعلومات موزعة بين أكثر من مكان؛ جداول إكسل، مجموعات واتساب، وسجلات ورقية يصعب التحكم فيها.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-border/80 bg-card space-y-2 card-hover-interactive group">
              <span className="text-xs font-mono font-bold text-[#C88A2C] bg-[#C88A2C]/10 px-2 py-0.5 rounded-md">02</span>
              <h3 className="text-lg font-bold group-hover:text-[#002855] dark:group-hover:text-[#C88A2C] transition-colors">المتابعة اليدوية</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                الحضور والدرجات والواجبات تحتاج إلى وقت وجهد مضاعف لجمعها وتدقيقها أسبوعياً.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-border/80 bg-card space-y-2 card-hover-interactive group">
              <span className="text-xs font-mono font-bold text-[#C88A2C] bg-[#C88A2C]/10 px-2 py-0.5 rounded-md">03</span>
              <h3 className="text-lg font-bold group-hover:text-[#002855] dark:group-hover:text-[#C88A2C] transition-colors">ضعف التواصل</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                يصعب على ولي الأمر متابعة أداء أبنائه باستمرار والاطمئنان على انتظام حضورهم في الوقت الحقيقي.
              </p>
            </div>

            <div className="p-6 rounded-2xl border border-border/80 bg-card space-y-2 card-hover-interactive group">
              <span className="text-xs font-mono font-bold text-[#C88A2C] bg-[#C88A2C]/10 px-2 py-0.5 rounded-md">04</span>
              <h3 className="text-lg font-bold group-hover:text-[#002855] dark:group-hover:text-[#C88A2C] transition-colors">غياب الصورة الكاملة</h3>
              <p className="text-xs text-muted-foreground leading-relaxed">
                يصعب على الإدارة معرفة مستوى المركز بشكل واضح أو استخراج مؤشرات موثوقة تسهم في تطويره.
              </p>
            </div>

          </div>

          {/* Story Transition */}
          <div className="p-6 rounded-2xl bg-white dark:bg-[#001F3F] border border-[#002855]/15 text-center sm:text-right flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
            <div>
              <h4 className="text-lg font-bold text-[#002855] dark:text-white font-display">
                روّاد تجمع كل ذلك في مكان واحد.
              </h4>
              <p className="text-xs text-muted-foreground mt-1">
                نظام إدارة عصري يحول الفوضى الورقية إلى مسارات رقمية واضحة ومترابطة.
              </p>
            </div>
            <a
              href="#solution"
              className="btn-primary !text-xs shrink-0"
            >
              استكشف الحلول
            </a>
          </div>

        </div>
      </RevealSection>

      {/* 5. Solution Section (Clean Grid Overview) */}
      <section id="solution" className="py-16 sm:py-20 border-t border-border/60 bg-white dark:bg-[#001428] px-4 sm:px-6">
        <div className="container max-w-6xl mx-auto space-y-10 sm:space-y-12 text-center">
          
          <div className="max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase">
              نطاق المنصة
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-[#001F3F] dark:text-white font-display">
              كل ما تحتاجه لإدارة التعليم... في مكان واحد
            </h2>
            <p className="text-muted-foreground text-sm sm:text-base leading-relaxed">
              حزمة متكاملة من الوحدات والأدوات المصممة لتغطية كافة جوانب اليوم الدراسي.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5 text-center">
            
            {[
              { title: "إدارة الطلاب", desc: "سجلات شاملة ومتابعة أكاديمية مستمرة", icon: GraduationCap },
              { title: "إدارة المدرسين", desc: "تنظيم الأفواج وتوزيع المواد والجداول", icon: Users },
              { title: "الحضور والغياب", desc: "تسجيل فوري بالباركود وإشعارات فورية", icon: ClipboardCheck },
              { title: "الجداول والحصص", desc: "تنظيم مواعيد القاعات والأفواج بدقة", icon: CalendarDays },
              { title: "الاختبارات", desc: "برمجة الفروض والامتحانات الدورية", icon: FileText },
              { title: "الدرجات والنقاط", desc: "رصد الكشوفات وحساب المعدلات تلقائياً", icon: BarChart3 },
              { title: "الواجبات والتمارين", desc: "رفع المهام واستلام الحلول وتقييمها", icon: BookOpen },
              { title: "الدروس والمقررات", desc: "تنظيم المناهج والملفات الرقمية", icon: School },
              { title: "مكتبة الفيديوهات", desc: "تسجيلات الحصص والشروحات التفاعلية", icon: Video },
              { title: "التقارير الشاملة", desc: "مؤشرات تحليلية تفصيلية لكل فوج", icon: LineChart },
              { title: "لوحة الإعلانات", desc: "نشر مستجدات المركز وأخبار الفصول", icon: Bell },
              { title: "التواصل مع أولياء الأمور", desc: "رسائل مباشرة وشفافية كاملة للأداء", icon: MessageSquare },
            ].map((feat, idx) => (
              <div
                key={idx}
                className="p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#001F3F] hover:border-[#C88A2C]/60 card-hover-interactive flex flex-col items-center justify-center text-center space-y-2.5 group cursor-default shadow-sm hover:shadow-md hover:scale-[1.02] transition-all duration-300"
              >
                <div className="h-11 w-11 rounded-xl bg-[#002855]/5 text-[#002855] dark:text-[#C88A2C] group-hover:bg-[#002855] group-hover:text-white dark:group-hover:bg-[#C88A2C] dark:group-hover:text-white transition-all duration-300 grid place-items-center">
                  <feat.icon className="h-5 w-5 transition-transform group-hover:scale-110 duration-300" />
                </div>
                <h4 className="font-bold text-sm text-[#001F3F] dark:text-white group-hover:text-[#002855] dark:group-hover:text-[#C88A2C] transition-colors">
                  {feat.title}
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed max-w-[200px]">
                  {feat.desc}
                </p>
              </div>
            ))}

          </div>

        </div>
      </section>

      {/* 6. Unified Interactive Role Experience (No Redundant Dashboard Repetitions) */}
      <section id="roles" className="py-20 px-4 sm:px-6 border-t border-border/60 bg-[#FAFBFC] dark:bg-[#001428]">
        <div className="container max-w-6xl mx-auto space-y-12 text-center">
          
          <div className="max-w-2xl mx-auto space-y-3">
            <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase">
              تجربة مصممة لكل دور
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-[#001F3F] dark:text-white font-display">
              روّاد تجمع أركان العملية التعليمية بذكاء
            </h2>
            <p className="text-sm sm:text-base text-muted-foreground leading-relaxed">
              بدلاً من الشاشات المتشابهة، توفر المنصة لكل طرف واجهة عمل مخصصة تناسب احتياجاته اليومية الفعلية.
            </p>
          </div>

          {/* 4 Distinct Role Cards with Rich Hover Animations */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* 1. Center Administration */}
            <div className="p-7 rounded-2xl border border-border/80 bg-white dark:bg-[#001F3F] card-hover-interactive space-y-4 group">
              <div className="flex items-center justify-between">
                <div className="h-12 w-12 rounded-xl bg-[#002855]/10 text-[#002855] dark:text-[#C88A2C] grid place-items-center group-hover:scale-110 transition-transform">
                  <Building2 className="h-6 w-6" />
                </div>
                <span className="text-xs font-mono font-bold text-[#C88A2C] bg-[#C88A2C]/10 px-2.5 py-1 rounded-full">
                  للإدارة والمراكز
                </span>
              </div>
              <h3 className="text-xl font-bold text-[#001F3F] dark:text-white group-hover:text-[#002855] dark:group-hover:text-[#C88A2C] transition-colors">
                التحكم المركزي بالعمليات
              </h3>
              <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                توزيع القاعات، تنظيم اشتراكات الطلاب، اعتماد الجداول الأسبوعية، واستخراج المؤشرات المالية والتقارير الشهرية بضغطة زر.
              </p>
              <div className="pt-2 flex items-center justify-between border-t border-border/60 text-xs font-semibold">
                <span className="text-emerald-600">✓ ضبط حضور وأفواج متزامن</span>
                <Link to="/center" className="text-[#002855] dark:text-[#C88A2C] hover:underline flex items-center gap-1">
                  <span>لوحة المركز</span>
                  <span>←</span>
                </Link>
              </div>
            </div>

            {/* 2. Teachers */}
            <div className="p-7 rounded-2xl border border-border/80 bg-white dark:bg-[#001F3F] card-hover-interactive space-y-4 group">
              <div className="flex items-center justify-between">
                <div className="h-12 w-12 rounded-xl bg-[#C88A2C]/10 text-[#C88A2C] grid place-items-center group-hover:scale-110 transition-transform">
                  <Users className="h-6 w-6" />
                </div>
                <span className="text-xs font-mono font-bold text-[#002855] dark:text-white bg-[#002855]/10 dark:bg-white/10 px-2.5 py-1 rounded-full">
                  للأساتذة والمشرفين
                </span>
              </div>
              <h3 className="text-xl font-bold text-[#001F3F] dark:text-white group-hover:text-[#C88A2C] transition-colors">
                التركيز على التدريس والإتقان
              </h3>
              <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                تسجيل الحضور السريع بمسح باركود الطالب، رفع التمارين والواجبات، ورصد العلامات وإرسال الملاحظات الفردية بدقة.
              </p>
              <div className="pt-2 flex items-center justify-between border-t border-border/60 text-xs font-semibold">
                <span className="text-emerald-600">✓ إحصائيات فورية لكل حصة</span>
                <Link to="/teacher" className="text-[#002855] dark:text-[#C88A2C] hover:underline flex items-center gap-1">
                  <span>فضاء الأستاذ</span>
                  <span>←</span>
                </Link>
              </div>
            </div>

            {/* 3. Students */}
            <div className="p-7 rounded-2xl border border-border/80 bg-white dark:bg-[#001F3F] card-hover-interactive space-y-4 group">
              <div className="flex items-center justify-between">
                <div className="h-12 w-12 rounded-xl bg-emerald-500/10 text-emerald-600 grid place-items-center group-hover:scale-110 transition-transform">
                  <GraduationCap className="h-6 w-6" />
                </div>
                <span className="text-xs font-mono font-bold text-emerald-600 bg-emerald-500/10 px-2.5 py-1 rounded-full">
                  للطلاب والمتعلمين
                </span>
              </div>
              <h3 className="text-xl font-bold text-[#001F3F] dark:text-white group-hover:text-emerald-600 transition-colors">
                تنظيم اليوم الدراسي والواجبات
              </h3>
              <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                مواعيد الحصص القادمة، الفروض والامتحانات، تحميل ملخصات الدروس، ومتابعة تطور المعدل خطوة بخطوة بكل وضوح.
              </p>
              <div className="pt-2 flex items-center justify-between border-t border-border/60 text-xs font-semibold">
                <span className="text-emerald-600">✓ وضوح تام لجميع المهام</span>
                <Link to="/student" className="text-[#002855] dark:text-[#C88A2C] hover:underline flex items-center gap-1">
                  <span>لوحة الطالب</span>
                  <span>←</span>
                </Link>
              </div>
            </div>

            {/* 4. Parents */}
            <div className="p-7 rounded-2xl border border-border/80 bg-white dark:bg-[#001F3F] card-hover-interactive space-y-4 group">
              <div className="flex items-center justify-between">
                <div className="h-12 w-12 rounded-xl bg-amber-500/10 text-amber-600 grid place-items-center group-hover:scale-110 transition-transform">
                  <UserCheck className="h-6 w-6" />
                </div>
                <span className="text-xs font-mono font-bold text-amber-600 bg-amber-500/10 px-2.5 py-1 rounded-full">
                  لأولياء الأمور
                </span>
              </div>
              <h3 className="text-xl font-bold text-[#001F3F] dark:text-white group-hover:text-amber-600 transition-colors">
                المتابعة الشفافة والاطمئنان
              </h3>
              <p className="text-xs sm:text-sm text-muted-foreground leading-relaxed">
                إشعار فوري عند دخول الابن للمركز أو خروجه، متابعة الدرجات الأسبوعية، والاطلاع على ملاحظات الأساتذة بانتظام.
              </p>
              <div className="pt-2 flex items-center justify-between border-t border-border/60 text-xs font-semibold">
                <span className="text-emerald-600">✓ إشعارات لحظية عبر الهاتف</span>
                <Link to="/parent" className="text-[#002855] dark:text-[#C88A2C] hover:underline flex items-center gap-1">
                  <span>فضاء ولي الأمر</span>
                  <span>←</span>
                </Link>
              </div>
            </div>

          </div>

        </div>
      </section>



      {/* 11. How It Works (Simple Timeline with Animated Step Progress & Staggered Cards) */}
      <section id="how-it-works" className="py-20 px-4 sm:px-6 border-t border-slate-200 dark:border-white/10 bg-white dark:bg-[#001428] relative overflow-hidden">
        <div className="container max-w-5xl mx-auto space-y-14 text-center">
          
          <div className="max-w-xl mx-auto space-y-2">
            <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase bg-[#C88A2C]/10 px-3 py-1 rounded-full border border-[#C88A2C]/20 inline-block">
              بساطة الإعداد
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-[#001F3F] dark:text-white font-display">
              ابدأ خلال دقائق
            </h2>
            <p className="text-muted-foreground text-sm">
              خطوات يسيرة ومباشرة لرقمنة مؤسستك التعليمية.
            </p>
          </div>

          {/* Timeline Wrapper with Horizontal Guide Line on Desktop */}
          <div className="relative">
            {/* Connecting Timeline Line */}
            <div className="hidden lg:block absolute top-1/2 left-10 right-10 h-0.5 bg-slate-200 dark:bg-white/10 -translate-y-12 z-0"></div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
              
              {/* Step 01 */}
              <div className="p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#001F3F] text-right space-y-3.5 card-hover-interactive group animate-fade-in-up delay-100 shadow-sm hover:shadow-md">
                <div className="flex items-center justify-between">
                  <span className="h-10 w-10 rounded-xl bg-[#002855] text-white flex items-center justify-center font-black font-mono text-sm shadow-sm group-hover:scale-110 group-hover:bg-[#C88A2C] transition-all">
                    01
                  </span>
                  <span className="text-[11px] font-bold text-[#C88A2C] bg-[#C88A2C]/10 px-2 py-0.5 rounded-md">
                    البداية
                  </span>
                </div>
                <h4 className="font-bold text-base text-[#001F3F] dark:text-white group-hover:text-[#002855] dark:group-hover:text-[#C88A2C] transition-colors">
                  أنشئ بيئتك التعليمية
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  سجّل حساب مركزك، حدد المراحل الدراسية، المواد المتاحة، والقاعات التدريسية.
                </p>
              </div>

              {/* Step 02 */}
              <div className="p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#001F3F] text-right space-y-3.5 card-hover-interactive group animate-fade-in-up delay-200 shadow-sm hover:shadow-md">
                <div className="flex items-center justify-between">
                  <span className="h-10 w-10 rounded-xl bg-[#002855] text-white flex items-center justify-center font-black font-mono text-sm shadow-sm group-hover:scale-110 group-hover:bg-[#C88A2C] transition-all">
                    02
                  </span>
                  <span className="text-[11px] font-bold text-blue-600 bg-blue-500/10 px-2 py-0.5 rounded-md">
                    المستخدمين
                  </span>
                </div>
                <h4 className="font-bold text-base text-[#001F3F] dark:text-white group-hover:text-[#002855] dark:group-hover:text-[#C88A2C] transition-colors">
                  أضف الطلاب والمدرسين
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  استورد قوائم الطلاب والأساتذة بضغطة زر واحدة ووزعهم على الأفواج الدراسية.
                </p>
              </div>

              {/* Step 03 */}
              <div className="p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#001F3F] text-right space-y-3.5 card-hover-interactive group animate-fade-in-up delay-300 shadow-sm hover:shadow-md">
                <div className="flex items-center justify-between">
                  <span className="h-10 w-10 rounded-xl bg-[#002855] text-white flex items-center justify-center font-black font-mono text-sm shadow-sm group-hover:scale-110 group-hover:bg-[#C88A2C] transition-all">
                    03
                  </span>
                  <span className="text-[11px] font-bold text-emerald-600 bg-emerald-500/10 px-2 py-0.5 rounded-md">
                    الانطلاق
                  </span>
                </div>
                <h4 className="font-bold text-base text-[#001F3F] dark:text-white group-hover:text-[#002855] dark:group-hover:text-[#C88A2C] transition-colors">
                  ابدأ بإدارة العملية التعليمية
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  انشر الجداول، ابدأ برصد الحضور بالباركود، وانشر الامتحانات والواجبات.
                </p>
              </div>

              {/* Step 04 */}
              <div className="p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#001F3F] text-right space-y-3.5 card-hover-interactive group animate-fade-in-up delay-400 shadow-sm hover:shadow-md">
                <div className="flex items-center justify-between">
                  <span className="h-10 w-10 rounded-xl bg-[#002855] text-white flex items-center justify-center font-black font-mono text-sm shadow-sm group-hover:scale-110 group-hover:bg-[#C88A2C] transition-all">
                    04
                  </span>
                  <span className="text-[11px] font-bold text-purple-600 bg-purple-500/10 px-2 py-0.5 rounded-md">
                    المتابعة
                  </span>
                </div>
                <h4 className="font-bold text-base text-[#001F3F] dark:text-white group-hover:text-[#002855] dark:group-hover:text-[#C88A2C] transition-colors">
                  تابع الأداء والنتائج
                </h4>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  استخرج التقارير الأكاديمية اللحظية وشارك أولياء الأمور مستجدات تقدم أبنائهم.
                </p>
              </div>

            </div>
          </div>

        </div>
      </section>

      {/* 12. Animated Statistics Section (Solid Dark Blue Section with Fast Live Count-Up) */}
      <section className="py-12 md:py-14 bg-[#002855] text-white relative overflow-hidden">
        
        {/* Subtle geometric line grid accent */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:32px_32px] pointer-events-none"></div>

        <div className="container max-w-5xl mx-auto px-4 sm:px-6 relative z-10">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 md:gap-8 text-center">
            
            {/* Stat 1: Students */}
            <div className="space-y-1 group">
              <div className="text-3xl sm:text-4xl lg:text-5xl font-black text-white transition-transform group-hover:scale-105 duration-300">
                <CountUpNumber end={500} duration={1600} prefix="+" />
              </div>
              <div className="text-sm sm:text-base font-bold text-[#C88A2C]">طالب</div>
              <p className="text-[11px] sm:text-xs text-slate-300">يتعلمون وينظمون يومهم</p>
            </div>

            {/* Stat 2: Teachers */}
            <div className="space-y-1 group">
              <div className="text-3xl sm:text-4xl lg:text-5xl font-black text-white transition-transform group-hover:scale-105 duration-300">
                <CountUpNumber end={50} duration={1400} prefix="+" />
              </div>
              <div className="text-sm sm:text-base font-bold text-[#C88A2C]">مدرس</div>
              <p className="text-[11px] sm:text-xs text-slate-300">يديرون حصصهم بكفاءة</p>
            </div>

            {/* Stat 3: Centers */}
            <div className="space-y-1 group">
              <div className="text-3xl sm:text-4xl lg:text-5xl font-black text-white transition-transform group-hover:scale-105 duration-300">
                <CountUpNumber end={20} duration={1200} prefix="+" />
              </div>
              <div className="text-sm sm:text-base font-bold text-[#C88A2C]">مركز تعليمي</div>
              <p className="text-[11px] sm:text-xs text-slate-300">يعتمدون النظام رقمياً</p>
            </div>

            {/* Stat 4: Lessons & Activities */}
            <div className="space-y-1 group">
              <div className="text-3xl sm:text-4xl lg:text-5xl font-black text-white transition-transform group-hover:scale-105 duration-300">
                <CountUpNumber end={10000} duration={2000} prefix="+" />
              </div>
              <div className="text-sm sm:text-base font-bold text-[#C88A2C]">درس ونشاط</div>
              <p className="text-[11px] sm:text-xs text-slate-300">تم إنجازها عبر المنصة</p>
            </div>

          </div>
        </div>
      </section>

      {/* 13. Platform Ecosystem Visual Section */}
      <section className="py-20 border-t border-border/60 bg-white dark:bg-[#001428] px-4 sm:px-6">
        <div className="container max-w-5xl mx-auto text-center space-y-4">
          <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase">
            الترابط الرقمي
          </span>
          <h2 className="text-3xl sm:text-4xl font-black text-[#001F3F] dark:text-white font-display">
            منظومة متكاملة تضمن تناغم الجميع
          </h2>
          <p className="text-muted-foreground text-sm max-w-xl mx-auto">
            لا معزل بين الإدارة والأستاذ، ولا فجوة بين الطالب والأسرة. منصة روّاد تجعل تدفق البيانات حياً ومتواصلاً.
          </p>
          <EcosystemSection />
        </div>
      </section>

      {/* 14. Analytics & Decision Making Section */}
      <section className="py-20 border-t border-border/60 bg-white dark:bg-[#001428] px-4 sm:px-6">
        <div className="container max-w-5xl mx-auto space-y-8 text-center">
          <div className="max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase">
              الذكاء الأكاديمي
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-[#001F3F] dark:text-white font-display">
              قرارات أفضل تبدأ من بيانات أوضح
            </h2>
            <p className="text-muted-foreground text-sm sm:text-base leading-relaxed">
              تمنحك لوحة التحليلات في روّاد رؤية فورية لمستوى كل فوج، نسب الحضور، ومؤشرات النجاح،
              مما يتيح التدخل التربوي السريع ودعم الطلاب قبل حلول الامتحانات الرسمية.
            </p>
          </div>
          <AnalyticsSectionMockup />
        </div>
      </section>

      {/* 15. Communication Section */}
      <section className="py-20 border-t border-border/60 bg-white dark:bg-[#001428] px-4 sm:px-6">
        <div className="container max-w-5xl mx-auto space-y-8 text-center">
          <div className="max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase">
              التواصل الفوري
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-[#001F3F] dark:text-white font-display">
              تواصل أفضل بين المركز والأسرة
            </h2>
            <p className="text-muted-foreground text-sm sm:text-base leading-relaxed">
              إشعارات فورية بكل ما يهم ولي الأمر: حضور الحصة، نتائج الامتحانات، نشر الواجبات، والإعلانات
              الخاصة، حتى لا يضطر الأهل للانتظار حتى نهاية الفصل لمعرفة مستوى أبنائهم.
            </p>
          </div>
          <CommunicationMockup />
        </div>
      </section>

      {/* 16. Mobile Experience Section */}
      <section className="py-20 border-t border-border/60 bg-white dark:bg-[#001428] px-4 sm:px-6">
        <div className="container max-w-5xl mx-auto text-center space-y-12">
          <div className="max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase">
              تجربة مستخدم مرنة
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-[#001F3F] dark:text-white font-display">
              تجربتك التعليمية أينما كنت
            </h2>
            <p className="text-muted-foreground text-sm sm:text-base leading-relaxed">
              واجهات متجاوبة ومتقنة تعمل بسلاسة فائقة على الهواتف والأجهزة اللوحية وحواسيب المكاتب.
            </p>
          </div>
          <MobileExperienceFrames />
        </div>
      </section>

      {/* 17. Security & Trust Section (Honest Prototype Trust) */}
      <section className="py-16 border-t border-border/60 bg-white dark:bg-[#001428] px-4 sm:px-6">
        <div className="container max-w-5xl mx-auto space-y-8 text-center">
          <div className="max-w-2xl mx-auto space-y-2">
            <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase">
              الموثوقية والتنظيم
            </span>
            <h3 className="text-2xl sm:text-3xl font-black text-[#001F3F] dark:text-white font-display">
              بيئة تعليمية منظمة وموثوقة
            </h3>
            <p className="text-xs sm:text-sm text-muted-foreground">
              بنية برمجية مهيكلة تضمن خصوصية المستخدمين وتمنح كل طرف صلاحيات محددة بدقة.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            <div className="p-4 rounded-xl border border-border/80 bg-card space-y-2">
              <Shield className="h-5 w-5 text-[#002855]" />
              <h5 className="font-bold text-sm">صلاحيات حسب الدور</h5>
              <p className="text-xs text-muted-foreground">
                عزل كامل بين لوحة الإدارة، فضاء المدرس، ملف الطالب، وحساب ولي الأمر.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-border/80 bg-card space-y-2">
              <FileSpreadsheet className="h-5 w-5 text-violet-600" />
              <h5 className="font-bold text-sm">تنظيم البيانات الأكاديمية</h5>
              <p className="text-xs text-muted-foreground">
                هيكلة واضحة للدرجات وكشوفات النقاط والمقررات دون تداخل أو فقدان.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-border/80 bg-card space-y-2">
              <Bell className="h-5 w-5 text-emerald-600" />
              <h5 className="font-bold text-sm">إشعارات واضحة ودقيقة</h5>
              <p className="text-xs text-muted-foreground">
                تنبيهات لحظية مؤكدة بالوصول، الغياب، والنتائج دون تشتيت.
              </p>
            </div>

            <div className="p-4 rounded-xl border border-border/80 bg-card space-y-2">
              <CheckCircle2 className="h-5 w-5 text-amber-500" />
              <h5 className="font-bold text-sm">تجربة آمنة ومنظمة</h5>
              <p className="text-xs text-muted-foreground">
                بيئة متكاملة تضمن تجربة استخدام احترافية وسلسة لكافة أفراد المنظومة.
              </p>
            </div>

          </div>
        </div>
      </section>

      {/* 18. Testimonials Section (Clean Avatar Shapes, No Stock Photos) */}
      <section id="testimonials" className="py-20 border-t border-border/60 bg-white dark:bg-[#001428] px-4 sm:px-6">
        <div className="container max-w-5xl mx-auto space-y-12 text-center">
          
          <div className="max-w-xl mx-auto space-y-2">
            <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase">
              آراء المستخدمين
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-[#001F3F] dark:text-white font-display">
              ماذا يقول مستخدمو روّاد؟
            </h2>
            <p className="text-muted-foreground text-sm">
              تجارب حقيقية من مديري المراكز، الأساتذة، الطلاب، وأولياء الأمور.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 text-right">
            
            <div className="p-5 rounded-2xl border border-border/80 bg-card flex flex-col justify-between space-y-4 card-hover-interactive">
              <p className="text-xs text-muted-foreground leading-relaxed">
                "وفّرت منصة روّاد على فريقنا الإداري أكثر من 15 ساعة أسبوعياً كنا نقضيها في الجداول
                الورقية ومتابعة الغيابات. أصبح كل شيء رقمياً ومنظماً."
              </p>
              <div className="flex items-center gap-3 pt-3 border-t border-border/60">
                <div className="h-9 w-9 rounded-full bg-[#002855]/10 dark:bg-[#001428] text-[#001F3F] dark:text-[#C88A2C] font-bold grid place-items-center text-xs">
                  م.ر
                </div>
                <div>
                  <div className="text-xs font-bold">أ. مصطفى رحماني</div>
                  <div className="text-[10px] text-muted-foreground">مدير مركز تعليمي</div>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-border/80 bg-card flex flex-col justify-between space-y-4 card-hover-interactive">
              <p className="text-xs text-muted-foreground leading-relaxed">
                "ميزة مسح الحضور بالباركود ونشر الواجبات مباشرة جعلتني أركز على الشرح وإيصال المعلومة،
                ولم أعد أضيع وقت الحصة في النداء الورقي."
              </p>
              <div className="flex items-center gap-3 pt-3 border-t border-border/60">
                <div className="h-9 w-9 rounded-full bg-violet-100 dark:bg-violet-950 text-violet-700 dark:text-violet-300 font-bold grid place-items-center text-xs">
                  أ.ع
                </div>
                <div>
                  <div className="text-xs font-bold">أ. أحمد بن علي</div>
                  <div className="text-[10px] text-muted-foreground">أستاذ مادة الرياضيات</div>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-border/80 bg-card flex flex-col justify-between space-y-4 card-hover-interactive">
              <p className="text-xs text-muted-foreground leading-relaxed">
                "كولي أمر، الإشعار الفوري الذي يصلني بمجرد وصول ابني للمركز يمنحني راحة بال واطمئناناً
                تاماً، فضلاً عن متابعة علاماته دون مفاجآت."
              </p>
              <div className="flex items-center gap-3 pt-3 border-t border-border/60">
                <div className="h-9 w-9 rounded-full bg-amber-100 dark:bg-amber-950 text-amber-700 dark:text-amber-300 font-bold grid place-items-center text-xs">
                  ك.أ
                </div>
                <div>
                  <div className="text-xs font-bold">كريم الأمين</div>
                  <div className="text-[10px] text-muted-foreground">ولي أمر طالبين</div>
                </div>
              </div>
            </div>

            <div className="p-5 rounded-2xl border border-border/80 bg-card flex flex-col justify-between space-y-4 card-hover-interactive">
              <p className="text-xs text-muted-foreground leading-relaxed">
                "تطبيق روّاد هو مفكرتي اليومية للبكالوريا. أعرف بالضبط واجبي القادم وموعد امتحاني،
                ومعدلي يتحسن بوضوح مع كل تمرين منجز."
              </p>
              <div className="flex items-center gap-3 pt-3 border-t border-border/60">
                <div className="h-9 w-9 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold grid place-items-center text-xs">
                  ي.أ
                </div>
                <div>
                  <div className="text-xs font-bold">يوسف الأمين</div>
                  <div className="text-[10px] text-muted-foreground">طالب 3 ثانوي</div>
                </div>
              </div>
            </div>

          </div>

        </div>
      </section>

      {/* 19. Pricing Section (Center Plan Highlighted) */}
      <section id="pricing" className="py-20 border-t border-border/60 bg-white dark:bg-[#001428] px-4 sm:px-6">
        <div className="container max-w-5xl mx-auto text-center space-y-12">
          
          <div className="max-w-xl mx-auto space-y-2">
            <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase">
              اشتراكات شفافة
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-[#001F3F] dark:text-white font-display">
              خطة تناسب احتياجاتك
            </h2>
            <p className="text-muted-foreground text-sm">
              اختر الخطة المناسبة لحجم نشاطك التعليمي دون أي تكاليف خفية.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-right items-stretch">
            
            {/* Plan 1: Teacher */}
            <div className="p-6 rounded-2xl border border-border/80 bg-card flex flex-col justify-between space-y-6 card-hover-interactive">
              <div className="space-y-4">
                <div className="space-y-1">
                  <h4 className="text-lg font-bold font-display">خطة المدرس</h4>
                  <p className="text-xs text-muted-foreground">للأساتذة المستقلين والمجموعات الخاصة</p>
                </div>
                <div className="font-mono">
                  <span className="text-3xl font-black text-foreground">4,500</span>
                  <span className="text-xs text-muted-foreground"> د.ج / شهرياً</span>
                </div>
                <ul className="space-y-2.5 text-xs text-muted-foreground pt-2">
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-[#002855]" />
                    حتى 100 طالب مسجل
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-[#002855]" />
                    جداول الحصص وتسجيل الحضور
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-[#002855]" />
                    رفع التمارين والامتحانات
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-[#002855]" />
                    رصد الدرجات وإصدار الكشوف
                  </li>
                </ul>
              </div>
              <button
                onClick={() => toast.info("تم اختيار خطة المدرس التجريبية")}
                className="btn-secondary w-full"
              >
                اختر خطة المدرس
              </button>
            </div>

            {/* Plan 2: Center (Highlighted - Most Popular) */}
            <div className="p-6 rounded-2xl border-2 border-[#002855] bg-card shadow-xl shadow-[#002855]/10 flex flex-col justify-between space-y-6 relative card-hover-interactive">
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 bg-[#002855] text-white px-3 py-0.5 rounded-full text-[11px] font-bold">
                الأكثر اختياراً
              </div>
              <div className="space-y-4">
                <div className="space-y-1">
                  <h4 className="text-lg font-bold font-display">خطة المركز</h4>
                  <p className="text-xs text-muted-foreground">للمراكز التعليمية ومعاهد الدروس المسائية</p>
                </div>
                <div className="font-mono">
                  <span className="text-3xl font-black text-[#002855]">12,000</span>
                  <span className="text-xs text-muted-foreground"> د.ج / شهرياً</span>
                </div>
                <ul className="space-y-2.5 text-xs text-muted-foreground pt-2">
                  <li className="flex items-center gap-2 font-medium text-foreground">
                    <Check className="h-3.5 w-3.5 text-[#002855] stroke-[3]" />
                    عدد غير محدود من الطلاب والأساتذة
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-[#002855]" />
                    لوحة تحكم إدارية ومحاسبية كاملة
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-[#002855]" />
                    حسابات مستقلة لأولياء الأمور
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-[#002855]" />
                    تسجيل الحضور بالباركود التلقائي
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-[#002855]" />
                    إشعارات فورية وتقارير أكاديمية متقدمة
                  </li>
                </ul>
              </div>
              <button
                onClick={() => toast.success("تم تفعيل طلب التجربة المجانية لخطة المركز")}
                className="btn-primary w-full"
              >
                ابدأ تجربة المركز الآن
              </button>
            </div>

            {/* Plan 3: Enterprise */}
            <div className="p-6 rounded-2xl border border-border/80 bg-card flex flex-col justify-between space-y-6 card-hover-interactive">
              <div className="space-y-4">
                <div className="space-y-1">
                  <h4 className="text-lg font-bold font-display">خطة المؤسسة</h4>
                  <p className="text-xs text-muted-foreground">لشبكات المدارس والفروع المتعددة</p>
                </div>
                <div className="font-mono">
                  <span className="text-3xl font-black text-foreground">مخصصة</span>
                  <span className="text-xs text-muted-foreground"> / سنوي</span>
                </div>
                <ul className="space-y-2.5 text-xs text-muted-foreground pt-2">
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-[#002855]" />
                    ربط عدة فروع ومقرات في منصة واحدة
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-[#002855]" />
                    خادم مخصص وهوية بصرية مخصصة
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-[#002855]" />
                    ربط برمجي API مع أنظمتكم الحالية
                  </li>
                  <li className="flex items-center gap-2">
                    <Check className="h-3.5 w-3.5 text-[#002855]" />
                    دعم فني مخصص على مدار 24/7
                  </li>
                </ul>
              </div>
              <a
                href="#contact"
                className="btn-secondary w-full"
              >
                تواصل لتخصيص الخطة
              </a>
            </div>

          </div>

          <p className="text-xs text-muted-foreground">
            * جميع الخطط تشمل فترة تجريبية مجانية لمدة 14 يوماً مع كامل الخصائص.
          </p>

        </div>
      </section>

      {/* 20. Interactive FAQ Section (Working Accordion) */}
      <section id="faq" className="py-20 border-t border-border/60 px-4 sm:px-6">
        <div className="container max-w-3xl mx-auto space-y-8 text-center">
          
          <div className="space-y-2 max-w-xl mx-auto">
            <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase">
              تساؤلات شائعة
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-[#001F3F] dark:text-white font-display">
              الأسئلة الشائعة
            </h2>
            <p className="text-muted-foreground text-sm">
              إجابات مباشرة وواضحة حول منصة روّاد وكيفية الاستفادة منها.
            </p>
          </div>

          <FaqAccordion />

        </div>
      </section>

      {/* 21. Strong Editorial Cinematic CTA Section */}
      <RevealSection className="py-24 border-t border-slate-200 dark:border-white/10 bg-white dark:bg-[#001428] px-4 sm:px-6 relative overflow-hidden">
        {/* Subtle ambient background glow */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[38rem] h-[38rem] rounded-full bg-[#002855]/5 dark:bg-white/5 blur-3xl pointer-events-none"></div>

        <div className="container max-w-4xl mx-auto text-center space-y-7 relative z-10">
          
          <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#C88A2C]/10 border border-[#C88A2C]/30 text-xs font-bold text-[#C88A2C]">
            <span>نرافق طلاب اليوم... لنصنع روّاد الغد</span>
          </div>

          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-[#001F3F] dark:text-white font-display tracking-tight leading-[1.2]">
            جاهز لتجربة طريقة أبسط لإدارة التعليم؟
          </h2>
          
          <p className="text-base sm:text-lg text-muted-foreground max-w-xl mx-auto leading-relaxed">
            ابدأ استكشاف منصة روّاد واكتشف كيف يمكن جمع أطراف العملية التعليمية في مكان واحد
            بكل بساطة وثقة واحترافية.
          </p>

          <div className="pt-3 flex flex-col sm:flex-row items-center justify-center gap-3.5 max-w-sm mx-auto">
            <a
              href="#pricing"
              className="btn-primary w-full sm:w-auto hover:scale-105 transition-all duration-300 shadow-md hover:shadow-lg"
            >
              ابدأ الآن
            </a>
            <a
              href="#contact"
              className="btn-secondary w-full sm:w-auto hover:scale-105 transition-all duration-300"
            >
              تواصل معنا
            </a>
          </div>

        </div>
      </RevealSection>

      {/* 22. Contact Form Section (Validated, Local Simulation) */}
      <section id="contact" className="py-20 border-t border-border/60 bg-white dark:bg-[#001428] px-4 sm:px-6">
        <div className="container max-w-2xl mx-auto space-y-8 text-center">
          
          <div className="space-y-2 max-w-xl mx-auto">
            <span className="text-xs font-bold text-[#C88A2C] tracking-wider uppercase">
              نحن هنا لمساعدتك
            </span>
            <h2 className="text-3xl sm:text-4xl font-black text-[#001F3F] dark:text-white font-display">
              يسعدنا أن نسمع منك
            </h2>
            <p className="text-muted-foreground text-sm">
              املأ النموذج أدناه وسيقوم فريق روّاد بالإجابة عن استفساراتك أو إعداد جلستك التجريبية.
            </p>
          </div>

          <ContactForm />

        </div>
      </section>

      {/* 23. Premium High-Contrast Brand Footer */}
      <footer className="border-t border-[#C88A2C]/20 bg-[#001428] text-slate-300 pt-16 pb-12 px-4 sm:px-6 text-right text-xs relative overflow-hidden">
        {/* Subtle decorative gold ambient glow at the bottom */}
        <div className="absolute -bottom-20 right-1/4 w-96 h-96 rounded-full bg-[#C88A2C]/5 blur-3xl pointer-events-none"></div>
        <div className="absolute -top-20 -left-20 w-80 h-80 rounded-full bg-[#002855]/20 blur-3xl pointer-events-none"></div>

        <div className="container max-w-6xl mx-auto space-y-12 relative z-10">
          
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
            
            {/* Col 1: Brand & Tagline */}
            <div className="col-span-2 space-y-4">
              <div className="flex items-center gap-3">
                <img
                  src={logoAsset.logo.url}
                  alt="شعار منصة روّاد"
                  className="h-10 w-auto object-contain brightness-110"
                />
                <span className="text-2xl font-black text-white font-display">منصة روّاد</span>
              </div>
              <p className="text-slate-400 text-xs leading-relaxed max-w-sm">
                <span className="text-[#C88A2C] font-semibold">نرافق طلاب اليوم... لنصنع روّاد الغد.</span>
                <br />
                نظام إدارة تعليمي سحابي متكامل يربط المراكز والأساتذة والطلاب وأولياء الأمور في مسار رقمي موحد وموثوق.
              </p>
              <div className="pt-2 flex items-center gap-3 text-slate-400">
                <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-[11px] text-[#C88A2C]">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                  المنظومة الرقمية النشطة 2026
                </span>
              </div>
            </div>

            {/* Col 2: Navigation Links */}
            <div className="space-y-3">
              <div className="font-bold text-white text-sm font-display tracking-wide text-[#C88A2C]">المنصة</div>
              <ul className="space-y-2 text-slate-400 text-xs">
                <li><a href="#about" className="hover:text-white transition-colors">الرئيسية</a></li>
                <li><a href="#solution" className="hover:text-white transition-colors">المميزات والحلول</a></li>
                <li><a href="#pricing" className="hover:text-white transition-colors">خطط الاشتراكات</a></li>
                <li><a href="#faq" className="hover:text-white transition-colors">الأسئلة الشائعة</a></li>
                <li><a href="#contact" className="hover:text-white transition-colors">تواصل مع الإدارة</a></li>
              </ul>
            </div>

            {/* Col 3: Role Links */}
            <div className="space-y-3">
              <div className="font-bold text-white text-sm font-display tracking-wide text-[#C88A2C]">بوابات الدخول</div>
              <ul className="space-y-2 text-slate-400 text-xs">
                <li><Link to="/center" className="hover:text-white transition-colors">إدارة المركز التعليمي</Link></li>
                <li><Link to="/teacher" className="hover:text-white transition-colors">فضاء المدرس والأستاذ</Link></li>
                <li><Link to="/student" className="hover:text-white transition-colors">لوحة الطالب والمقررات</Link></li>
                <li><Link to="/parent" className="hover:text-white transition-colors">حساب ولي الأمر والتقارير</Link></li>
                <li><Link to="/login" className="hover:text-white transition-colors">تسجيل الدخول الموحد</Link></li>
              </ul>
            </div>

            {/* Col 4: Support */}
            <div className="space-y-3">
              <div className="font-bold text-white text-sm font-display tracking-wide text-[#C88A2C]">الدعم والتواصل</div>
              <ul className="space-y-2 text-slate-400 text-xs">
                <li><a href="#faq" className="hover:text-white transition-colors">مركز الإرشادات</a></li>
                <li><a href="#contact" className="hover:text-white transition-colors">حجز جلسة تجريبية</a></li>
                <li className="text-slate-300 font-mono text-[11px] pt-1">contact@rowad.edu.dz</li>
                <li className="text-slate-300 font-mono text-[11px]" dir="ltr">+213 (0) 555 12 34 56</li>
              </ul>
            </div>

          </div>

          {/* Bottom copyright line */}
          <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-slate-400 text-[11px]">
            <div>
              © 2026 <span className="text-white font-bold">منصة روّاد</span> — جميع الحقوق محفوظة. مشروع تخرج جامعي متميز ونواة منصة ريادية وطنية.
            </div>
            <div className="flex items-center gap-5 text-slate-400">
              <a href="#about" className="hover:text-[#C88A2C] transition-colors">سياسة الخصوصية</a>
              <span className="text-white/20">•</span>
              <a href="#about" className="hover:text-[#C88A2C] transition-colors">شروط الاستخدام والأمان</a>
              <span className="text-white/20">•</span>
              <a href="#about" className="hover:text-[#C88A2C] transition-colors">الجزائر 🇩🇿</a>
            </div>
          </div>

        </div>
      </footer>

    </div>
  );
}

// ----------------------------------------------------
// Sub-components: Interactive FAQ & Validated Contact Form
// ----------------------------------------------------

function FaqAccordion() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: "ما هي منصة روّاد؟",
      a: "روّاد هي منصة سحابية (SaaS) متكاملة صممت لإدارة المؤسسات والمراكز التعليمية والدروس الخصوصية، تجمع بين مديري المراكز، الأساتذة، الطلاب، وأولياء الأمور في واجهة موحدة لمتابعة كافة جوانب العملية التربوية.",
    },
    {
      q: "من يمكنه استخدام المنصة؟",
      a: "المنصة مصممة لأربعة أطراف أساسية: إدارات المراكز التعليمية لتنظيم التسجيل والعمليات، الأساتذة لإدارة الدروس والواجبات والحضور، الطلاب لمتابعة مقرراتهم وواجباتهم، وأولياء الأمور للاطلاع اللحظي على أداء أبنائهم.",
    },
    {
      q: "هل يمكن للمراكز إدارة الطلاب والمدرسين؟",
      a: "نعم بالتأكيد. تمنح لوحة تحكم المركز صلاحيات كاملة لإضافة وحذف الطلاب والأساتذة، تنظيمهم ضمن أفواج وقاعات، متابعة جداول الحصص الأسبوعية، واستخراج إحصائيات دقيقة عن الأداء والمالية.",
    },
    {
      q: "هل يستطيع ولي الأمر متابعة أكثر من طفل؟",
      a: "نعم. يمكن لولي الأمر عبر حساب واحد التبديل بين جميع أبنائه المسجلين في المركز، ومعاينة جدول حضور كل ابن، نتائجه الفردية، واجباته، والملاحظات التربوية الخاصة به في شاشة واحدة.",
    },
    {
      q: "هل يستطيع المدرس إدارة الواجبات والاختبارات؟",
      a: "بكل تأكيد. يستطيع الأستاذ رفع ملفات التمارين وتحديد مواعيد التسليم، وإجراء الاختبارات ورصد الدرجات مباشرة، لتظهر النتائج بشكل آلي في كشوف الطلاب وإشعارات أولياء الأمور.",
    },
    {
      q: "هل المنصة مناسبة للمدرسين المستقلين؟",
      a: "نعم، توفر خطة المدرس حلاً مستقلاً للأساتذة الذين يقدمون دروساً خصوصية فردية أو جماعية، لتمكينهم من تسجيل طلابهم وجداولهم ومتابعة واجباتهم دون الحاجة لمركز تعليمي وسيط.",
    },
    {
      q: "هل يمكن تجربة المنصة؟",
      a: "نعم، يمكنك تجربة جميع لوحات التحكم والأدوار مباشرة من خلال أزرار استكشاف المنصة، كما نوفر فترة تجريبية مجانية للمراكز الجديدة لمدة 14 يوماً مع كامل الصلاحيات.",
    },
  ];

  return (
    <div className="space-y-3">
      {faqs.map((item, idx) => {
        const isOpen = openIndex === idx;
        return (
          <div
            key={idx}
            className="rounded-xl border border-border/80 bg-card overflow-hidden transition-colors"
          >
            <button
              onClick={() => setOpenIndex(isOpen ? null : idx)}
              className="w-full p-4 text-right flex items-center justify-between gap-3 font-bold text-sm hover:bg-muted/30 transition-colors"
            >
              <span>{item.q}</span>
              <ChevronDown
                className={cn(
                  "h-4 w-4 text-muted-foreground transition-transform duration-200 shrink-0",
                  isOpen && "rotate-180 text-[#002855]"
                )}
              />
            </button>
            {isOpen && (
              <div className="px-4 pb-4 pt-1 text-xs text-muted-foreground leading-relaxed border-t border-border/40">
                {item.a}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function ContactForm() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [userType, setUserType] = useState("");
  const [message, setMessage] = useState("");

  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newErrors: Record<string, string> = {};

    if (!name.trim()) {
      newErrors.name = "يرجى إدخال الاسم";
    }

    if (!email.trim() || !email.includes("@") || !email.includes(".")) {
      newErrors.email = "يرجى إدخال بريد إلكتروني صحيح";
    }

    if (!userType) {
      newErrors.userType = "يرجى اختيار نوع المستخدم";
    }

    if (!message.trim()) {
      newErrors.message = "يرجى كتابة رسالتك";
    }

    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setErrors({});
    setLoading(true);

    // Simulate sending local request
    setTimeout(() => {
      setLoading(false);
      toast.success("تم إرسال رسالتك بنجاح، وسنتواصل معك قريباً.");
      setName("");
      setEmail("");
      setPhone("");
      setUserType("");
      setMessage("");
    }, 1200);
  };

  return (
    <form
      onSubmit={handleSubmit}
      className="p-6 rounded-2xl border border-border/80 bg-card space-y-4"
    >
      {/* Name */}
      <div className="space-y-1">
        <label className="text-xs font-semibold text-foreground">الاسم الكامل *</label>
        <input
          type="text"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="مثال: كريم رحماني"
          className={cn(
            "w-full px-3.5 py-2 text-xs rounded-xl border bg-background focus:outline-none focus:ring-1 focus:ring-[#002855] transition-colors",
            errors.name ? "border-rose-500" : "border-border"
          )}
        />
        {errors.name && <p className="text-[11px] text-rose-500">{errors.name}</p>}
      </div>

      {/* Email & Phone Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-1">
          <label className="text-xs font-semibold text-foreground">البريد الإلكتروني *</label>
          <input
            type="email"
            dir="ltr"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="name@example.com"
            className={cn(
              "w-full px-3.5 py-2 text-xs rounded-xl border bg-background focus:outline-none focus:ring-1 focus:ring-[#002855] transition-colors text-right",
              errors.email ? "border-rose-500" : "border-border"
            )}
          />
          {errors.email && <p className="text-[11px] text-rose-500">{errors.email}</p>}
        </div>

        <div className="space-y-1">
          <label className="text-xs font-semibold text-foreground">رقم الهاتف</label>
          <input
            type="tel"
            dir="ltr"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="+213 555 00 00 00"
            className="w-full px-3.5 py-2 text-xs rounded-xl border border-border bg-background focus:outline-none focus:ring-1 focus:ring-[#002855] transition-colors text-right"
          />
        </div>
      </div>

      {/* User Type Select */}
      <div className="space-y-1">
        <label className="text-xs font-semibold text-foreground">نوع المستخدم *</label>
        <select
          value={userType}
          onChange={(e) => setUserType(e.target.value)}
          className={cn(
            "w-full px-3.5 py-2 text-xs rounded-xl border bg-background focus:outline-none focus:ring-1 focus:ring-[#002855] transition-colors cursor-pointer",
            errors.userType ? "border-rose-500" : "border-border"
          )}
        >
          <option value="">-- يرجى الاختيار --</option>
          <option value="center">مدير مركز تعليمي أو مدرسة خاصة</option>
          <option value="teacher">أستاذ أو مدرس دروس خصوصية</option>
          <option value="parent">ولي أمر طالب</option>
          <option value="student">طالب</option>
          <option value="other">شريك أو مستثمر</option>
        </select>
        {errors.userType && <p className="text-[11px] text-rose-500">{errors.userType}</p>}
      </div>

      {/* Message */}
      <div className="space-y-1">
        <label className="text-xs font-semibold text-foreground">الرسالة أو الاستفسار *</label>
        <textarea
          rows={4}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="أخبرنا عن متطلبات مركزك أو استفسارك..."
          className={cn(
            "w-full px-3.5 py-2 text-xs rounded-xl border bg-background focus:outline-none focus:ring-1 focus:ring-[#002855] transition-colors resize-none",
            errors.message ? "border-rose-500" : "border-border"
          )}
        />
        {errors.message && <p className="text-[11px] text-rose-500">{errors.message}</p>}
      </div>

      {/* Submit Button */}
      <button
        type="submit"
        disabled={loading}
        className="btn-primary w-full disabled:opacity-70"
      >
        {loading ? (
          <>
            <Loader2 className="h-4 w-4 animate-spin" />
            جاري الإرسال...
          </>
        ) : (
          <>
            <Send className="h-3.5 w-3.5 -rotate-90" />
            إرسال الرسالة
          </>
        )}
      </button>
    </form>
  );
}

