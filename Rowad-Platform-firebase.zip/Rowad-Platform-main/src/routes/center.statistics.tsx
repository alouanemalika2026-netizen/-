import { createFileRoute } from "@tanstack/react-router";
import { StatCard } from "@/components/dashboard/StatCard";
import { GrowthChart, RevenueChart, SubjectPie, ProgressLine } from "@/components/dashboard/charts";
import { GraduationCap, UserCog, ClipboardCheck, Trophy } from "lucide-react";

export const Route = createFileRoute("/center/statistics")({
  component: () => (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold">الإحصائيات</h1>
        <p className="mt-1 text-sm text-muted-foreground">مؤشرات الأداء الرئيسية.</p>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={GraduationCap} label="نمو الطلاب" value="+15%" tone="purple" />
        <StatCard icon={UserCog} label="أداء الأساتذة" value="4.8/5" tone="pink" />
        <StatCard icon={ClipboardCheck} label="متوسط الحضور" value="94%" tone="blue" />
        <StatCard icon={Trophy} label="متوسط النقاط" value="14.8" tone="orange" />
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <GrowthChart />
        <SubjectPie />
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <RevenueChart />
        <ProgressLine />
      </div>
    </div>
  ),
});
