import { createFileRoute } from "@tanstack/react-router";
import { ChatPage } from "@/components/dashboard/ChatPage";

export const Route = createFileRoute("/parent/messages")({
  component: () => (
    <ChatPage title="الرسائل" description="تواصل مباشر مع أساتذة أبنائك" contactsCollection="teachers" />
  ),
});
