import { createFileRoute } from "@tanstack/react-router";
import {
  GraduationCap,
  ClipboardCheck,
  CalendarDays,
  Award,
  TrendingUp,
  Search,
  Bell,
  CheckCircle2,
} from "lucide-react";

export const Route = createFileRoute("/center/")({
  component: CenterDashboard,
});

function CenterDashboard() {
  return (
    <div className="space-y-6 text-right">
      
      {/* Top Welcome / Status Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200/80 dark:border-white/10">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-2xl sm:text-3xl font-black text-[#001F3F] dark:text-white font-display">
              نظرة عامة على النشاط اليومي
            </h1>
            <span className="text-xs text-[#002855] dark:text-[#C88A2C] font-semibold bg-[#002855]/5 dark:bg-white/5 px-3 py-1 rounded-full border border-[#002855]/10 dark:border-white/10">
              الأحد، 3 سبتمبر 2026
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            جميع العمليات تسير بانتظام • تم تسجيل 96.2% نسبة حضور
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="relative">
            <span className="absolute inset-y-0 right-0 flex items-center pr-3 pointer-events-none text-muted-foreground">
              <Search className="h-4 w-4" />
            </span>
            <input
              type="text"
              placeholder="بحث عن طالب أو فوج..."
              className="h-10 pr-9 pl-3 text-xs rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-[#001F3F] text-foreground w-48 sm:w-64 focus:outline-none focus:ring-2 focus:ring-[#002855]"
            />
          </div>
          <div className="relative p-2.5 rounded-xl border border-slate-200 dark:border-white/15 bg-white dark:bg-[#001F3F] text-foreground cursor-pointer hover:bg-slate-50 dark:hover:bg-[#001428]">
            <Bell className="h-4 w-4" />
            <span className="absolute top-2 right-2 h-2 w-2 rounded-full bg-[#C88A2C]"></span>
          </div>
        </div>
      </div>

      {/* 4 Primary Metric Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Total Students */}
        <div className="p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#001F3F] shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-bold text-foreground">إجمالي الطلاب</span>
            <div className="h-8 w-8 rounded-lg bg-[#002855]/5 text-[#002855] dark:text-[#C88A2C] grid place-items-center">
              <GraduationCap className="h-4 w-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-[#002855] dark:text-white font-mono">542</div>
          <div className="flex items-center gap-1.5 text-xs text-emerald-600 font-bold">
            <TrendingUp className="h-3.5 w-3.5" />
            <span>+18% هذا الفصل</span>
          </div>
        </div>

        {/* Card 2: Attendance Rate */}
        <div className="p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#001F3F] shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-bold text-foreground">نسبة الحضور</span>
            <div className="h-8 w-8 rounded-lg bg-emerald-500/10 text-emerald-600 grid place-items-center">
              <ClipboardCheck className="h-4 w-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-emerald-600 font-mono">96.4%</div>
          <div className="text-xs text-muted-foreground">
            522 طالب حاضر اليوم
          </div>
        </div>

        {/* Card 3: Completed Classes */}
        <div className="p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#001F3F] shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-bold text-foreground">الحصص المكتملة</span>
            <div className="h-8 w-8 rounded-lg bg-blue-500/10 text-blue-600 grid place-items-center">
              <CalendarDays className="h-4 w-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-[#001F3F] dark:text-white font-mono">24 / 28</div>
          <div className="text-xs text-blue-600 dark:text-blue-400 font-bold">
            4 حصص جارية الآن
          </div>
        </div>

        {/* Card 4: Term Average */}
        <div className="p-5 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#001F3F] shadow-sm space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span className="font-bold text-foreground">المعدل الفصلي</span>
            <div className="h-8 w-8 rounded-lg bg-[#C88A2C]/10 text-[#C88A2C] grid place-items-center">
              <Award className="h-4 w-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-[#C88A2C] font-mono">
            15.8 <span className="text-xs font-normal text-muted-foreground">/ 20</span>
          </div>
          <div className="text-xs text-emerald-600 font-bold">
            مستوى متقدم
          </div>
        </div>

      </div>

      {/* Middle Section: Attendance Chart + Upcoming Classes */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        
        {/* Weekly Attendance Bars Card */}
        <div className="lg:col-span-7 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#001F3F] shadow-sm flex flex-col justify-between space-y-5">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-[#001F3F] dark:text-white font-display">
                معدل الحضور والانضباط الأسبوعي
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                مقارنة بين جميع الأفواج الدراسية
              </p>
            </div>
            <span className="text-xs font-bold text-[#C88A2C] bg-[#C88A2C]/10 border border-[#C88A2C]/30 px-3 py-1 rounded-full">
              الأسبوع الحالي
            </span>
          </div>

          <div className="space-y-4 pt-1">
            <div>
              <div className="flex justify-between text-xs font-semibold mb-1.5">
                <span>أفواج البكالوريا (3 ثانوي)</span>
                <span className="font-mono text-[#002855] dark:text-blue-400 font-bold">98.5%</span>
              </div>
              <div className="h-3 w-full rounded-full bg-slate-100 dark:bg-white/5 overflow-hidden">
                <div className="h-full rounded-full bg-[#002855] dark:bg-blue-500" style={{ width: "98.5%" }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1.5">
                <span>أفواج 2 ثانوي (علمي ورياضي)</span>
                <span className="font-mono text-violet-600 font-bold">94.2%</span>
              </div>
              <div className="h-3 w-full rounded-full bg-slate-100 dark:bg-white/5 overflow-hidden">
                <div className="h-full rounded-full bg-violet-600" style={{ width: "94.2%" }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1.5">
                <span>أفواج 4 متوسط (شهادة التعليم المتوسط)</span>
                <span className="font-mono text-emerald-600 font-bold">96.0%</span>
              </div>
              <div className="h-3 w-full rounded-full bg-slate-100 dark:bg-white/5 overflow-hidden">
                <div className="h-full rounded-full bg-emerald-500" style={{ width: "96.0%" }}></div>
              </div>
            </div>

            <div>
              <div className="flex justify-between text-xs font-semibold mb-1.5">
                <span>أفواج اللغات والمواد الحرة</span>
                <span className="font-mono text-[#C88A2C] font-bold">91.8%</span>
              </div>
              <div className="h-3 w-full rounded-full bg-slate-100 dark:bg-white/5 overflow-hidden">
                <div className="h-full rounded-full bg-[#C88A2C]" style={{ width: "91.8%" }}></div>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 dark:border-white/10 flex items-center justify-between text-xs text-muted-foreground">
            <span>تم التحديث تلقائياً عند مسح باركود الحضور</span>
            <span className="text-[#002855] dark:text-[#C88A2C] font-bold cursor-pointer hover:underline">
              تقرير مفصل ←
            </span>
          </div>
        </div>

        {/* Evening Classes Feed Card */}
        <div className="lg:col-span-5 p-6 rounded-2xl border border-slate-200 dark:border-white/10 bg-white dark:bg-[#001F3F] shadow-sm flex flex-col justify-between space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-[#001F3F] dark:text-white font-display">
                حصص الفترة المسائية
              </h3>
              <p className="text-xs text-muted-foreground mt-0.5">
                جدول الحصص المباشرة والجارية
              </p>
            </div>
            <span className="text-xs text-slate-500 font-mono bg-slate-100 dark:bg-white/5 px-2.5 py-1 rounded-lg">
              14:00 - 18:00
            </span>
          </div>

          <div className="space-y-3">
            <div className="p-3.5 rounded-xl border border-[#C88A2C]/30 bg-[#C88A2C]/5 flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-[#001F3F] dark:text-white">
                  رياضيات — الدوال الأصلية
                </div>
                <div className="text-[11px] text-muted-foreground mt-0.5">
                  أ. أحمد بن علي • قاعة 12
                </div>
              </div>
              <span className="text-[10px] px-2.5 py-1 rounded-full bg-[#002855] text-white font-bold shrink-0">
                جارية الآن
              </span>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50/50 dark:bg-[#001428]/40 flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-[#001F3F] dark:text-white">
                  فيزياء — الميكانيك النقطية
                </div>
                <div className="text-[11px] text-muted-foreground mt-0.5">
                  أ. سارة قاسمي • قاعة 07
                </div>
              </div>
              <span className="text-[10px] px-2.5 py-1 rounded-full bg-slate-100 dark:bg-white/10 text-muted-foreground font-mono font-bold shrink-0">
                15:30
              </span>
            </div>

            <div className="p-3.5 rounded-xl border border-slate-200 dark:border-white/10 bg-slate-50/50 dark:bg-[#001428]/40 flex items-start justify-between gap-3">
              <div>
                <div className="text-xs font-bold text-[#001F3F] dark:text-white">
                  لغة عربية — البلاغة والنقد
                </div>
                <div className="text-[11px] text-muted-foreground mt-0.5">
                  أ. خالد بوعزيز • قاعة 03
                </div>
              </div>
              <span className="text-[10px] px-2.5 py-1 rounded-full bg-slate-100 dark:bg-white/10 text-muted-foreground font-mono font-bold shrink-0">
                17:00
              </span>
            </div>
          </div>

          <div className="pt-2 text-xs text-muted-foreground flex items-center gap-2">
            <CheckCircle2 className="h-4 w-4 text-emerald-500 shrink-0" />
            <span>تم إرسال تذكير الحصة لأولياء الأمور عبر الرسائل القصيرة</span>
          </div>
        </div>

      </div>

      {/* Bottom Live Activity Notification Banner */}
      <div className="p-4 rounded-2xl bg-white dark:bg-[#001F3F] border border-[#C88A2C]/30 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
        <div className="flex items-center gap-2.5">
          <span className="h-2.5 w-2.5 rounded-full bg-[#002855] dark:bg-[#C88A2C] animate-ping"></span>
          <span className="font-bold text-[#002855] dark:text-[#C88A2C]">
            آخر نشاط مسجل:
          </span>
          <span className="text-foreground">
            تم رصد نتائج امتحان الفيزياء لفوج 3 ثانوي (متوسط الدرجات: 16.2 / 20)
          </span>
        </div>
        <span className="text-muted-foreground text-[11px] font-mono shrink-0">
          منذ 4 دقائق
        </span>
      </div>

    </div>
  );
}
