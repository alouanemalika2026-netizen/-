import { createFileRoute } from "@tanstack/react-router";
import { ChatPage } from "@/components/dashboard/ChatPage";

export const Route = createFileRoute("/teacher/messages")({
  component: () => (
    <ChatPage title="الرسائل" description="تواصل مباشر مع أولياء الأمور" contactsCollection="parents" />
  ),
});
