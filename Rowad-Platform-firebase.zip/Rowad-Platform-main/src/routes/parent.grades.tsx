import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/parent/grades")({
  component: () => (
    <DataTablePage
      title="النقاط"
      description="نقاط الأبناء"
      addLabel="-"
      collection="grades"
      columns={[
  { key: "student", label: "الابن" },
  { key: "subject", label: "المادة" },
  { key: "grade", label: "النقطة" },
  { key: "max", label: "من" },
  { key: "comment", label: "ملاحظة" },
]}
      filters={[]}
    />
  ),
});
