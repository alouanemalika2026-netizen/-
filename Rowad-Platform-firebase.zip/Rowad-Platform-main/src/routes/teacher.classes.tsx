import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/teacher/classes")({
  component: () => (
    <DataTablePage
      title="أقسامي"
      description="الأقسام التي أدرّسها"
      addLabel="إضافة قسم"
      collection="classes"
      columns={[
  { key: "name", label: "القسم" },
  { key: "students", label: "عدد الطلاب" },
  { key: "room", label: "القاعة" },
]}
      filters={[]}
    />
  ),
});
