import { createFileRoute } from "@tanstack/react-router";
import { BookOpen, ClipboardCheck, Trophy, Video } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/dashboard/StatCard";
import { ProgressLine } from "@/components/dashboard/charts";
import { useCollection } from "@/lib/db";
import { useAuth } from "@/lib/auth";
import { StatusBadge } from "@/components/dashboard/DataTablePage";
import { Progress } from "@/components/ui/progress";

export const Route = createFileRoute("/student/")({
  component: StudentDashboard,
});

function StudentDashboard() {
  const { user } = useAuth();
  const { data: timetable } = useCollection<any>("timetable");
  const { data: homework } = useCollection<any>("homework");
  const { data: grades } = useCollection<any>("grades");
  const mine = grades.filter((g) => g.student === user?.name);
  return (
    <div className="space-y-5">
      <div className="rounded-2xl bg-[#002855] p-6 text-white shadow-sm">
        <div className="text-sm opacity-90">أهلاً بك</div>
        <h1 className="mt-1 text-3xl font-black">{user?.name} 👋</h1>
        <p className="mt-2 max-w-2xl text-white/85">استمر في التقدم — معدلك الحالي 16.4/20 وأنت ضمن أفضل 15% من قسمك.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={BookOpen} label="دروسي" value="7" tone="purple" />
        <StatCard icon={ClipboardCheck} label="الحضور" value="96%" tone="teal" />
        <StatCard icon={Trophy} label="المعدل" value="16.4" tone="orange" />
        <StatCard icon={Video} label="الفيديوهات" value="42" tone="pink" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <ProgressLine />
        <Card>
          <CardHeader className="pb-2"><CardTitle>نقاطي الأخيرة</CardTitle></CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {mine.map((g) => (
                <li key={g.id}>
                  <div className="flex items-center justify-between text-sm">
                    <div className="font-semibold">{g.subject}</div>
                    <div className="font-bold text-brand-purple">{g.grade} / {g.max}</div>
                  </div>
                  <Progress value={(g.grade / g.max) * 100} className="mt-1 h-2" />
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-2"><CardTitle>جدول اليوم</CardTitle></CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {(timetable[0]?.slots ?? []).map((s, i) => (
                <li key={i} className="flex items-center justify-between rounded-lg border p-3 text-sm">
                  <div>
                    <div className="font-semibold">{s.subject}</div>
                    <div className="text-xs text-muted-foreground">{s.teacher} · قاعة {s.room}</div>
                  </div>
                  <div className="text-xs font-bold text-brand-pink">{s.time}</div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle>واجباتي</CardTitle></CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {homework.map((h) => (
                <li key={h.id} className="flex items-center justify-between rounded-lg border p-3 text-sm">
                  <div>
                    <div className="font-semibold">{h.title}</div>
                    <div className="text-xs text-muted-foreground">تسليم {h.due}</div>
                  </div>
                  <StatusBadge value={h.status} />
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
