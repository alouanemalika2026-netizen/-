import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/programs")({
  component: () => (
    <DataTablePage
      title="البرامج التعليمية"
      description="البرامج المتاحة"
      addLabel="برنامج جديد"
      collection="programs"
      columns={[
  { key: "title", label: "البرنامج" },
  { key: "target", label: "المستوى" },
  { key: "weeks", label: "الأسابيع" },
  { key: "price", label: "السعر" },
]}
      filters={[]}
    />
  ),
});
