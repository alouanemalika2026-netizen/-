import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/courses")({
  component: () => (
    <DataTablePage
      title="الدروس والمواد"
      description="المواد والمقررات"
      addLabel="إضافة درس"
      collection="courses"
      columns={[
  { key: "title", label: "الدرس" },
  { key: "subject", label: "المادة" },
  { key: "level", label: "المستوى" },
  { key: "lessons", label: "عدد الدروس" },
  { key: "duration", label: "المدة" },
]}
      filters={[]}
    />
  ),
});
