import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/student/courses")({
  component: () => (
    <DataTablePage
      title="دروسي"
      description="الدروس المسجل بها"
      addLabel="التسجيل بدرس"
      collection="courses"
      columns={[
  { key: "title", label: "الدرس" },
  { key: "subject", label: "المادة" },
  { key: "lessons", label: "عدد الدروس" },
  { key: "duration", label: "المدة" },
]}
      filters={[]}
    />
  ),
});
