import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/teacher/homework")({
  component: () => (
    <DataTablePage
      title="الواجبات"
      description="الواجبات المسندة"
      addLabel="واجب جديد"
      collection="homework"
      columns={[
  { key: "title", label: "الواجب" },
  { key: "subject", label: "المادة" },
  { key: "due", label: "تاريخ التسليم" },
  { key: "status", label: "الحالة", render: (r) => <StatusBadge value={r.status} /> },
]}
      filters={[]}
    />
  ),
});
