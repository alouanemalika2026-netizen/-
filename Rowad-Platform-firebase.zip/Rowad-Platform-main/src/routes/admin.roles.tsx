import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/admin/roles")({
  component: () => (
    <DataTablePage
      title="الأدوار والصلاحيات"
      description="إدارة الأدوار وصلاحياتها"
      addLabel="إضافة دور"
      collection="roles"
      columns={[
  { key: "name", label: "الدور" },
  { key: "users", label: "عدد المستخدمين" },
  { key: "permissions", label: "الصلاحيات" },
]}
      filters={[]}
    />
  ),
});
