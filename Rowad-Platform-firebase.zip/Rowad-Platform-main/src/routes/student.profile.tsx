import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { BookOpen, Trophy, ClipboardCheck, Video } from "lucide-react";
import { StatCard } from "@/components/dashboard/StatCard";

export const Route = createFileRoute("/student/profile")({
  component: () => (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold">ملفي الشخصي</h1>
      </div>
      <div className="grid gap-5 lg:grid-cols-3">
        <Card>
          <CardContent className="p-6 text-center">
            <Avatar className="mx-auto h-24 w-24">
              <AvatarFallback className="bg-gradient-to-br from-brand-pink to-brand-orange text-3xl font-black text-white">ي</AvatarFallback>
            </Avatar>
            <h2 className="mt-4 text-xl font-bold">يوسف الأمين</h2>
            <div className="mt-1 text-sm text-muted-foreground">طالب — 3 ثانوي</div>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              <Badge variant="outline" className="bg-brand-purple/10 text-brand-purple">متفوق</Badge>
              <Badge variant="outline" className="bg-brand-orange/10 text-brand-orange">شارة الحضور</Badge>
            </div>
          </CardContent>
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>معلوماتي</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={(e) => { e.preventDefault(); toast.success("تم حفظ الملف"); }} className="grid gap-4">
              <div className="grid gap-2 sm:grid-cols-2">
                <div className="grid gap-2"><Label>الاسم</Label><Input defaultValue="يوسف الأمين" /></div>
                <div className="grid gap-2"><Label>المستوى</Label><Input defaultValue="3 ثانوي — علوم" /></div>
                <div className="grid gap-2"><Label>البريد</Label><Input defaultValue="student@rowad.com" /></div>
                <div className="grid gap-2"><Label>ولي الأمر</Label><Input defaultValue="كريم الأمين" /></div>
              </div>
              <Button type="submit" className="bg-brand-gradient text-white w-fit">حفظ</Button>
            </form>
          </CardContent>
        </Card>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={BookOpen} label="دروسي" value="7" tone="purple" />
        <StatCard icon={ClipboardCheck} label="الحضور" value="96%" tone="teal" />
        <StatCard icon={Trophy} label="المعدل" value="16.4" tone="orange" />
        <StatCard icon={Video} label="فيديو مشاهد" value="42" tone="pink" />
      </div>
    </div>
  ),
});
