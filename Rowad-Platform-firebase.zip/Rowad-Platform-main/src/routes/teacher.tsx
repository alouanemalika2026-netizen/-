import { createFileRoute, Outlet } from "@tanstack/react-router";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { teacherNav } from "@/components/dashboard/nav-configs";

export const Route = createFileRoute("/teacher")({
  head: () => ({ meta: [{ title: "لوحة الأستاذ — منصة رواد" }] }),
  component: () => (
    <DashboardLayout role="teacher" roleLabel="الأستاذ" nav={teacherNav}>
      <Outlet />
    </DashboardLayout>
  ),
});
