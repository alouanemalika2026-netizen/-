import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";
import { ROLE_LABELS, createUserAccount, type Role } from "@/lib/auth";
import { updateRow } from "@/lib/db";

const roleOptions = (Object.keys(ROLE_LABELS) as Role[]).map((k) => ({ value: k, label: ROLE_LABELS[k] }));

export const Route = createFileRoute("/admin/users")({
  component: () => (
    <DataTablePage
      title="إدارة المستخدمين"
      description="جميع المستخدمين في المنصة"
      addLabel="إضافة مستخدم"
      collection="users"
      columns={[
        { key: "name", label: "الاسم" },
        { key: "email", label: "البريد" },
        { key: "role", label: "الدور", render: (r) => ROLE_LABELS[r.role as Role] ?? r.role },
        { key: "status", label: "الحالة", render: (r) => <StatusBadge value={r.status} /> },
      ]}
      filters={[{ key: "role", label: "الأدوار", options: roleOptions }]}
      addFields={[
        { key: "name", label: "الاسم" },
        { key: "email", label: "البريد الإلكتروني", type: "email", createOnly: true },
        { key: "password", label: "كلمة المرور (6 أحرف على الأقل)", type: "password", createOnly: true },
        { key: "role", label: "الدور", type: "select", options: roleOptions },
        { key: "status", label: "الحالة", type: "select", options: ["نشط", "معلق"] },
      ]}
      onCreate={async (v) => {
        await createUserAccount({
          email: v.email, password: v.password, name: v.name, role: v.role as Role,
        });
      }}
      deleteLabel="تعليق الحساب"
      onDelete={async (row) => {
        await updateRow("users", String(row.id), { status: "معلق" });
      }}
    />
  ),
});
