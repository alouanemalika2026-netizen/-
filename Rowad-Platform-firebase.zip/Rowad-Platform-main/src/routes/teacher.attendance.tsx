import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { toast } from "sonner";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { useCollection } from "@/lib/db";
import { authErrorMessage, useAuth } from "@/lib/auth";
import { saveAttendance, type AttendanceStatus } from "@/lib/attendance";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/teacher/attendance")({
  component: TeacherAttendance,
});

const STATUSES: { value: AttendanceStatus; active: string }[] = [
  { value: "حاضر", active: "bg-emerald-600 text-white border-emerald-600" },
  { value: "متأخر", active: "bg-amber-500 text-white border-amber-500" },
  { value: "غائب", active: "bg-rose-600 text-white border-rose-600" },
];

function TeacherAttendance() {
  const { user } = useAuth();
  const { data: students, loading } = useCollection<any>("students");
  const [date, setDate] = useState(() => new Date().toLocaleDateString("en-CA"));
  const [level, setLevel] = useState("الكل");
  const [local, setLocal] = useState<Record<string, AttendanceStatus>>({});
  const [saving, setSaving] = useState(false);
  const { data: existing } = useCollection<any>("attendance", ["date", "==", date]);

  const levels = useMemo(
    () => Array.from(new Set(students.map((s) => s.level).filter(Boolean))) as string[],
    [students],
  );
  const shown = students.filter((s) => level === "الكل" || s.level === level);
  const saved = useMemo(
    () => Object.fromEntries(existing.map((a) => [a.studentId, a.status as AttendanceStatus])),
    [existing],
  );
  const statusOf = (id: string): AttendanceStatus => local[id] ?? saved[id] ?? "حاضر";

  const counts = shown.reduce(
    (acc, s) => ({ ...acc, [statusOf(s.id)]: acc[statusOf(s.id)] + 1 }),
    { "حاضر": 0, "متأخر": 0, "غائب": 0 } as Record<AttendanceStatus, number>,
  );

  const handleSave = async () => {
    if (!user || shown.length === 0) return;
    setSaving(true);
    try {
      const notified = await saveAttendance(
        date,
        shown.map((s) => ({
          student: { id: s.id, name: s.name, level: s.level, parentEmail: s.parentEmail },
          status: statusOf(s.id),
        })),
        user.email,
      );
      setLocal({});
      toast.success(
        notified > 0
          ? `تم حفظ الحضور وإشعار ${notified} من أولياء الأمور`
          : "تم حفظ الحضور",
      );
    } catch (err) {
      console.error(err);
      toast.error(authErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-extrabold">تسجيل الحضور</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          عند تسجيل غياب أو تأخر يصل إشعار تلقائي إلى ولي الأمر.
        </p>
      </div>

      <Card>
        <CardContent className="space-y-4 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <Input
              type="date"
              dir="ltr"
              value={date}
              onChange={(e) => { setDate(e.target.value); setLocal({}); }}
              className="w-44"
            />
            <Select value={level} onValueChange={setLevel}>
              <SelectTrigger className="w-44"><SelectValue placeholder="المستوى" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="الكل">كل المستويات</SelectItem>
                {levels.map((l) => <SelectItem key={l} value={l}>{l}</SelectItem>)}
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              onClick={() => setLocal(Object.fromEntries(shown.map((s) => [s.id, "حاضر" as AttendanceStatus])))}
            >
              الكل حاضر
            </Button>
            <div className="ms-auto flex gap-1.5 text-xs">
              <Badge variant="outline" className="bg-emerald-100 text-emerald-700">حاضر {counts["حاضر"]}</Badge>
              <Badge variant="outline" className="bg-amber-100 text-amber-700">متأخر {counts["متأخر"]}</Badge>
              <Badge variant="outline" className="bg-rose-100 text-rose-700">غائب {counts["غائب"]}</Badge>
            </div>
          </div>

          <ul className="divide-y rounded-lg border">
            {shown.length === 0 && (
              <li className="p-6 text-center text-sm text-muted-foreground">
                {loading ? "جارٍ التحميل..." : "لا يوجد طلاب"}
              </li>
            )}
            {shown.map((s) => (
              <li key={s.id} className="flex flex-wrap items-center justify-between gap-2 p-3">
                <div>
                  <div className="font-semibold">{s.name}</div>
                  <div className="text-xs text-muted-foreground">
                    {s.level}
                    {!s.parentEmail && <span className="ms-2 text-amber-600">· بدون بريد ولي أمر (لن يصله إشعار)</span>}
                  </div>
                </div>
                <div className="flex gap-1">
                  {STATUSES.map((st) => (
                    <button
                      key={st.value}
                      type="button"
                      onClick={() => setLocal((m) => ({ ...m, [s.id]: st.value }))}
                      className={cn(
                        "rounded-lg border px-3 py-1.5 text-xs font-bold transition",
                        statusOf(s.id) === st.value ? st.active : "bg-background hover:bg-muted",
                      )}
                    >
                      {st.value}
                    </button>
                  ))}
                </div>
              </li>
            ))}
          </ul>

          <Button
            onClick={handleSave}
            disabled={saving || shown.length === 0}
            className="w-full bg-brand-gradient text-white sm:w-auto"
          >
            {saving ? "جارٍ الحفظ..." : "حفظ الحضور وإشعار أولياء الأمور"}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
