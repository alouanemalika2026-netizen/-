import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/student/files")({
  component: () => (
    <DataTablePage
      title="ملفات الدروس"
      description="دروسي المكتوبة"
      addLabel="تحميل الكل"
      collection="lessons"
      columns={[
  { key: "title", label: "الدرس" },
  { key: "subject", label: "المادة" },
  { key: "teacher", label: "الأستاذ" },
  { key: "type", label: "النوع" },
  { key: "size", label: "الحجم" },
]}
      filters={[]}
    />
  ),
});
