import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/student/exams")({
  component: () => (
    <DataTablePage
      title="الامتحانات"
      description="امتحاناتي القادمة"
      addLabel="تفاصيل"
      collection="exams"
      columns={[
  { key: "title", label: "الامتحان" },
  { key: "subject", label: "المادة" },
  { key: "date", label: "التاريخ" },
  { key: "duration", label: "المدة" },
  { key: "status", label: "الحالة", render: (r) => <StatusBadge value={r.status} /> },
]}
      filters={[]}
    />
  ),
});
