import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/student/notifications")({
  component: () => (
    <DataTablePage
      title="الإشعارات"
      description="إشعاراتي"
      collection="notifications"
      mine="toEmail"
      hideActions
      columns={[
        { key: "title", label: "الإشعار" },
        { key: "body", label: "التفاصيل" },
        { key: "date", label: "التاريخ" },
      ]}
    />
  ),
});
