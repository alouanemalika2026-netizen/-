import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { GraduationCap, School, Trophy, ClipboardCheck } from "lucide-react";
import { StatCard } from "@/components/dashboard/StatCard";

function ProfilePage({ name, role, badges }: { name: string; role: string; badges: string[] }) {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold">الملف الشخصي</h1>
        <p className="mt-1 text-sm text-muted-foreground">إدارة معلوماتك الشخصية.</p>
      </div>
      <div className="grid gap-5 lg:grid-cols-3">
        <Card>
          <CardContent className="p-6 text-center">
            <Avatar className="mx-auto h-24 w-24">
              <AvatarFallback className="bg-brand-gradient text-3xl font-black text-white">{name.charAt(0)}</AvatarFallback>
            </Avatar>
            <h2 className="mt-4 text-xl font-bold">{name}</h2>
            <div className="mt-1 text-sm text-muted-foreground">{role}</div>
            <div className="mt-4 flex flex-wrap justify-center gap-2">
              {badges.map((b) => <Badge key={b} variant="outline" className="bg-brand-purple/10 text-brand-purple">{b}</Badge>)}
            </div>
            <Button className="mt-4 w-full" variant="outline" onClick={() => toast.info("تغيير الصورة")}>تغيير الصورة</Button>
          </CardContent>
        </Card>
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>المعلومات الشخصية</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={(e) => { e.preventDefault(); toast.success("تم حفظ الملف"); }} className="grid gap-4">
              <div className="grid gap-2 sm:grid-cols-2">
                <div className="grid gap-2"><Label>الاسم الكامل</Label><Input defaultValue={name} /></div>
                <div className="grid gap-2"><Label>البريد</Label><Input defaultValue="user@rowad.com" /></div>
                <div className="grid gap-2"><Label>الهاتف</Label><Input defaultValue="+213 555 12 34 56" /></div>
                <div className="grid gap-2"><Label>المدينة</Label><Input defaultValue="الجزائر العاصمة" /></div>
              </div>
              <div className="grid gap-2"><Label>نبذة</Label><Textarea rows={3} defaultValue="أستاذ رياضيات بخبرة 12 سنة في تحضير طلبة البكالوريا." /></div>
              <div className="flex gap-2">
                <Button type="submit" className="bg-brand-gradient text-white">حفظ</Button>
                <Button type="button" variant="outline" onClick={() => toast.info("سيتم إعادة التعيين")}>إعادة تعيين كلمة المرور</Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={GraduationCap} label="سنوات الخبرة" value="12" tone="purple" />
        <StatCard icon={School} label="أقسام مدرَّسة" value="5" tone="pink" />
        <StatCard icon={ClipboardCheck} label="نسبة النجاح" value="92%" tone="blue" />
        <StatCard icon={Trophy} label="تقييم الطلاب" value="4.9/5" tone="orange" />
      </div>
    </div>
  );
}

export const Route = createFileRoute("/teacher/profile")({
  component: () => <ProfilePage name="أ. أحمد بن علي" role="أستاذ رياضيات" badges={["متميز 2025","معتمد","مرشد"]} />,
});
