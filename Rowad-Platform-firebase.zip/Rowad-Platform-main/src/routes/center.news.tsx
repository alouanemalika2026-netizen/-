import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/news")({
  component: () => (
    <DataTablePage
      title="الأخبار"
      description="أخبار المؤسسة"
      addLabel="خبر جديد"
      collection="news"
      columns={[
  { key: "title", label: "الخبر" },
  { key: "date", label: "التاريخ" },
  { key: "excerpt", label: "مقتطف" },
]}
      filters={[]}
    />
  ),
});
