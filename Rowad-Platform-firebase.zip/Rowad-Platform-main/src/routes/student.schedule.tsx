import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useCollection } from "@/lib/db";
import { Badge } from "@/components/ui/badge";

export const Route = createFileRoute("/student/schedule")({
  component: () => {
    const { data: timetable } = useCollection<any>("timetable");
    return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-extrabold">جدولي الأسبوعي</h1>
        <p className="mt-1 text-sm text-muted-foreground">حصصي هذا الأسبوع</p>
      </div>
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-5">
        {timetable.map((d) => (
          <Card key={d.day} className="overflow-hidden">
            <CardHeader className="bg-[#002855] py-3 text-white">
              <CardTitle className="text-base">{d.day}</CardTitle>
            </CardHeader>
            <CardContent className="p-3 space-y-2">
              {d.slots.map((s, i) => (
                <div key={i} className="rounded-lg border p-3 text-sm">
                  <div className="font-bold">{s.subject}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{s.teacher}</div>
                  <Badge variant="outline" className="mt-2">{s.time}</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
    );
  },
});
