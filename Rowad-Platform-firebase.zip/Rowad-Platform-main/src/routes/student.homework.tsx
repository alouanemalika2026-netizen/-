import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/student/homework")({
  component: () => (
    <DataTablePage
      title="الواجبات"
      description="واجباتي"
      addLabel="رفع واجب"
      collection="homework"
      columns={[
  { key: "title", label: "الواجب" },
  { key: "subject", label: "المادة" },
  { key: "due", label: "التسليم" },
  { key: "status", label: "الحالة", render: (r) => <StatusBadge value={r.status} /> },
]}
      filters={[]}
    />
  ),
});
