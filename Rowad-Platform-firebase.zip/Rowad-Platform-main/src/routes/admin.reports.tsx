import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { GrowthChart, RevenueChart, SubjectPie } from "@/components/dashboard/charts";
import { Button } from "@/components/ui/button";
import { Download, FileText } from "lucide-react";
import { toast } from "sonner";

function ReportsPage({ title }: { title: string }) {
  const reports = [
    { name: "تقرير أداء الطلاب — الفصل 1", date: "2026-07-15", size: "2.4 MB" },
    { name: "تقرير الحضور الشهري", date: "2026-07-01", size: "1.1 MB" },
    { name: "تقرير مالي — يونيو", date: "2026-06-30", size: "3.2 MB" },
    { name: "تقرير أداء الأساتذة", date: "2026-06-25", size: "1.8 MB" },
    { name: "تقرير الامتحانات النهائية", date: "2026-06-20", size: "4.5 MB" },
  ];
  return (
    <div className="space-y-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">{title}</h1>
          <p className="mt-1 text-sm text-muted-foreground">تقارير أداء شاملة قابلة للتصدير.</p>
        </div>
        <Button className="bg-brand-gradient text-white" onClick={() => toast.success("جاري توليد تقرير جديد")}>
          <FileText className="h-4 w-4" /> توليد تقرير
        </Button>
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <GrowthChart />
        <SubjectPie />
      </div>
      <RevenueChart />
      <Card>
        <CardHeader><CardTitle>التقارير المتاحة</CardTitle></CardHeader>
        <CardContent>
          <ul className="divide-y">
            {reports.map((r) => (
              <li key={r.name} className="flex items-center justify-between py-3">
                <div className="flex items-center gap-3">
                  <div className="grid h-10 w-10 place-items-center rounded-lg bg-brand-purple/10 text-brand-purple"><FileText className="h-4 w-4" /></div>
                  <div>
                    <div className="font-semibold">{r.name}</div>
                    <div className="text-xs text-muted-foreground">{r.date} · {r.size}</div>
                  </div>
                </div>
                <Button variant="outline" onClick={() => toast.success("جاري التحميل")}>
                  <Download className="h-4 w-4" /> تحميل
                </Button>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

export const Route = createFileRoute("/admin/reports")({
  component: () => <ReportsPage title="التقارير" />,
});
