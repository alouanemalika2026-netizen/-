import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/teachers")({
  component: () => (
    <DataTablePage
      title="الأساتذة"
      description="جميع أساتذة المؤسسة"
      addLabel="إضافة أستاذ"
      collection="teachers"
      columns={[
  { key: "name", label: "الاسم" },
  { key: "email", label: "البريد" },
  { key: "subject", label: "المادة" },
  { key: "students", label: "الطلاب" },
  { key: "rating", label: "التقييم" },
  { key: "status", label: "الحالة", render: (r) => <StatusBadge value={r.status} /> },
]}
      filters={[{ key: "status", label: "الحالة", options: ["نشط","إجازة"] }]}
    />
  ),
});
