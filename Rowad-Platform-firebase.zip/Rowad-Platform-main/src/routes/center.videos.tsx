import { createFileRoute } from "@tanstack/react-router";
import { useCollection } from "@/lib/db";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Play, Eye } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

function VideoLibrary({ title }: { title: string }) {
  const { data: videos } = useCollection<any>("videos");
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">{title}</h1>
          <p className="mt-1 text-sm text-muted-foreground">فيديوهات تعليمية للمراجعة والفهم.</p>
        </div>
        <Button className="bg-brand-gradient text-white" onClick={() => toast.success("جاري رفع الفيديو")}>+ رفع فيديو</Button>
      </div>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {videos.map((v, i) => (
          <Card key={v.id} className="overflow-hidden group cursor-pointer transition hover:shadow-md">
            <div className="relative aspect-video bg-[#002855]">
              <div className="absolute inset-0 grid place-items-center">
                <div className="grid h-14 w-14 place-items-center rounded-full bg-white/90 shadow-md transition group-hover:scale-110">
                  <Play className="h-6 w-6 text-[#C88A2C] fill-current" />
                </div>
              </div>
              <Badge className="absolute bottom-2 end-2 bg-black/60 text-white">{v.duration}</Badge>
            </div>
            <CardContent className="p-4">
              <div className="font-bold">{v.title}</div>
              <div className="mt-1 flex items-center justify-between text-xs text-muted-foreground">
                <span>{v.subject}</span>
                <span className="flex items-center gap-1"><Eye className="h-3 w-3" /> {v.views}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

export const Route = createFileRoute("/center/videos")({
  component: () => <VideoLibrary title="مكتبة الفيديو" />,
});
