import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/documents")({
  component: () => (
    <DataTablePage
      title="الوثائق"
      description="ملفات ووثائق المؤسسة"
      addLabel="رفع وثيقة"
      collection="documents"
      columns={[
  { key: "name", label: "الملف" },
  { key: "category", label: "الفئة" },
  { key: "size", label: "الحجم" },
]}
      filters={[{ key: "category", label: "الفئة", options: ["مناهج","إداري","نماذج","امتحانات"] }]}
    />
  ),
});
