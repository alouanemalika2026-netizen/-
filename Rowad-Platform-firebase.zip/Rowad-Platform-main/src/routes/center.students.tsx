import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/students")({
  component: () => (
    <DataTablePage
      title="الطلاب"
      description="جميع الطلاب المسجلين"
      addLabel="إضافة طالب"
      collection="students"
      columns={[
  { key: "name", label: "الاسم" },
  { key: "level", label: "المستوى" },
  { key: "parent", label: "ولي الأمر" },
  { key: "attendance", label: "الحضور" },
  { key: "average", label: "المعدل" },
  { key: "status", label: "الحالة", render: (r) => <StatusBadge value={r.status} /> },
]}
      addFields={[
        { key: "name", label: "الاسم" },
        { key: "level", label: "المستوى" },
        { key: "parent", label: "ولي الأمر" },
        { key: "parentEmail", label: "بريد ولي الأمر (لوصول الإشعارات)", type: "email" },
        { key: "attendance", label: "الحضور" },
        { key: "average", label: "المعدل", type: "number" },
        { key: "status", label: "الحالة", type: "select", options: ["منتظم", "متفوق", "يحتاج متابعة"] },
      ]}
      filters={[{ key: "status", label: "الحالة", options: ["منتظم","متفوق","يحتاج متابعة"] }]}
    />
  ),
});
