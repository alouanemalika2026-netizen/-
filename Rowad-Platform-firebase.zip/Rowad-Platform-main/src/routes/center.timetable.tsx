import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useCollection } from "@/lib/db";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import { toast } from "sonner";

function TimetableView({ title }: { title: string }) {
  const { data: timetable } = useCollection<any>("timetable");
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">{title}</h1>
          <p className="mt-1 text-sm text-muted-foreground">جدول الحصص للأسبوع الحالي</p>
        </div>
        <Button className="bg-brand-gradient text-white" onClick={() => toast.success("تم إضافة حصة")}>
          <Plus className="h-4 w-4" /> إضافة حصة
        </Button>
      </div>
      <div className="grid gap-3 md:grid-cols-2 lg:grid-cols-5">
        {timetable.map((d) => (
          <Card key={d.day} className="overflow-hidden">
            <CardHeader className="bg-[#002855] py-3 text-white">
              <CardTitle className="text-base">{d.day}</CardTitle>
            </CardHeader>
            <CardContent className="p-3 space-y-2">
              {d.slots.map((s, i) => (
                <div key={i} className="rounded-lg border p-3 text-sm">
                  <div className="font-bold">{s.subject}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{s.teacher}</div>
                  <div className="mt-2 flex items-center justify-between">
                    <Badge variant="outline">قاعة {s.room}</Badge>
                    <span className="text-xs font-semibold text-brand-purple">{s.time}</span>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

export const Route = createFileRoute("/center/timetable")({
  component: () => <TimetableView title="الجدول الأسبوعي" />,
});
