import { createFileRoute, Outlet } from "@tanstack/react-router";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { parentNav } from "@/components/dashboard/nav-configs";

export const Route = createFileRoute("/parent")({
  head: () => ({ meta: [{ title: "لوحة ولي الأمر — منصة رواد" }] }),
  component: () => (
    <DashboardLayout role="parent" roleLabel="ولي الأمر" nav={parentNav}>
      <Outlet />
    </DashboardLayout>
  ),
});
