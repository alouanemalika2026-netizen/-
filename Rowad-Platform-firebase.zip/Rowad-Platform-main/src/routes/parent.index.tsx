import { createFileRoute } from "@tanstack/react-router";
import { Baby, ClipboardCheck, Trophy, MessageSquare } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { StatCard } from "@/components/dashboard/StatCard";
import { ProgressLine } from "@/components/dashboard/charts";
import { useCollection } from "@/lib/db";
import { useAuth } from "@/lib/auth";
import { Progress } from "@/components/ui/progress";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export const Route = createFileRoute("/parent/")({
  component: ParentDashboard,
});

const kids = [
  { name: "يوسف الأمين", level: "3 ثانوي", avg: 16.4, attendance: 96 },
  { name: "لينة الأمين", level: "2 متوسط", avg: 15.2, attendance: 92 },
];

function ParentDashboard() {
  const { user } = useAuth();
  const { data: announcements } = useCollection<any>("announcements");
  return (
    <div className="space-y-5">
      <div className="rounded-2xl bg-[#002855] p-6 text-white shadow-sm">
        <div className="text-sm opacity-90">أهلاً بك</div>
        <h1 className="mt-1 text-3xl font-black">{user?.name}</h1>
        <p className="mt-2 max-w-2xl text-white/85">ابنك يوسف حصل على معدل 16.4 هذا الفصل، مبروك!</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard icon={Baby} label="عدد الأبناء" value="2" tone="purple" />
        <StatCard icon={ClipboardCheck} label="متوسط الحضور" value="94%" tone="teal" />
        <StatCard icon={Trophy} label="أعلى معدل" value="16.4" tone="orange" />
        <StatCard icon={MessageSquare} label="رسائل جديدة" value="3" tone="pink" />
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {kids.map((k) => (
          <Card key={k.name}>
            <CardHeader className="pb-2">
              <div className="flex items-center gap-3">
                <Avatar className="h-11 w-11">
                  <AvatarFallback className="bg-brand-gradient text-white font-bold">{k.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle className="text-base">{k.name}</CardTitle>
                  <div className="text-xs text-muted-foreground">{k.level}</div>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <div>
                <div className="flex justify-between text-sm"><span>المعدل</span><span className="font-bold">{k.avg}/20</span></div>
                <Progress value={(k.avg / 20) * 100} className="mt-1 h-2" />
              </div>
              <div>
                <div className="flex justify-between text-sm"><span>الحضور</span><span className="font-bold">{k.attendance}%</span></div>
                <Progress value={k.attendance} className="mt-1 h-2" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <ProgressLine />
        <Card>
          <CardHeader className="pb-2"><CardTitle>آخر الإعلانات</CardTitle></CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {announcements.slice(0, 4).map((a) => (
                <li key={a.id} className="rounded-lg border p-3">
                  <div className="text-sm font-semibold">{a.title}</div>
                  <div className="mt-1 text-xs text-muted-foreground">{a.date}</div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
