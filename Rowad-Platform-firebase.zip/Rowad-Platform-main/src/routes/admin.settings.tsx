import { createFileRoute } from "@tanstack/react-router";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";

export const Route = createFileRoute("/admin/settings")({
  component: () => (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold">إعدادات النظام</h1>
        <p className="mt-1 text-sm text-muted-foreground">إعدادات المنصة العامة.</p>
      </div>
      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader><CardTitle>الإعدادات العامة</CardTitle></CardHeader>
          <CardContent>
            <form onSubmit={(e) => { e.preventDefault(); toast.success("تم الحفظ"); }} className="grid gap-4">
              <div className="grid gap-2 sm:grid-cols-2">
                <div className="grid gap-2"><Label>اسم المنصة</Label><Input defaultValue="منصة رواد" /></div>
                <div className="grid gap-2"><Label>البريد الرسمي</Label><Input defaultValue="admin@rowad.com" /></div>
                <div className="grid gap-2"><Label>العملة</Label><Input defaultValue="د.ج (دينار جزائري)" /></div>
                <div className="grid gap-2"><Label>المنطقة الزمنية</Label><Input defaultValue="Africa/Algiers" /></div>
              </div>
              <Button type="submit" className="bg-brand-gradient text-white w-fit">حفظ</Button>
            </form>
          </CardContent>
        </Card>
        <Card>
          <CardHeader><CardTitle>التفعيل</CardTitle></CardHeader>
          <CardContent className="space-y-4">
            {["السماح بالتسجيل الجديد","التحقق من البريد","الدفع الآلي","التقارير الأسبوعية","وضع الصيانة"].map((s) => (
              <div key={s} className="flex items-center justify-between rounded-lg border p-3">
                <span className="text-sm font-medium">{s}</span>
                <Switch defaultChecked={s !== "وضع الصيانة"} onCheckedChange={() => toast.success("تم التحديث")} />
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  ),
});
