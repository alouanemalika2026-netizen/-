import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/notifications")({
  component: () => (
    <DataTablePage
      title="الإشعارات"
      description="إشعارات المؤسسة"
      addLabel="إشعار جديد"
      collection="notifications"
      columns={[
  { key: "title", label: "الإشعار" },
  { key: "time", label: "الوقت" },
]}
      filters={[]}
    />
  ),
});
