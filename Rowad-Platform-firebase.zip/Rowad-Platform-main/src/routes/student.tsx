import { createFileRoute, Outlet } from "@tanstack/react-router";
import { DashboardLayout } from "@/components/dashboard/DashboardLayout";
import { studentNav } from "@/components/dashboard/nav-configs";

export const Route = createFileRoute("/student")({
  head: () => ({ meta: [{ title: "لوحة الطالب — منصة رواد" }] }),
  component: () => (
    <DashboardLayout role="student" roleLabel="الطالب" nav={studentNav}>
      <Outlet />
    </DashboardLayout>
  ),
});
