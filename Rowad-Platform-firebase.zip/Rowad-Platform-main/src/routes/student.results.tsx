import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/student/results")({
  component: () => (
    <DataTablePage
      title="النتائج"
      description="نتائجي"
      addLabel="تحميل الشهادة"
      collection="grades"
      columns={[
  { key: "subject", label: "المادة" },
  { key: "grade", label: "النقطة" },
  { key: "max", label: "من" },
  { key: "comment", label: "الملاحظة" },
]}
      filters={[]}
    />
  ),
});
