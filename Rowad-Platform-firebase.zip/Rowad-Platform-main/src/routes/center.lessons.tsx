import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/lessons")({
  component: () => (
    <DataTablePage
      title="الدروس المرفوعة"
      description="الدروس المكتوبة"
      addLabel="رفع درس"
      collection="lessons"
      columns={[
  { key: "title", label: "الدرس" },
  { key: "subject", label: "المادة" },
  { key: "teacher", label: "الأستاذ" },
  { key: "type", label: "النوع" },
  { key: "size", label: "الحجم" },
]}
      filters={[]}
    />
  ),
});
