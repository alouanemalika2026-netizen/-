import { createFileRoute } from "@tanstack/react-router";
import { DataTablePage, StatusBadge } from "@/components/dashboard/DataTablePage";

export const Route = createFileRoute("/center/parents")({
  component: () => (
    <DataTablePage
      title="أولياء الأمور"
      description="قائمة أولياء الأمور"
      addLabel="إضافة ولي أمر"
      collection="parents"
      columns={[
  { key: "name", label: "الاسم" },
  { key: "phone", label: "الهاتف" },
  { key: "email", label: "البريد" },
  { key: "children", label: "عدد الأبناء" },
]}
      filters={[]}
    />
  ),
});
