import { createFileRoute } from "@tanstack/react-router";
import { GrowthChart, RevenueChart, SubjectPie } from "@/components/dashboard/charts";

export const Route = createFileRoute("/center/reports")({
  component: () => (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-extrabold">التقارير</h1>
        <p className="mt-1 text-sm text-muted-foreground">تقارير مفصلة عن نشاط المؤسسة.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-3">
        <GrowthChart />
        <SubjectPie />
      </div>
      <RevenueChart />
    </div>
  ),
});
