// Static Arabic mock data used across all dashboards.

export const monthlyStats = [
  { month: "جانفي", طلاب: 320, حصص: 180, دخل: 42000 },
  { month: "فيفري", طلاب: 340, حصص: 210, دخل: 46000 },
  { month: "مارس", طلاب: 380, حصص: 240, دخل: 52000 },
  { month: "أفريل", طلاب: 410, حصص: 260, دخل: 58000 },
  { month: "ماي", طلاب: 460, حصص: 290, دخل: 64000 },
  { month: "جوان", طلاب: 520, حصص: 310, دخل: 72000 },
  { month: "جويلية", طلاب: 540, حصص: 330, دخل: 78000 },
];

export const subjectDistribution = [
  { name: "رياضيات", value: 32 },
  { name: "فيزياء", value: 22 },
  { name: "لغة عربية", value: 18 },
  { name: "لغة فرنسية", value: 14 },
  { name: "علوم", value: 14 },
];

export const teachers = [
  { id: 1, name: "أ. أحمد بن علي", subject: "الرياضيات", students: 42, rating: 4.9, status: "نشط" },
  { id: 2, name: "أ. سارة قاسمي", subject: "الفيزياء", students: 36, rating: 4.8, status: "نشط" },
  { id: 3, name: "أ. خالد بوعزيز", subject: "اللغة العربية", students: 51, rating: 4.7, status: "نشط" },
  { id: 4, name: "أ. ليلى مرابط", subject: "اللغة الفرنسية", students: 29, rating: 4.6, status: "إجازة" },
  { id: 5, name: "أ. عمر حداد", subject: "العلوم الطبيعية", students: 33, rating: 4.9, status: "نشط" },
  { id: 6, name: "أ. نور الهدى", subject: "الإنجليزية", students: 40, rating: 4.8, status: "نشط" },
  { id: 7, name: "أ. يوسف طيب", subject: "التاريخ والجغرافيا", students: 27, rating: 4.5, status: "نشط" },
];

export const students = [
  { id: 1, name: "يوسف الأمين", level: "3 ثانوي", parent: "كريم الأمين", attendance: "96%", average: 16.4, status: "منتظم" },
  { id: 2, name: "مريم بلعيد", level: "2 ثانوي", parent: "سعيد بلعيد", attendance: "92%", average: 15.2, status: "منتظم" },
  { id: 3, name: "أنس قدور", level: "4 متوسط", parent: "منير قدور", attendance: "88%", average: 14.8, status: "منتظم" },
  { id: 4, name: "هبة صالحي", level: "3 ثانوي", parent: "فاتح صالحي", attendance: "99%", average: 17.9, status: "متفوق" },
  { id: 5, name: "زكريا عمار", level: "1 ثانوي", parent: "رياض عمار", attendance: "84%", average: 13.5, status: "يحتاج متابعة" },
  { id: 6, name: "لينة برشيد", level: "3 متوسط", parent: "أحلام برشيد", attendance: "94%", average: 15.9, status: "منتظم" },
  { id: 7, name: "إلياس بوزيان", level: "2 ثانوي", parent: "ياسين بوزيان", attendance: "90%", average: 14.2, status: "منتظم" },
];

export const parents = [
  { id: 1, name: "كريم الأمين", phone: "+213 555 12 34 56", children: 1, email: "parent@rowad.com" },
  { id: 2, name: "سعيد بلعيد", phone: "+213 555 78 90 12", children: 2, email: "s.belaid@mail.com" },
  { id: 3, name: "منير قدور", phone: "+213 555 33 44 55", children: 1, email: "m.kadour@mail.com" },
  { id: 4, name: "فاتح صالحي", phone: "+213 555 66 77 88", children: 3, email: "f.salhi@mail.com" },
  { id: 5, name: "رياض عمار", phone: "+213 555 22 11 00", children: 2, email: "r.ammar@mail.com" },
];

export const classes = [
  { id: 1, name: "قسم الرياضيات — 3 ثانوي أ", teacher: "أ. أحمد بن علي", students: 22, room: "قاعة 12" },
  { id: 2, name: "قسم الفيزياء — 2 ثانوي ب", teacher: "أ. سارة قاسمي", students: 18, room: "قاعة 07" },
  { id: 3, name: "قسم اللغة العربية — 4 متوسط", teacher: "أ. خالد بوعزيز", students: 25, room: "قاعة 03" },
  { id: 4, name: "قسم الفرنسية — 3 ثانوي", teacher: "أ. ليلى مرابط", students: 20, room: "قاعة 09" },
  { id: 5, name: "قسم العلوم — 3 متوسط", teacher: "أ. عمر حداد", students: 24, room: "قاعة 05" },
];

export const courses = [
  { id: 1, title: "الدوال العددية", subject: "رياضيات", level: "3 ثانوي", lessons: 12, duration: "18 ساعة" },
  { id: 2, title: "الميكانيك النقطية", subject: "فيزياء", level: "2 ثانوي", lessons: 10, duration: "15 ساعة" },
  { id: 3, title: "علم النحو التطبيقي", subject: "لغة عربية", level: "4 متوسط", lessons: 14, duration: "20 ساعة" },
  { id: 4, title: "قواعد التصريف", subject: "فرنسية", level: "3 ثانوي", lessons: 11, duration: "16 ساعة" },
  { id: 5, title: "الوراثة والتطور", subject: "علوم", level: "3 ثانوي", lessons: 9, duration: "13 ساعة" },
];

export const timetable = [
  { day: "الأحد", slots: [
    { time: "08:00 - 09:30", subject: "رياضيات", teacher: "أ. أحمد", room: "12" },
    { time: "10:00 - 11:30", subject: "فيزياء", teacher: "أ. سارة", room: "07" },
    { time: "14:00 - 15:30", subject: "لغة عربية", teacher: "أ. خالد", room: "03" },
  ]},
  { day: "الاثنين", slots: [
    { time: "09:00 - 10:30", subject: "فرنسية", teacher: "أ. ليلى", room: "09" },
    { time: "11:00 - 12:30", subject: "علوم", teacher: "أ. عمر", room: "05" },
  ]},
  { day: "الثلاثاء", slots: [
    { time: "08:00 - 09:30", subject: "رياضيات", teacher: "أ. أحمد", room: "12" },
    { time: "14:00 - 15:30", subject: "إنجليزية", teacher: "أ. نور", room: "11" },
  ]},
  { day: "الأربعاء", slots: [
    { time: "10:00 - 11:30", subject: "فيزياء", teacher: "أ. سارة", room: "07" },
    { time: "13:00 - 14:30", subject: "تاريخ وجغرافيا", teacher: "أ. يوسف", room: "02" },
  ]},
  { day: "الخميس", slots: [
    { time: "09:00 - 10:30", subject: "لغة عربية", teacher: "أ. خالد", room: "03" },
    { time: "11:00 - 12:30", subject: "رياضيات", teacher: "أ. أحمد", room: "12" },
  ]},
];

export const attendance = [
  { id: 1, name: "يوسف الأمين", date: "2026-07-18", status: "حاضر", class: "3 ثانوي أ" },
  { id: 2, name: "مريم بلعيد", date: "2026-07-18", status: "حاضر", class: "2 ثانوي ب" },
  { id: 3, name: "أنس قدور", date: "2026-07-18", status: "متأخر", class: "4 متوسط" },
  { id: 4, name: "هبة صالحي", date: "2026-07-18", status: "حاضر", class: "3 ثانوي أ" },
  { id: 5, name: "زكريا عمار", date: "2026-07-18", status: "غائب", class: "1 ثانوي" },
  { id: 6, name: "لينة برشيد", date: "2026-07-18", status: "حاضر", class: "3 متوسط" },
  { id: 7, name: "إلياس بوزيان", date: "2026-07-18", status: "حاضر", class: "2 ثانوي ب" },
];

export const exams = [
  { id: 1, title: "امتحان الفصل الأول — رياضيات", subject: "رياضيات", date: "2026-07-25", duration: "2س", status: "قادم" },
  { id: 2, title: "اختبار قصير — فيزياء", subject: "فيزياء", date: "2026-07-22", duration: "1س", status: "قادم" },
  { id: 3, title: "امتحان تقييمي — اللغة العربية", subject: "لغة عربية", date: "2026-07-15", duration: "2س", status: "منجز" },
  { id: 4, title: "امتحان الفصل — فرنسية", subject: "فرنسية", date: "2026-07-10", duration: "2س", status: "منجز" },
  { id: 5, title: "اختبار — علوم", subject: "علوم", date: "2026-07-28", duration: "1س30", status: "قادم" },
];

export const grades = [
  { id: 1, student: "يوسف الأمين", subject: "رياضيات", grade: 17.5, max: 20, comment: "ممتاز" },
  { id: 2, student: "يوسف الأمين", subject: "فيزياء", grade: 16.0, max: 20, comment: "جيد جداً" },
  { id: 3, student: "مريم بلعيد", subject: "لغة عربية", grade: 15.5, max: 20, comment: "جيد جداً" },
  { id: 4, student: "هبة صالحي", subject: "رياضيات", grade: 18.75, max: 20, comment: "متفوق" },
  { id: 5, student: "أنس قدور", subject: "علوم", grade: 14.0, max: 20, comment: "مقبول" },
  { id: 6, student: "زكريا عمار", subject: "فيزياء", grade: 11.5, max: 20, comment: "يحتاج تحسين" },
];

export const announcements = [
  { id: 1, title: "بداية الفصل الدراسي الجديد", date: "2026-07-15", audience: "جميع الطلاب", body: "نعلن عن انطلاق الفصل الدراسي الجديد يوم الأحد. نتمنى للجميع موسماً موفقاً." },
  { id: 2, title: "برنامج الدروس الاستدراكية", date: "2026-07-12", audience: "3 ثانوي", body: "ستنطلق حصص الدعم أيام السبت من الساعة 9 صباحاً." },
  { id: 3, title: "اجتماع أولياء الأمور", date: "2026-07-10", audience: "أولياء الأمور", body: "يوم الجمعة القادم في تمام الساعة 5 مساءً بالقاعة الكبرى." },
  { id: 4, title: "إغلاق استثنائي يوم الأربعاء", date: "2026-07-08", audience: "الجميع", body: "بسبب أعمال صيانة، ستعلق الحصص يوم الأربعاء." },
];

export const news = [
  { id: 1, title: "منصة رواد تطلق تطبيق الهاتف", date: "2026-07-14", excerpt: "تجربة أفضل لأولياء الأمور والطلاب على الأندرويد و iOS." },
  { id: 2, title: "شراكة جديدة مع دار النشر التربوية", date: "2026-07-05", excerpt: "لتوفير محتوى تعليمي حصري للمنخرطين." },
  { id: 3, title: "احتفال المتفوقين لهذا الفصل", date: "2026-06-30", excerpt: "تكريم 42 طالباً متفوقاً في مختلف المستويات." },
];

export const programs = [
  { id: 1, title: "برنامج التفوق للبكالوريا", target: "3 ثانوي", weeks: 24, price: "35,000 د.ج" },
  { id: 2, title: "برنامج تقوية المتوسط", target: "متوسط", weeks: 20, price: "22,000 د.ج" },
  { id: 3, title: "برنامج اللغات المكثف", target: "جميع المستويات", weeks: 12, price: "18,000 د.ج" },
  { id: 4, title: "برنامج الصيف التمهيدي", target: "قادم من متوسط", weeks: 6, price: "9,000 د.ج" },
];

export const lessons = [
  { id: 1, title: "المشتقات وتطبيقاتها — درس مكتوب", subject: "رياضيات", teacher: "أ. أحمد", size: "3.2 MB", type: "PDF" },
  { id: 2, title: "الحركة المستقيمة المنتظمة", subject: "فيزياء", teacher: "أ. سارة", size: "2.8 MB", type: "PDF" },
  { id: 3, title: "شرح البلاغة العربية", subject: "لغة عربية", teacher: "أ. خالد", size: "4.1 MB", type: "PDF" },
  { id: 4, title: "قواعد Passé Composé", subject: "فرنسية", teacher: "أ. ليلى", size: "1.9 MB", type: "PDF" },
  { id: 5, title: "الخلية والوراثة", subject: "علوم", teacher: "أ. عمر", size: "5.3 MB", type: "PDF" },
];

export const videos = [
  { id: 1, title: "درس فيديو: النهايات والاتصال", subject: "رياضيات", duration: "24:18", views: 1240 },
  { id: 2, title: "درس فيديو: القوى وقوانين نيوتن", subject: "فيزياء", duration: "31:02", views: 980 },
  { id: 3, title: "درس فيديو: الإعراب والبناء", subject: "لغة عربية", duration: "19:45", views: 1560 },
  { id: 4, title: "درس فيديو: زمن الماضي المركب", subject: "فرنسية", duration: "22:30", views: 830 },
  { id: 5, title: "درس فيديو: التكاثر عند النبات", subject: "علوم", duration: "28:12", views: 720 },
];

export const documents = [
  { id: 1, name: "منهاج البكالوريا 2026.pdf", category: "مناهج", size: "6.1 MB" },
  { id: 2, name: "قائمة الأدوات المطلوبة.pdf", category: "إداري", size: "0.4 MB" },
  { id: 3, name: "قواعد داخلية للمؤسسة.pdf", category: "إداري", size: "1.2 MB" },
  { id: 4, name: "نموذج تسجيل ولي أمر.docx", category: "نماذج", size: "0.2 MB" },
  { id: 5, name: "روزنامة الامتحانات.xlsx", category: "امتحانات", size: "0.8 MB" },
];

export const notifications = [
  { id: 1, title: "تم رفع درس جديد", time: "قبل 5 دقائق", read: false },
  { id: 2, title: "امتحان قادم يوم الخميس", time: "قبل 2 ساعة", read: false },
  { id: 3, title: "تقييم جديد متاح", time: "اليوم", read: true },
  { id: 4, title: "رسالة من أ. أحمد", time: "أمس", read: true },
  { id: 5, title: "نشرة أولياء الأمور", time: "قبل يومين", read: true },
];

export const messages = [
  { id: 1, from: "أ. أحمد بن علي", subject: "بخصوص واجب الرياضيات", time: "10:24", unread: true },
  { id: 2, from: "المؤسسة", subject: "دعوة اجتماع أولياء الأمور", time: "أمس", unread: true },
  { id: 3, from: "أ. ليلى مرابط", subject: "تصحيح فرض الفرنسية", time: "الاثنين", unread: false },
  { id: 4, from: "الإدارة", subject: "تحديث الجدول الأسبوعي", time: "الأحد", unread: false },
];

export const centers = [
  { id: 1, name: "مؤسسة النور التعليمية", city: "الجزائر العاصمة", teachers: 24, students: 420, plan: "متقدم" },
  { id: 2, name: "أكاديمية النجاح", city: "وهران", teachers: 18, students: 310, plan: "احترافي" },
  { id: 3, name: "مركز الإتقان", city: "قسنطينة", teachers: 12, students: 220, plan: "أساسي" },
  { id: 4, name: "أكاديمية الرواد", city: "عنابة", teachers: 15, students: 260, plan: "متقدم" },
  { id: 5, name: "مؤسسة المستقبل", city: "سطيف", teachers: 20, students: 380, plan: "احترافي" },
];

export const branches = [
  { id: 1, center: "مؤسسة النور التعليمية", name: "فرع باب الوادي", city: "الجزائر", students: 180 },
  { id: 2, center: "مؤسسة النور التعليمية", name: "فرع الأبيار", city: "الجزائر", students: 240 },
  { id: 3, center: "أكاديمية النجاح", name: "الفرع الرئيسي", city: "وهران", students: 310 },
  { id: 4, center: "أكاديمية الرواد", name: "فرع عنابة الوسط", city: "عنابة", students: 160 },
];

export const plans = [
  { id: 1, name: "أساسي", price: "9,900 د.ج / شهر", centers: 1, students: "حتى 100", features: "الميزات الأساسية" },
  { id: 2, name: "متقدم", price: "19,900 د.ج / شهر", centers: 3, students: "حتى 500", features: "تقارير + تنبيهات SMS" },
  { id: 3, name: "احترافي", price: "39,900 د.ج / شهر", centers: 10, students: "غير محدود", features: "كل الميزات + دعم مخصص" },
];

export const users = [
  { id: 1, name: "المدير العام", email: "superadmin@rowad.com", role: "مدير عام", status: "نشط" },
  { id: 2, name: "مؤسسة النور التعليمية", email: "center@rowad.com", role: "مؤسسة", status: "نشط" },
  { id: 3, name: "أ. أحمد بن علي", email: "teacher@rowad.com", role: "أستاذ", status: "نشط" },
  { id: 4, name: "يوسف الأمين", email: "student@rowad.com", role: "طالب", status: "نشط" },
  { id: 5, name: "كريم الأمين", email: "parent@rowad.com", role: "ولي أمر", status: "نشط" },
  { id: 6, name: "أ. سارة قاسمي", email: "s.kacimi@rowad.com", role: "أستاذ", status: "نشط" },
  { id: 7, name: "أكاديمية النجاح", email: "najah@rowad.com", role: "مؤسسة", status: "معلق" },
];

export const roles = [
  { id: 1, name: "مدير عام", users: 2, permissions: 48 },
  { id: 2, name: "مؤسسة", users: 24, permissions: 32 },
  { id: 3, name: "أستاذ", users: 180, permissions: 18 },
  { id: 4, name: "طالب", users: 2400, permissions: 8 },
  { id: 5, name: "ولي أمر", users: 1800, permissions: 6 },
];

export const homework = [
  { id: 1, title: "تمارين الفصل 3 — الرياضيات", subject: "رياضيات", due: "2026-07-22", status: "قيد الإنجاز" },
  { id: 2, title: "تلخيص نص — العربية", subject: "لغة عربية", due: "2026-07-20", status: "منجز" },
  { id: 3, title: "تمرين تطبيقي — الفيزياء", subject: "فيزياء", due: "2026-07-25", status: "قيد الإنجاز" },
  { id: 4, title: "conjugaison — Français", subject: "فرنسية", due: "2026-07-19", status: "متأخر" },
];

export const testimonials = [
  { name: "أ. محمد الشريف", role: "مدير مؤسسة", text: "منصة رواد وفّرت علينا ساعات من العمل الإداري كل أسبوع. النظام سلس وسهل." },
  { name: "السيدة سعاد", role: "ولية أمر", text: "أصبحت أتابع دراسة ابني لحظة بلحظة. تنبيهات وتقارير واضحة وسريعة." },
  { name: "أ. سليم", role: "أستاذ متنقل", text: "أفضل ما استخدمت لتنظيم حصصي وواجبات طلابي في مكان واحد." },
];

export const pricing = [
  { name: "المجاني", price: "0", period: "دائماً", features: ["حتى 20 طالب", "لوحة تحكم أساسية", "دعم عبر البريد"], highlight: false },
  { name: "المتقدم", price: "19,900", period: "شهرياً", features: ["حتى 500 طالب", "تقارير متقدمة", "تنبيهات SMS", "3 فروع"], highlight: true },
  { name: "الاحترافي", price: "39,900", period: "شهرياً", features: ["طلاب غير محدود", "10 فروع", "API مخصص", "دعم أولوية 24/7"], highlight: false },
];

export const features = [
  { icon: "GraduationCap", title: "إدارة الطلاب", desc: "ملفات شاملة، متابعة الحضور، النقاط، والتقدم الأكاديمي." },
  { icon: "Users", title: "إدارة الأساتذة", desc: "جداول، أقسام، تقييم أداء، ومكافآت الأساتذة." },
  { icon: "CalendarDays", title: "جداول ذكية", desc: "جدول أسبوعي مرن مع تعارضات آلية وإشعارات." },
  { icon: "ClipboardCheck", title: "الحضور والغياب", desc: "نداء إلكتروني وتنبيه فوري لأولياء الأمور." },
  { icon: "FileText", title: "امتحانات وتقييمات", desc: "إنشاء ورقة، تصحيح، ومعدلات آلية." },
  { icon: "Bell", title: "إشعارات وأخبار", desc: "نشرات، أخبار، ورسائل داخلية للمجتمع التعليمي." },
  { icon: "Video", title: "مكتبة فيديو", desc: "دروس مرئية للمراجعة في أي وقت." },
  { icon: "BarChart3", title: "تقارير وإحصاءات", desc: "لوحات تحكم بصرية بمؤشرات الأداء." },
];

export const stats = [
  { label: "مؤسسة تعليمية", value: "480+" },
  { label: "أستاذ نشط", value: "3,200+" },
  { label: "طالب مسجل", value: "68,000+" },
  { label: "ولاية مغطاة", value: "48" },
];
