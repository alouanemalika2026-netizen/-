import { doc, serverTimestamp, writeBatch } from "firebase/firestore";
import { db } from "./firebase";

export type AttendanceStatus = "حاضر" | "متأخر" | "غائب";

export interface StudentLite {
  id: string;
  name: string;
  level?: string;
  parentEmail?: string;
}

/**
 * يحفظ الحضور (سجل واحد لكل طالب في اليوم) وينشئ إشعاراً لولي الأمر عند الغياب أو التأخر.
 * إذا عُدّلت الحالة إلى «حاضر» يُحذف الإشعار.
 */
export async function saveAttendance(
  date: string,
  entries: { student: StudentLite; status: AttendanceStatus }[],
  markedBy: string,
) {
  let notified = 0;
  for (let i = 0; i < entries.length; i += 200) {
    const batch = writeBatch(db);
    entries.slice(i, i + 200).forEach(({ student, status }, j) => {
      const order = Date.now() + i + j;
      const parentEmail = (student.parentEmail ?? "").trim().toLowerCase();
      batch.set(doc(db, "attendance", `${date}_${student.id}`), {
        studentId: student.id,
        name: student.name,
        class: student.level ?? "",
        date,
        status,
        parentEmail,
        markedBy,
        order,
        updatedAt: serverTimestamp(),
      });
      if (!parentEmail) return;
      const ref = doc(db, "notifications", `att_${date}_${student.id}`);
      if (status === "حاضر") {
        batch.delete(ref);
      } else {
        notified++;
        batch.set(ref, {
          toEmail: parentEmail,
          fromEmail: markedBy,
          title: `${status === "غائب" ? "غياب" : "تأخر"} ${student.name}`,
          body: `تم تسجيل ${status} للطالب ${student.name} بتاريخ ${date}.`,
          type: "attendance",
          date,
          read: false,
          order,
        });
      }
    });
    await batch.commit();
  }
  return notified;
}
