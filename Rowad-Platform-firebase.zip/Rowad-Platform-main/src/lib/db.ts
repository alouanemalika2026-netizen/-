import { useEffect, useMemo, useState } from "react";
import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  onSnapshot,
  query,
  where as fbWhere,
  writeBatch,
  serverTimestamp,
  updateDoc,
} from "firebase/firestore";
import { db } from "./firebase";

export type Row = { id: string; [k: string]: any };

function sortRows<T extends Row>(rows: T[]): T[] {
  return rows.sort((a, b) => {
    const ao = typeof a.order === "number" ? a.order : Number.MAX_SAFE_INTEGER;
    const bo = typeof b.order === "number" ? b.order : Number.MAX_SAFE_INTEGER;
    return ao - bo;
  });
}

/** اشتراك لحظي في مجموعة Firestore. أي تغيير في القاعدة يظهر مباشرة. */
export type Where = [field: string, op: "==", value: unknown];

export function useCollection<T extends Row = Row>(name: string | undefined, where?: Where) {
  const [data, setData] = useState<T[]>([]);
  const [loading, setLoading] = useState(!!name);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!name) return;
    const base = collection(db, name);
    const unsub = onSnapshot(
      where ? query(base, fbWhere(where[0], where[1], where[2])) : base,
      (snap) => {
        const rows = snap.docs.map((d) => ({ ...d.data(), id: d.id }) as T);
        setData(sortRows(rows));
        setError(null);
        setLoading(false);
      },
      (err) => {
        console.error(`[db] ${name}`, err);
        setError(err);
        setLoading(false);
      },
    );
    return unsub;
  }, [name, where?.[0], where?.[2]]); // eslint-disable-line react-hooks/exhaustive-deps

  return { data, loading, error };
}

export function addRow(name: string, values: Record<string, unknown>) {
  return addDoc(collection(db, name), {
    ...values,
    order: Date.now(),
    createdAt: serverTimestamp(),
  });
}

export function updateRow(name: string, id: string, values: Record<string, unknown>) {
  return updateDoc(doc(db, name, id), { ...values, updatedAt: serverTimestamp() });
}

export function deleteRow(name: string, id: string) {
  return deleteDoc(doc(db, name, id));
}

/** رسائلي (المرسلة والمستلمة) — استعلامان لأن قواعد الأمان تتطلب تقييد الاستعلام بالبريد */
export function useMyMessages(email: string | undefined) {
  const [sent, setSent] = useState<Row[]>([]);
  const [received, setReceived] = useState<Row[]>([]);

  useEffect(() => {
    if (!email) return;
    const col = collection(db, "messages");
    const toRows = (snap: { docs: { data: () => object; id: string }[] }) =>
      snap.docs.map((d) => ({ ...d.data(), id: d.id }) as Row);
    const u1 = onSnapshot(query(col, fbWhere("fromEmail", "==", email)), (s) => setSent(toRows(s)), console.error);
    const u2 = onSnapshot(query(col, fbWhere("toEmail", "==", email)), (s) => setReceived(toRows(s)), console.error);
    return () => {
      u1();
      u2();
    };
  }, [email]);

  return useMemo(() => sortRows([...sent, ...received]), [sent, received]);
}

/** تعليم مجموعة سجلات كمقروءة */
export async function markRead(name: string, ids: string[]) {
  for (let i = 0; i < ids.length; i += 400) {
    const batch = writeBatch(db);
    ids.slice(i, i + 400).forEach((id) => batch.update(doc(db, name, id), { read: true }));
    await batch.commit();
  }
}
