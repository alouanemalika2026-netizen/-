import { useSyncExternalStore } from "react";
import { getApps, initializeApp } from "firebase/app";
import {
  createUserWithEmailAndPassword,
  getAuth,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
} from "firebase/auth";
import { doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import { auth, db, firebaseConfig } from "./firebase";

export type Role = "admin" | "center" | "teacher" | "student" | "parent";

export interface AuthUser {
  uid: string;
  role: Role;
  name: string;
  email: string;
  avatar?: string;
}

export const ROLE_HOME: Record<Role, string> = {
  admin: "/admin",
  center: "/center",
  teacher: "/teacher",
  student: "/student",
  parent: "/parent",
};

export const ROLE_LABELS: Record<Role, string> = {
  admin: "مدير عام",
  center: "مؤسسة",
  teacher: "أستاذ",
  student: "طالب",
  parent: "ولي أمر",
};

interface AuthState {
  ready: boolean;
  user: AuthUser | null;
}

let state: AuthState = { ready: false, user: null };
const listeners = new Set<() => void>();

function setState(next: AuthState) {
  state = next;
  listeners.forEach((l) => l());
}

function subscribe(l: () => void) {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
}

/** يقرأ ملف المستخدم (الدور والاسم) من Firestore: users/{uid} */
async function loadProfile(uid: string, email: string | null): Promise<AuthUser> {
  const snap = await getDoc(doc(db, "users", uid));
  if (!snap.exists()) throw new Error("no-profile");
  const d = snap.data();
  if (d.status === "معلق") throw new Error("suspended");
  if (!(d.role in ROLE_HOME)) throw new Error("no-profile");
  return {
    uid,
    role: d.role as Role,
    name: d.name ?? email ?? "",
    email: d.email ?? email ?? "",
    avatar: d.avatar,
  };
}

onAuthStateChanged(auth, async (fbUser) => {
  if (!fbUser) {
    setState({ ready: true, user: null });
    return;
  }
  try {
    const user = await loadProfile(fbUser.uid, fbUser.email);
    setState({ ready: true, user });
  } catch (e) {
    console.error("[auth] profile error", e);
    await signOut(auth);
    setState({ ready: true, user: null });
  }
});

export async function login(email: string, password: string): Promise<AuthUser> {
  const cred = await signInWithEmailAndPassword(auth, email.trim(), password);
  try {
    const user = await loadProfile(cred.user.uid, cred.user.email);
    setState({ ready: true, user });
    return user;
  } catch (e) {
    await signOut(auth);
    throw e;
  }
}

export async function logout() {
  await signOut(auth);
  setState({ ready: true, user: null });
}

export function resetPassword(email: string) {
  return sendPasswordResetEmail(auth, email.trim());
}

export function getUser(): AuthUser | null {
  return state.user;
}

export function useAuth(): AuthState {
  return useSyncExternalStore(subscribe, () => state, () => state);
}

/**
 * ينشئ حساباً جديداً (للمدير فقط) دون تسجيل خروج المدير الحالي،
 * عبر نسخة Firebase ثانوية، ثم يكتب ملف الدور في users/{uid}.
 */
export async function createUserAccount(input: {
  email: string;
  password: string;
  name: string;
  role: Role;
}) {
  const secondary =
    getApps().find((a) => a.name === "secondary") ?? initializeApp(firebaseConfig, "secondary");
  const secondaryAuth = getAuth(secondary);
  const cred = await createUserWithEmailAndPassword(
    secondaryAuth,
    input.email.trim(),
    input.password,
  );
  try {
    await setDoc(doc(db, "users", cred.user.uid), {
      name: input.name,
      email: input.email.trim().toLowerCase(),
      role: input.role,
      status: "نشط",
      createdAt: serverTimestamp(),
    });
  } finally {
    await signOut(secondaryAuth);
  }
}

export function authErrorMessage(e: unknown): string {
  const code = (e as { code?: string; message?: string })?.code ?? (e as Error)?.message ?? "";
  if (code === "no-profile") return "هذا الحساب غير مرتبط بدور في المنصة. تواصل مع المدير.";
  if (code === "suspended") return "تم تعليق هذا الحساب. تواصل مع المدير.";
  if (code.includes("invalid-credential") || code.includes("wrong-password") || code.includes("user-not-found"))
    return "البريد الإلكتروني أو كلمة المرور غير صحيحة";
  if (code.includes("too-many-requests")) return "محاولات كثيرة، حاول لاحقاً";
  if (code.includes("network")) return "تعذر الاتصال بالشبكة";
  if (code.includes("email-already-in-use")) return "هذا البريد مستخدم من قبل";
  if (code.includes("weak-password")) return "كلمة المرور ضعيفة (6 أحرف على الأقل)";
  if (code.includes("permission-denied")) return "ليست لديك صلاحية لهذه العملية";
  return "حدث خطأ غير متوقع";
}
