import type { Role } from "./auth";

// صلاحيات الكتابة لكل دور. يجب أن تطابق firestore.rules.
const CENTER_WRITE = [
  "students", "teachers", "parents", "classes", "courses", "programs", "lessons",
  "videos", "documents", "exams", "grades", "attendance", "announcements",
  "news", "notifications", "timetable", "homework",
];
const TEACHER_WRITE = [
  "attendance", "grades", "exams", "homework", "announcements",
  "lessons", "videos", "documents",
];

export function canWrite(role: Role | undefined, collection: string | undefined): boolean {
  if (!role || !collection) return false;
  if (role === "admin") return true;
  if (role === "center") return CENTER_WRITE.includes(collection);
  if (role === "teacher") return TEACHER_WRITE.includes(collection);
  return false;
}
