import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Send } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { addRow, markRead, useCollection, useMyMessages } from "@/lib/db";
import { authErrorMessage, useAuth } from "@/lib/auth";
import { cn } from "@/lib/utils";

interface Props {
  title: string;
  description?: string;
  /** المجموعة التي تحوي جهات الاتصال (ولكل منها name و email) */
  contactsCollection: "parents" | "teachers";
}

export function ChatPage({ title, description, contactsCollection }: Props) {
  const { user } = useAuth();
  const { data: contacts } = useCollection<any>(contactsCollection);
  const messages = useMyMessages(user?.email);
  const [selected, setSelected] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [sending, setSending] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  const list = contacts.filter((c) => c.email && c.email !== user?.email);
  const active = list.find((c) => c.email === selected) ?? list[0];
  const thread = active
    ? messages.filter((m) => m.fromEmail === active.email || m.toEmail === active.email)
    : [];
  const unreadIds = thread
    .filter((m) => m.toEmail === user?.email && !m.read)
    .map((m) => m.id);
  const unreadFrom = (email: string) =>
    messages.filter((m) => m.fromEmail === email && m.toEmail === user?.email && !m.read).length;

  // تعليم الرسائل الواردة كمقروءة عند فتح المحادثة
  const unreadKey = unreadIds.join(",");
  useEffect(() => {
    if (unreadKey) markRead("messages", unreadKey.split(",")).catch(console.error);
  }, [unreadKey]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [thread.length, active?.email]);

  const send = async (e: React.FormEvent) => {
    e.preventDefault();
    const body = text.trim();
    if (!body || !active || !user) return;
    setSending(true);
    try {
      await addRow("messages", {
        fromEmail: user.email,
        fromName: user.name,
        toEmail: active.email,
        toName: active.name,
        text: body,
        read: false,
      });
      setText("");
      // إشعار للمستلم (لا يمنع الإرسال إن فشل)
      addRow("notifications", {
        toEmail: active.email,
        fromEmail: user.email,
        title: `رسالة جديدة من ${user.name}`,
        body: body.slice(0, 80),
        type: "message",
        date: new Date().toLocaleDateString("en-CA"),
        read: false,
      }).catch(console.error);
    } catch (err) {
      console.error(err);
      toast.error(authErrorMessage(err));
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-extrabold">{title}</h1>
        {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
      </div>

      <Card className="grid min-h-[28rem] overflow-hidden md:grid-cols-[16rem_1fr]">
        <aside className="max-h-60 overflow-y-auto border-b md:max-h-none md:border-b-0 md:border-l">
          {list.length === 0 && (
            <div className="p-4 text-sm text-muted-foreground">لا توجد جهات اتصال بعد</div>
          )}
          {list.map((c) => {
            const n = unreadFrom(c.email);
            return (
              <button
                key={c.email}
                type="button"
                onClick={() => setSelected(c.email)}
                className={cn(
                  "flex w-full items-center justify-between gap-2 border-b p-3 text-right text-sm transition hover:bg-muted",
                  active?.email === c.email && "bg-muted font-bold",
                )}
              >
                <span className="truncate">
                  {c.name}
                  {c.subject && <span className="block text-xs font-normal text-muted-foreground">{c.subject}</span>}
                </span>
                {n > 0 && (
                  <span className="grid h-5 min-w-5 place-items-center rounded-full bg-[#C88A2C] px-1 text-[10px] font-bold text-white">
                    {n}
                  </span>
                )}
              </button>
            );
          })}
        </aside>

        <section className="flex min-h-0 flex-col">
          {active ? (
            <>
              <header className="border-b p-3 text-sm font-bold">{active.name}</header>
              <div className="flex-1 space-y-2 overflow-y-auto p-3">
                {thread.length === 0 && (
                  <p className="py-10 text-center text-sm text-muted-foreground">ابدأ المحادثة بإرسال رسالة</p>
                )}
                {thread.map((m) => {
                  const mine = m.fromEmail === user?.email;
                  return (
                    <div key={m.id} className={cn("flex", mine ? "justify-start" : "justify-end")}>
                      <div
                        className={cn(
                          "max-w-[80%] whitespace-pre-wrap rounded-2xl px-3.5 py-2 text-sm",
                          mine ? "bg-[#002855] text-white" : "bg-muted",
                        )}
                      >
                        {m.text}
                      </div>
                    </div>
                  );
                })}
                <div ref={endRef} />
              </div>
              <form onSubmit={send} className="flex gap-2 border-t p-3">
                <Input
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="اكتب رسالتك..."
                  maxLength={1000}
                />
                <Button type="submit" disabled={sending || !text.trim()} className="bg-brand-gradient text-white">
                  <Send className="h-4 w-4" />
                </Button>
              </form>
            </>
          ) : (
            <div className="grid flex-1 place-items-center text-sm text-muted-foreground">اختر جهة اتصال</div>
          )}
        </section>
      </Card>
    </div>
  );
}
