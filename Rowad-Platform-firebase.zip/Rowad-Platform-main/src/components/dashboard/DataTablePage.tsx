import { type ReactNode, useMemo, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import {
  Dialog, DialogContent, DialogDescription, DialogFooter,
  DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Search, Filter, Download, Trash2, Pencil } from "lucide-react";
import { toast } from "sonner";
import { addRow, deleteRow, updateRow, useCollection, type Where } from "@/lib/db";
import { authErrorMessage, useAuth } from "@/lib/auth";
import { canWrite } from "@/lib/permissions";

export interface Column<T> {
  key: keyof T | string;
  label: string;
  render?: (row: T) => ReactNode;
}

type Option = string | { value: string; label: string };
const optValue = (o: Option) => (typeof o === "string" ? o : o.value);
const optLabel = (o: Option) => (typeof o === "string" ? o : o.label);

export interface Field {
  key: string;
  label: string;
  type?: "text" | "textarea" | "date" | "number" | "email" | "password" | "select";
  options?: Option[];
  /** يظهر عند الإضافة فقط (مثل البريد وكلمة المرور) */
  createOnly?: boolean;
}

interface Props<T extends { id: number | string }> {
  title: string;
  description?: string;
  columns: Column<T>[];
  /** بيانات ثابتة (قراءة فقط). استخدم collection للبيانات الحقيقية. */
  rows?: T[];
  /** اسم مجموعة Firestore: تُقرأ لحظياً وتدعم الإضافة والتعديل والحذف حسب الصلاحيات */
  collection?: string;
  addLabel?: string;
  filters?: { key: string; label: string; options: Option[] }[];
  addFields?: Field[];
  hideActions?: boolean;
  /** استبدال الإضافة الافتراضية (مثل إنشاء حساب مستخدم) */
  onCreate?: (values: Record<string, any>) => Promise<void>;
  /** استبدال الحذف الافتراضي (مثل تعليق حساب بدل حذفه) */
  onDelete?: (row: T) => Promise<void>;
  deleteLabel?: string;
  /** اسم حقل بريد في السجل: تُعرض فقط السجلات التي يساوي فيها هذا الحقل بريد المستخدم الحالي */
  mine?: string;
}

function csvEscape(v: unknown) {
  const s = v === undefined || v === null ? "" : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export function DataTablePage<T extends { id: number | string; [k: string]: any }>({
  title, description, columns, rows: staticRows, collection, addLabel = "إضافة جديد",
  filters = [], addFields, hideActions, onCreate, onDelete, deleteLabel = "حذف", mine,
}: Props<T>) {
  const { user } = useAuth();
  const mineWhere: Where | undefined = mine && user ? [mine, "==", user.email] : undefined;
  const live = useCollection<any>(collection && (!mine || user) ? collection : undefined, mineWhere);
  const rows: T[] = collection ? (live.data as T[]) : (staticRows ?? []);
  const writable = !!collection && canWrite(user?.role, collection) && !hideActions;

  const [query, setQuery] = useState("");
  const [filterVals, setFilterVals] = useState<Record<string, string>>({});
  const [page, setPage] = useState(1);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<T | null>(null);
  const [values, setValues] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [toDelete, setToDelete] = useState<T | null>(null);
  const perPage = 8;

  const filtered = useMemo(() => {
    return rows.filter((r) => {
      const q = query.trim().toLowerCase();
      const matchesQuery = !q || Object.values(r).some((v) => String(v).toLowerCase().includes(q));
      const matchesFilters = filters.every((f) => {
        const val = filterVals[f.key];
        if (!val || val === "الكل") return true;
        return String(r[f.key]) === val;
      });
      return matchesQuery && matchesFilters;
    });
  }, [rows, query, filterVals, filters]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / perPage));
  const paged = filtered.slice((page - 1) * perPage, page * perPage);

  // حقول النموذج: إما المحددة صراحةً، أو مشتقة من الأعمدة
  const fields: Field[] = useMemo(() => {
    if (addFields) return addFields;
    const sample = rows[0];
    return columns.map((c) => {
      const key = String(c.key);
      const f = filters.find((x) => x.key === key);
      if (f) return { key, label: c.label, type: "select" as const, options: f.options };
      if (sample && typeof sample[key] === "number") return { key, label: c.label, type: "number" as const };
      return { key, label: c.label };
    });
  }, [addFields, columns, filters, rows]);

  const visibleFields = fields.filter((f) => !(editing && f.createOnly));

  const openCreate = () => {
    setEditing(null);
    setValues({});
    setDialogOpen(true);
  };

  const openEdit = (row: T) => {
    setEditing(row);
    setValues(
      Object.fromEntries(fields.map((f) => [f.key, row[f.key] === undefined ? "" : String(row[f.key])])),
    );
    setDialogOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!collection) return;
    const payload: Record<string, any> = {};
    for (const f of visibleFields) {
      const v = values[f.key] ?? "";
      payload[f.key] = f.type === "number" ? (v === "" ? 0 : Number(v)) : v;
    }
    setSaving(true);
    try {
      if (editing) {
        await updateRow(collection, String(editing.id), payload);
        toast.success("تم حفظ التعديلات");
      } else if (onCreate) {
        await onCreate(payload);
        toast.success("تمت الإضافة بنجاح");
      } else {
        await addRow(collection, payload);
        toast.success("تمت الإضافة بنجاح");
      }
      setDialogOpen(false);
    } catch (err) {
      console.error(err);
      toast.error(authErrorMessage(err));
    } finally {
      setSaving(false);
    }
  };

  const confirmDelete = async () => {
    if (!toDelete || !collection) return;
    try {
      if (onDelete) await onDelete(toDelete);
      else await deleteRow(collection, String(toDelete.id));
      toast.success("تمت العملية بنجاح");
    } catch (err) {
      console.error(err);
      toast.error(authErrorMessage(err));
    } finally {
      setToDelete(null);
    }
  };

  const exportCsv = () => {
    const header = columns.map((c) => csvEscape(c.label)).join(",");
    const body = filtered
      .map((r) => columns.map((c) => csvEscape(r[c.key as keyof T])).join(","))
      .join("\n");
    const blob = new Blob(["\uFEFF" + header + "\n" + body], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `${collection ?? "export"}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const emptyText = live.error && collection
    ? "تعذر تحميل البيانات (تحقق من الصلاحيات)"
    : collection && live.loading
      ? "جارٍ التحميل..."
      : "لا توجد بيانات";

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold">{title}</h1>
          {description && <p className="mt-1 text-sm text-muted-foreground">{description}</p>}
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={exportCsv} disabled={filtered.length === 0}>
            <Download className="h-4 w-4" /> تصدير
          </Button>
          {writable && (
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <Button className="bg-brand-gradient text-white shadow-glow" onClick={openCreate}>
                  <Plus className="h-4 w-4" /> {addLabel}
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editing ? "تعديل السجل" : addLabel}</DialogTitle>
                  <DialogDescription>املأ الحقول ثم اضغط حفظ.</DialogDescription>
                </DialogHeader>
                <form onSubmit={handleSubmit} className="grid gap-3">
                  {visibleFields.map((f) => (
                    <div key={f.key} className="grid gap-1.5">
                      <Label htmlFor={f.key}>{f.label}</Label>
                      {f.type === "textarea" ? (
                        <Textarea
                          id={f.key}
                          placeholder={f.label}
                          value={values[f.key] ?? ""}
                          onChange={(e) => setValues((s) => ({ ...s, [f.key]: e.target.value }))}
                        />
                      ) : f.type === "select" ? (
                        <Select
                          value={values[f.key] ?? ""}
                          onValueChange={(v) => setValues((s) => ({ ...s, [f.key]: v }))}
                        >
                          <SelectTrigger id={f.key}>
                            <SelectValue placeholder={f.label} />
                          </SelectTrigger>
                          <SelectContent>
                            {(f.options ?? []).map((o) => (
                              <SelectItem key={optValue(o)} value={optValue(o)}>{optLabel(o)}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      ) : (
                        <Input
                          id={f.key}
                          type={f.type ?? "text"}
                          dir={f.type === "email" || f.type === "password" ? "ltr" : undefined}
                          placeholder={f.label}
                          value={values[f.key] ?? ""}
                          onChange={(e) => setValues((s) => ({ ...s, [f.key]: e.target.value }))}
                          required={f.key === fields[0]?.key || f.createOnly}
                        />
                      )}
                    </div>
                  ))}
                  <DialogFooter>
                    <Button type="submit" disabled={saving} className="bg-brand-gradient text-white">
                      {saving ? "جارٍ الحفظ..." : "حفظ"}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </div>

      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative min-w-0 flex-1">
              <Search className="pointer-events-none absolute right-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="بحث..."
                value={query}
                onChange={(e) => { setQuery(e.target.value); setPage(1); }}
                className="pr-9"
              />
            </div>
            {filters.map((f) => (
              <Select
                key={f.key}
                value={filterVals[f.key] ?? "الكل"}
                onValueChange={(v) => { setFilterVals((s) => ({ ...s, [f.key]: v })); setPage(1); }}
              >
                <SelectTrigger className="w-40">
                  <Filter className="h-4 w-4" />
                  <SelectValue placeholder={f.label} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="الكل">كل {f.label}</SelectItem>
                  {f.options.map((o) => (
                    <SelectItem key={optValue(o)} value={optValue(o)}>{optLabel(o)}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            ))}
          </div>

          <div className="mt-4 overflow-x-auto rounded-lg border">
            <Table>
              <TableHeader>
                <TableRow>
                  {columns.map((c) => (
                    <TableHead key={String(c.key)} className="whitespace-nowrap text-right">{c.label}</TableHead>
                  ))}
                  {writable && <TableHead className="text-right">إجراءات</TableHead>}
                </TableRow>
              </TableHeader>
              <TableBody>
                {paged.length === 0 && (
                  <TableRow>
                    <TableCell colSpan={columns.length + 1} className="py-8 text-center text-muted-foreground">
                      {emptyText}
                    </TableCell>
                  </TableRow>
                )}
                {paged.map((row) => (
                  <TableRow key={String(row.id)}>
                    {columns.map((c) => (
                      <TableCell key={String(c.key)} className="whitespace-nowrap">
                        {c.render ? c.render(row) : String(row[c.key as keyof T] ?? "")}
                      </TableCell>
                    ))}
                    {writable && (
                      <TableCell>
                        <div className="flex gap-1">
                          <Button size="icon" variant="ghost" aria-label="تعديل" onClick={() => openEdit(row)}>
                            <Pencil className="h-4 w-4" />
                          </Button>
                          <Button size="icon" variant="ghost" aria-label={deleteLabel} onClick={() => setToDelete(row)}>
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </div>
                      </TableCell>
                    )}
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>

          <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-sm">
            <div className="text-muted-foreground">
              {filtered.length} نتيجة — صفحة {page} من {pageCount}
            </div>
            <div className="flex gap-1">
              <Button size="sm" variant="outline" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>السابق</Button>
              <Button size="sm" variant="outline" disabled={page === pageCount} onClick={() => setPage((p) => p + 1)}>التالي</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <AlertDialog open={!!toDelete} onOpenChange={(o) => !o && setToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>تأكيد العملية</AlertDialogTitle>
            <AlertDialogDescription>هل أنت متأكد؟ لا يمكن التراجع عن هذه العملية.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete}>{deleteLabel}</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

export function StatusBadge({ value }: { value: string }) {
  const map: Record<string, string> = {
    "نشط": "bg-emerald-100 text-emerald-700",
    "منتظم": "bg-emerald-100 text-emerald-700",
    "متفوق": "bg-brand-purple/15 text-brand-purple",
    "حاضر": "bg-emerald-100 text-emerald-700",
    "منجز": "bg-emerald-100 text-emerald-700",
    "قادم": "bg-brand-blue/15 text-brand-blue",
    "قيد الإنجاز": "bg-brand-blue/15 text-brand-blue",
    "معلق": "bg-amber-100 text-amber-700",
    "إجازة": "bg-amber-100 text-amber-700",
    "متأخر": "bg-amber-100 text-amber-700",
    "غائب": "bg-rose-100 text-rose-700",
    "يحتاج متابعة": "bg-rose-100 text-rose-700",
    "يحتاج تحسين": "bg-rose-100 text-rose-700",
  };
  return (
    <Badge variant="outline" className={map[value] ?? "bg-muted"}>{value}</Badge>
  );
}
