import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import {
  Area, AreaChart, Bar, BarChart, CartesianGrid, Cell, Legend,
  Line, LineChart, Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis,
} from "recharts";
import { useCollection } from "@/lib/db";

// Strict Brand Color Palette for Charts (No gradients, harmonious contrast)
const BRAND_COLORS = {
  navy: "#002855",
  gold: "#C88A2C",
  navyLight: "#1A4474",
  goldLight: "#E0A94D",
  slate: "#64748B",
  emerald: "#059669",
};

const PIE_COLORS = ["#002855", "#C88A2C", "#1A4474", "#E0A94D", "#334155"];

const customTooltipStyle = {
  direction: "rtl" as const,
  backgroundColor: "#FFFFFF",
  borderColor: "#E2E8F0",
  borderRadius: 12,
  boxShadow: "0 10px 25px -5px rgba(0, 40, 85, 0.1)",
  fontSize: "12px",
  fontWeight: 600,
  color: "#001F3F",
  padding: "8px 14px",
};

export function GrowthChart() {
  const { data: monthlyStats } = useCollection("monthlyStats");
  return (
    <Card className="col-span-full lg:col-span-2 border-slate-200 dark:border-white/10 shadow-sm rounded-2xl">
      <CardHeader className="pb-3 border-b border-slate-100 dark:border-white/5">
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-base font-bold text-[#001F3F] dark:text-white font-display">
              نمو النشاط الشهري
            </CardTitle>
            <CardDescription className="text-xs text-muted-foreground mt-0.5">
              مقارنة تطور عدد الطلاب والحصص المنجزة
            </CardDescription>
          </div>
          <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-[#002855]/5 text-[#002855] dark:text-[#C88A2C]">
            العام الدراسي 2026
          </span>
        </div>
      </CardHeader>
      <CardContent className="pt-4">
        <ResponsiveContainer width="100%" height={290}>
          <AreaChart data={monthlyStats} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" opacity={0.6} />
            <XAxis dataKey="month" reversed stroke="#64748B" fontSize={11} tickLine={false} />
            <YAxis orientation="right" stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} />
            <Tooltip contentStyle={customTooltipStyle} />
            <Legend wrapperStyle={{ paddingTop: 12, fontSize: 12 }} />
            <Area
              type="monotone"
              dataKey="طلاب"
              stroke={BRAND_COLORS.navy}
              fill={BRAND_COLORS.navy}
              fillOpacity={0.12}
              strokeWidth={2.5}
            />
            <Area
              type="monotone"
              dataKey="حصص"
              stroke={BRAND_COLORS.gold}
              fill={BRAND_COLORS.gold}
              fillOpacity={0.15}
              strokeWidth={2.5}
            />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

export function RevenueChart() {
  const { data: monthlyStats } = useCollection("monthlyStats");
  return (
    <Card className="border-slate-200 dark:border-white/10 shadow-sm rounded-2xl">
      <CardHeader className="pb-3 border-b border-slate-100 dark:border-white/5">
        <CardTitle className="text-base font-bold text-[#001F3F] dark:text-white font-display">
          الإيرادات الشهرية (د.ج)
        </CardTitle>
        <CardDescription className="text-xs text-muted-foreground mt-0.5">
          متابعة المداخيل المالية للمؤسسة
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-4">
        <ResponsiveContainer width="100%" height={280}>
          <BarChart data={monthlyStats} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" opacity={0.6} vertical={false} />
            <XAxis dataKey="month" reversed stroke="#64748B" fontSize={11} tickLine={false} />
            <YAxis orientation="right" stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} />
            <Tooltip contentStyle={customTooltipStyle} />
            <Bar dataKey="دخل" fill={BRAND_COLORS.navy} radius={[6, 6, 0, 0]} maxBarSize={38} />
          </BarChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

export function SubjectPie() {
  const { data: subjectDistribution } = useCollection("subjectDistribution");
  return (
    <Card className="border-slate-200 dark:border-white/10 shadow-sm rounded-2xl">
      <CardHeader className="pb-3 border-b border-slate-100 dark:border-white/5">
        <CardTitle className="text-base font-bold text-[#001F3F] dark:text-white font-display">
          توزيع المواد الدراسية
        </CardTitle>
        <CardDescription className="text-xs text-muted-foreground mt-0.5">
          نسبة إقبال الطلاب حسب الشعب والمواد
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-2">
        <ResponsiveContainer width="100%" height={280}>
          <PieChart>
            <Pie
              data={subjectDistribution}
              dataKey="value"
              nameKey="name"
              outerRadius={92}
              innerRadius={48}
              paddingAngle={3}
              label
            >
              {subjectDistribution.map((_, i) => (
                <Cell key={i} fill={PIE_COLORS[i % PIE_COLORS.length]} stroke="#FFFFFF" strokeWidth={2} />
              ))}
            </Pie>
            <Tooltip contentStyle={customTooltipStyle} />
            <Legend wrapperStyle={{ paddingTop: 8, fontSize: 11 }} />
          </PieChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}

export function ProgressLine() {
  const data = [
    { m: "س1", note: 12 }, { m: "س2", note: 13 }, { m: "س3", note: 14 },
    { m: "س4", note: 14.5 }, { m: "س5", note: 15.5 }, { m: "س6", note: 16.4 },
  ];
  return (
    <Card className="border-slate-200 dark:border-white/10 shadow-sm rounded-2xl">
      <CardHeader className="pb-3 border-b border-slate-100 dark:border-white/5">
        <CardTitle className="text-base font-bold text-[#001F3F] dark:text-white font-display">
          تطور المعدل العام
        </CardTitle>
        <CardDescription className="text-xs text-muted-foreground mt-0.5">
          المعدل التراكمي خلال الفصول الدراسية
        </CardDescription>
      </CardHeader>
      <CardContent className="pt-4">
        <ResponsiveContainer width="100%" height={240}>
          <LineChart data={data} margin={{ top: 10, right: 10, left: 10, bottom: 0 }}>
            <CartesianGrid strokeDasharray="3 3" stroke="#E2E8F0" opacity={0.6} />
            <XAxis dataKey="m" reversed stroke="#64748B" fontSize={11} tickLine={false} />
            <YAxis orientation="right" domain={[10, 20]} stroke="#64748B" fontSize={11} tickLine={false} axisLine={false} />
            <Tooltip contentStyle={customTooltipStyle} />
            <Line
              type="monotone"
              dataKey="note"
              stroke={BRAND_COLORS.gold}
              strokeWidth={3}
              dot={{ r: 5, fill: BRAND_COLORS.navy, stroke: BRAND_COLORS.gold, strokeWidth: 2 }}
              activeDot={{ r: 7 }}
            />
          </LineChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}
