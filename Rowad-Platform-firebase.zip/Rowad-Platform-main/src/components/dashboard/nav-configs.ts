import {
  LayoutDashboard, Users, GraduationCap, UserCog, School, BookOpen,
  CalendarDays, ClipboardCheck, FileText, BarChart3, Megaphone, Newspaper,
  BookMarked, FileVideo, Files, PieChart, Bell, MessageSquare, Settings,
  Shield, Building2, GitBranch, CreditCard, User, Upload, ClipboardList,
  Trophy, Video, Baby, TrendingUp,
} from "lucide-react";
import type { NavItem } from "./DashboardLayout";

export const adminNav: NavItem[] = [
  { to: "/admin", label: "لوحة التحكم", icon: LayoutDashboard },
  { to: "/admin/users", label: "إدارة المستخدمين", icon: Users },
  { to: "/admin/roles", label: "الأدوار والصلاحيات", icon: Shield },
  { to: "/admin/centers", label: "إدارة المؤسسات", icon: Building2 },
  { to: "/admin/branches", label: "الفروع", icon: GitBranch },
  { to: "/admin/plans", label: "خطط الاشتراك", icon: CreditCard },
  { to: "/admin/analytics", label: "التحليلات", icon: BarChart3 },
  { to: "/admin/reports", label: "التقارير", icon: FileText },
  { to: "/admin/notifications", label: "الإشعارات", icon: Bell },
  { to: "/admin/settings", label: "الإعدادات", icon: Settings },
];

export const centerNav: NavItem[] = [
  { to: "/center", label: "لوحة التحكم", icon: LayoutDashboard },
  { to: "/center/teachers", label: "الأساتذة", icon: UserCog },
  { to: "/center/students", label: "الطلاب", icon: GraduationCap },
  { to: "/center/parents", label: "أولياء الأمور", icon: Users },
  { to: "/center/classes", label: "الأقسام", icon: School },
  { to: "/center/courses", label: "الدروس والمواد", icon: BookOpen },
  { to: "/center/timetable", label: "الجدول الأسبوعي", icon: CalendarDays },
  { to: "/center/attendance", label: "الحضور", icon: ClipboardCheck },
  { to: "/center/exams", label: "الامتحانات", icon: FileText },
  { to: "/center/grades", label: "النقاط", icon: Trophy },
  { to: "/center/announcements", label: "الإعلانات", icon: Megaphone },
  { to: "/center/news", label: "الأخبار", icon: Newspaper },
  { to: "/center/programs", label: "البرامج التعليمية", icon: BookMarked },
  { to: "/center/lessons", label: "الدروس المرفوعة", icon: Upload },
  { to: "/center/videos", label: "مكتبة الفيديو", icon: FileVideo },
  { to: "/center/documents", label: "الوثائق", icon: Files },
  { to: "/center/reports", label: "التقارير", icon: FileText },
  { to: "/center/statistics", label: "الإحصائيات", icon: PieChart },
  { to: "/center/notifications", label: "الإشعارات", icon: Bell },
  { to: "/center/messages", label: "الرسائل", icon: MessageSquare },
  { to: "/center/settings", label: "الإعدادات", icon: Settings },
];

export const teacherNav: NavItem[] = [
  { to: "/teacher", label: "لوحة التحكم", icon: LayoutDashboard },
  { to: "/teacher/schedule", label: "جدولي", icon: CalendarDays },
  { to: "/teacher/classes", label: "أقسامي", icon: School },
  { to: "/teacher/students", label: "طلابي", icon: GraduationCap },
  { to: "/teacher/attendance", label: "الحضور", icon: ClipboardCheck },
  { to: "/teacher/upload-lessons", label: "رفع الدروس", icon: Upload },
  { to: "/teacher/upload-exercises", label: "رفع التمارين", icon: ClipboardList },
  { to: "/teacher/homework", label: "الواجبات", icon: BookMarked },
  { to: "/teacher/exams", label: "الامتحانات", icon: FileText },
  { to: "/teacher/grades", label: "النقاط", icon: Trophy },
  { to: "/teacher/announcements", label: "الإعلانات", icon: Megaphone },
  { to: "/teacher/messages", label: "الرسائل", icon: MessageSquare },
  { to: "/teacher/profile", label: "الملف الشخصي", icon: User },
];

export const studentNav: NavItem[] = [
  { to: "/student", label: "لوحة التحكم", icon: LayoutDashboard },
  { to: "/student/courses", label: "دروسي", icon: BookOpen },
  { to: "/student/schedule", label: "الجدول الأسبوعي", icon: CalendarDays },
  { to: "/student/homework", label: "الواجبات", icon: BookMarked },
  { to: "/student/exams", label: "الامتحانات", icon: FileText },
  { to: "/student/results", label: "النتائج", icon: Trophy },
  { to: "/student/videos", label: "الفيديوهات التعليمية", icon: Video },
  { to: "/student/files", label: "ملفات الدروس", icon: Files },
  { to: "/student/announcements", label: "الإعلانات", icon: Megaphone },
  { to: "/student/notifications", label: "الإشعارات", icon: Bell },
  { to: "/student/profile", label: "الملف الشخصي", icon: User },
];

export const parentNav: NavItem[] = [
  { to: "/parent", label: "لوحة التحكم", icon: LayoutDashboard },
  { to: "/parent/children", label: "قائمة الأبناء", icon: Baby },
  { to: "/parent/attendance", label: "الحضور", icon: ClipboardCheck },
  { to: "/parent/grades", label: "النقاط", icon: Trophy },
  { to: "/parent/progress", label: "التقدم الأكاديمي", icon: TrendingUp },
  { to: "/parent/notifications", label: "الإشعارات", icon: Bell },
  { to: "/parent/announcements", label: "الإعلانات", icon: Megaphone },
  { to: "/parent/messages", label: "الرسائل", icon: MessageSquare },
];
