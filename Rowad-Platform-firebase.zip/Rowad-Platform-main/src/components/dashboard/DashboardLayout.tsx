import { type ReactNode, useEffect, useState } from "react";
import { Link, useRouter, useRouterState } from "@tanstack/react-router";
import {
  Bell, Search, Menu, LogOut, ChevronDown, Sun,
  Settings as SettingsIcon,
} from "lucide-react";
import { toast } from "sonner";
import logoAsset from "@/assets/rowad-logo.asset.json";
import { logout, useAuth, ROLE_HOME, type Role } from "@/lib/auth";
import { markRead, useCollection } from "@/lib/db";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import type { LucideIcon } from "lucide-react";

export interface NavItem {
  to: string;
  label: string;
  icon: LucideIcon;
}

interface Props {
  role: Role;
  roleLabel: string;
  nav: NavItem[];
  children: ReactNode;
}

const roleColors: Record<Role, string> = {
  admin: "from-brand-purple to-brand-blue",
  center: "from-brand-purple to-brand-pink",
  teacher: "from-brand-blue to-brand-teal",
  student: "from-brand-pink to-brand-orange",
  parent: "from-brand-teal to-brand-blue",
};

export function DashboardLayout({ role, roleLabel, nav, children }: Props) {
  const router = useRouter();
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const [open, setOpen] = useState(false);
  const { ready, user } = useAuth();
  const displayName = user?.name ?? roleLabel;
  const allowed = !!user && user.role === role;

  // عدّاد الإشعارات غير المقروءة (تُعلَّم مقروءة عند فتح صفحة الإشعارات)
  const { data: myNotes } = useCollection<any>(user ? "notifications" : undefined, ["toEmail", "==", user?.email ?? ""]);
  const unreadNotes = myNotes.filter((n) => !n.read);
  const onNotificationsPage = pathname.endsWith("/notifications");
  const unreadKey = unreadNotes.map((n) => n.id).join(",");
  useEffect(() => {
    if (onNotificationsPage && unreadKey) markRead("notifications", unreadKey.split(",")).catch(console.error);
  }, [onNotificationsPage, unreadKey]);

  // حماية المسارات: غير مسجّل -> الدخول، ودور مختلف -> لوحته الخاصة
  useEffect(() => {
    if (!ready) return;
    if (!user) router.navigate({ to: "/login" });
    else if (user.role !== role) router.navigate({ to: ROLE_HOME[user.role] });
  }, [ready, user, role, router]);

  const handleLogout = async () => {
    await logout();
    toast.success("تم تسجيل الخروج بنجاح");
    router.navigate({ to: "/" });
  };

  if (!ready || !allowed) {
    return (
      <div className="grid min-h-screen place-items-center text-sm text-muted-foreground">
        جارٍ التحميل...
      </div>
    );
  }

  return (
    <div className="flex min-h-screen bg-mesh bg-background">
      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 right-0 z-40 w-72 shrink-0 border-l border-slate-200 dark:border-white/10 bg-white dark:bg-[#001428] transition-transform duration-300 lg:static lg:translate-x-0",
          open ? "translate-x-0" : "translate-x-full lg:translate-x-0",
        )}
      >
        <div className="flex h-full flex-col">
          <Link
            to="/"
            className="flex flex-col items-center justify-center text-center border-b border-slate-200/80 dark:border-white/10 px-5 py-5 bg-white dark:bg-[#001F3F] gap-2.5 transition-transform hover:scale-102"
          >
            <img
              src={logoAsset.logo.url}
              alt="شعار منصة روّاد"
              className="h-16 w-auto object-contain"
            />
            <span className="text-lg font-black text-[#002855] dark:text-white font-display">
              منصة روّاد
            </span>
          </Link>

          <nav className="flex-1 overflow-y-auto px-3 py-4">
            <ul className="space-y-1">
              {nav.map((item) => {
                const active = pathname === item.to || (item.to !== `/${role}` && pathname.startsWith(item.to));
                const Icon = item.icon;
                return (
                  <li key={item.to}>
                    <Link
                      to={item.to}
                      onClick={() => setOpen(false)}
                      className={cn(
                        "group flex items-center justify-between rounded-xl px-3.5 py-2.5 text-xs font-bold transition-all",
                        active
                          ? "bg-[#002855] text-white shadow-md shadow-[#002855]/20"
                          : "text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-white/5",
                      )}
                    >
                      <div className="flex items-center gap-3">
                        <Icon className={cn("h-4 w-4 shrink-0", active ? "text-[#C88A2C]" : "text-muted-foreground")} />
                        <span className="truncate">{item.label}</span>
                      </div>
                      {item.to.endsWith("/notifications") && unreadNotes.length > 0 ? (
                        <span className="grid h-5 min-w-5 place-items-center rounded-full bg-[#C88A2C] px-1 text-[10px] font-bold text-white">
                          {unreadNotes.length}
                        </span>
                      ) : (
                        active && (
                          <span className="text-[10px] bg-white/20 text-white px-1.5 py-0.5 rounded font-normal">
                            رئيسي
                          </span>
                        )
                      )}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>

          {/* Bottom user profile matching preview */}
          <div className="border-t border-slate-200/80 dark:border-white/10 p-3 bg-white dark:bg-[#001F3F]">
            <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50 dark:bg-[#001428] border border-slate-200/60 dark:border-white/10">
              <div className="flex items-center gap-2.5 truncate">
                <div className="h-8 w-8 rounded-full bg-[#002855]/10 text-[#002855] dark:text-[#C88A2C] font-bold text-xs grid place-items-center shrink-0">
                  {displayName.charAt(0)}
                </div>
                <div className="flex flex-col truncate">
                  <span className="text-xs font-bold text-foreground truncate">{displayName}</span>
                  <span className="text-[10px] text-muted-foreground truncate">{user?.email ?? roleLabel}</span>
                </div>
              </div>
              <span className="h-2 w-2 rounded-full bg-emerald-500 shrink-0"></span>
            </div>
            
            <button
              onClick={handleLogout}
              className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl py-2 text-xs font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 transition-colors"
            >
              <LogOut className="h-3.5 w-3.5" />
              <span>تسجيل الخروج</span>
            </button>
          </div>
        </div>
      </aside>

      {/* Overlay mobile */}
      {open && (
        <div onClick={() => setOpen(false)} className="fixed inset-0 z-30 bg-black/40 lg:hidden" />
      )}

      {/* Main */}
      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-20 bg-white/95 dark:bg-[#001428]/95 backdrop-blur-md border-b border-slate-200 dark:border-white/10">
          <div className="flex h-14 items-center justify-between px-4 lg:px-6">
            
            {/* Right side: Mobile Menu toggle + Breadcrumb text */}
            <div className="flex items-center gap-3">
              <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setOpen(!open)}>
                <Menu className="h-5 w-5" />
              </Button>
              <div className="flex items-center gap-2">
                <span className="h-2.5 w-2.5 rounded-full bg-rose-500 inline-block"></span>
                <span className="h-2.5 w-2.5 rounded-full bg-amber-400 inline-block"></span>
                <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 inline-block"></span>
                <span className="text-slate-500 dark:text-slate-400 font-mono text-xs hidden sm:inline-block mr-2">
                  app.rowad.edu.dz / لوحة {roleLabel}
                </span>
              </div>
            </div>

            {/* Left side: Status badge and profile menu */}
            <div className="flex items-center gap-3">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-[#C88A2C]/10 text-[#C88A2C] border border-[#C88A2C]/30">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
                النظام متصل ومباشر
              </span>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="gap-2 px-2 h-9 rounded-xl hover:bg-slate-100 dark:hover:bg-white/5">
                    <Avatar className="h-7 w-7">
                      <AvatarFallback className="bg-[#002855] text-white text-xs font-bold">
                        {displayName.charAt(0)}
                      </AvatarFallback>
                    </Avatar>
                    <div className="hidden text-right md:block">
                      <div className="text-xs font-bold leading-none text-[#001F3F] dark:text-white">{displayName}</div>
                    </div>
                    <ChevronDown className="h-3.5 w-3.5 opacity-60" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>حسابي</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem><SettingsIcon className="h-4 w-4 me-2" /> الإعدادات</DropdownMenuItem>
                  <DropdownMenuItem onClick={handleLogout} className="text-destructive">
                    <LogOut className="h-4 w-4 me-2" /> تسجيل الخروج
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

          </div>
        </header>

        <main className="flex-1 p-4 lg:p-6">
          <div className="mx-auto w-full max-w-[1400px]">{children}</div>
        </main>

        <footer className="border-t px-4 py-3 text-center text-xs text-muted-foreground">
          © 2026 منصة رواد — نرافق طلاب اليوم لنصنع رواد الغد.
          <Badge variant="outline" className="ms-2">نسخة تجريبية</Badge>
        </footer>
      </div>
    </div>
  );
}
