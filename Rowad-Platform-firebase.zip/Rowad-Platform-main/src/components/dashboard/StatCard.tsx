import type { LucideIcon } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { cn } from "@/lib/utils";

interface Props {
  icon: LucideIcon;
  label: string;
  value: string | number;
  hint?: string;
  trend?: string;
  tone?: "purple" | "pink" | "orange" | "blue" | "teal";
}

const tones: Record<NonNullable<Props["tone"]>, string> = {
  purple: "bg-[#002855]/10 text-[#002855] dark:text-[#C88A2C]",
  pink: "bg-[#C88A2C]/10 text-[#C88A2C]",
  orange: "bg-[#C88A2C]/10 text-[#C88A2C]",
  blue: "bg-[#002855]/10 text-[#002855]",
  teal: "bg-[#002855]/10 text-[#002855]",
};

export function StatCard({ icon: Icon, label, value, hint, trend, tone = "purple" }: Props) {
  return (
    <Card className="overflow-hidden">
      <CardContent className="p-5">
        <div className="flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="text-xs font-medium text-muted-foreground">{label}</div>
            <div className="mt-1 text-2xl font-extrabold">{value}</div>
            {hint && <div className="mt-1 text-xs text-muted-foreground">{hint}</div>}
          </div>
          <div className={cn("grid h-11 w-11 shrink-0 place-items-center rounded-xl", tones[tone])}>
            <Icon className="h-5 w-5" />
          </div>
        </div>
        {trend && (
          <div className="mt-3 text-xs font-semibold text-emerald-600">↑ {trend}</div>
        )}
      </CardContent>
    </Card>
  );
}
