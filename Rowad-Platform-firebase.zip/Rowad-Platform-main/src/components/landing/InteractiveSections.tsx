import {
  Bell,
  CheckCircle2,
  Calendar,
  AlertTriangle,
  GraduationCap,
  Clock,
  BookOpen,
  Award,
  ChevronLeft,
} from "lucide-react";

export function EcosystemSection() {
  return (
    <div className="relative py-12 px-4 max-w-5xl mx-auto">
      <div className="relative rounded-2xl border border-border/80 bg-card p-6 md:p-12 overflow-hidden">

        {/* Central Brand Node */}
        <div className="text-center relative z-10 mb-12">
          <div className="inline-flex items-center justify-center p-4 rounded-2xl bg-[#002855] text-white shadow-xl shadow-[#002855]/20 mb-3">
            <span className="text-xl font-extrabold tracking-wide">منصة روّاد</span>
          </div>
          <p className="text-sm font-medium text-muted-foreground max-w-md mx-auto">
            النواة الرقمية التي تضمن انسياب المعلومات ومزامنة البيانات في الوقت الفعلي
          </p>
        </div>

        {/* Four Connected Roles */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 relative z-10">
          
          {/* Role 1: Educational Center */}
          <div className="p-5 rounded-xl border border-[#C88A2C]/30 bg-card/80 text-right space-y-2 hover:border-[#C88A2C] transition-colors">
            <div className="h-8 w-8 rounded-lg bg-[#C88A2C]/10 text-[#002855] font-bold grid place-items-center text-sm mb-3">
              01
            </div>
            <h4 className="font-bold text-base text-foreground">المركز التعليمي</h4>
            <p className="text-xs text-muted-foreground leading-relaxed">
              الإشراف الشامل، إدارة التسجيل، التخطيط الأكاديمي، وإصدار التقارير الإدارية والمالية.
            </p>
            <div className="pt-2 text-[11px] font-medium text-[#002855]">
              ← إدارة العمليات المركزية
            </div>
          </div>

          {/* Role 2: Teacher */}
          <div className="p-5 rounded-xl border border-violet-500/30 bg-card/80 text-right space-y-2 hover:border-violet-500 transition-colors">
            <div className="h-8 w-8 rounded-lg bg-violet-500/10 text-violet-600 font-bold grid place-items-center text-sm mb-3">
              02
            </div>
            <h4 className="font-bold text-base text-foreground">المدرس والأستاذ</h4>
            <p className="text-xs text-muted-foreground leading-relaxed">
              تخطيط الحصص، رصد الحضور بالباركود، نشر الواجبات والامتحانات، وتقييم استيعاب الطلاب.
            </p>
            <div className="pt-2 text-[11px] font-medium text-violet-600">
              ← أدوات التدريس الذكية
            </div>
          </div>

          {/* Role 3: Student */}
          <div className="p-5 rounded-xl border border-emerald-500/30 bg-card/80 text-right space-y-2 hover:border-emerald-500 transition-colors">
            <div className="h-8 w-8 rounded-lg bg-emerald-500/10 text-emerald-600 font-bold grid place-items-center text-sm mb-3">
              03
            </div>
            <h4 className="font-bold text-base text-foreground">الطالب</h4>
            <p className="text-xs text-muted-foreground leading-relaxed">
              الوصول الفوري للمقررات، تسليم الواجبات، مراجعة الجداول، ومتابعة تطور المعدل والدرجات.
            </p>
            <div className="pt-2 text-[11px] font-medium text-emerald-600">
              ← مسار التعلم المنظم
            </div>
          </div>

          {/* Role 4: Parent */}
          <div className="p-5 rounded-xl border border-amber-500/30 bg-card/80 text-right space-y-2 hover:border-amber-500 transition-colors">
            <div className="h-8 w-8 rounded-lg bg-amber-500/10 text-amber-600 font-bold grid place-items-center text-sm mb-3">
              04
            </div>
            <h4 className="font-bold text-base text-foreground">ولي الأمر</h4>
            <p className="text-xs text-muted-foreground leading-relaxed">
              إشعارات فورية بالوصول والغياب، بطاقات الأداء المستمرة، وتواصل شفاف ومباشر مع الأسرة.
            </p>
            <div className="pt-2 text-[11px] font-medium text-amber-600">
              ← الشفافية والمتابعة اللحظية
            </div>
          </div>

        </div>

      </div>
    </div>
  );
}

export function AnalyticsSectionMockup() {
  return (
    <div className="rounded-xl border border-border/80 bg-card p-5 md:p-6 text-xs text-right">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-border/50">
        <div>
          <h4 className="text-base font-bold">لوحة المؤشرات والتحليلات الأكاديمية</h4>
          <p className="text-xs text-muted-foreground mt-0.5">
            رؤية شاملة قائمة على البيانات لاتخاذ قرارات تربوية وإدارية دقيقة
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-[11px] bg-muted px-2.5 py-1 rounded font-medium text-muted-foreground">
            الفصل الدراسي الحالي
          </span>
          <span className="text-[11px] bg-[#002855] text-white px-2.5 py-1 rounded font-medium">
            تصدير تقرير PDF
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 my-5">
        <div className="p-4 rounded-xl border border-border/70 bg-muted/20">
          <span className="text-xs text-muted-foreground font-medium block">متوسط درجات المؤسسة</span>
          <div className="text-2xl font-bold font-mono text-[#002855] mt-1">15.82 <span className="text-xs text-muted-foreground">/ 20</span></div>
          <p className="text-[11px] text-emerald-600 mt-1 font-medium">↑ تحسن بنسبة +1.4 نقطة عن الفصل الماضي</p>
        </div>

        <div className="p-4 rounded-xl border border-border/70 bg-muted/20">
          <span className="text-xs text-muted-foreground font-medium block">معدل الانضباط العام</span>
          <div className="text-2xl font-bold font-mono text-emerald-600 mt-1">96.8%</div>
          <p className="text-[11px] text-muted-foreground mt-1">انخفاض الغيابات غير المبررة بنسبة 45%</p>
        </div>

        <div className="p-4 rounded-xl border border-border/70 bg-muted/20">
          <span className="text-xs text-muted-foreground font-medium block">معدل رضا أولياء الأمور</span>
          <div className="text-2xl font-bold font-mono text-amber-500 mt-1">4.9 <span className="text-xs text-muted-foreground">/ 5.0</span></div>
          <p className="text-[11px] text-muted-foreground mt-1">بناءً على 380 تقييماً موثقاً</p>
        </div>
      </div>

      <div className="p-4 rounded-xl border border-border/70 bg-muted/10 space-y-3">
        <div className="flex items-center justify-between text-xs font-semibold">
          <span>مقارنة نسب النجاح حسب التخصصات والمواد الأكاديمية</span>
          <span className="text-[11px] text-muted-foreground font-mono">الامتحانات الرسمية 2026</span>
        </div>

        <div className="space-y-2">
          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span>العلوم الدقيقة (الرياضيات والفيزياء)</span>
              <span className="font-mono font-bold text-[#002855]">92% تفوق</span>
            </div>
            <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
              <div className="h-full rounded-full bg-[#002855]" style={{ width: "92%" }}></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span>العلوم الطبيعية والحياة</span>
              <span className="font-mono font-bold text-emerald-600">88% تفوق</span>
            </div>
            <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
              <div className="h-full rounded-full bg-emerald-500" style={{ width: "88%" }}></div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-[11px] mb-1">
              <span>اللغات الحية والآداب</span>
              <span className="font-mono font-bold text-amber-600">85% تفوق</span>
            </div>
            <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
              <div className="h-full rounded-full bg-amber-500" style={{ width: "85%" }}></div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function CommunicationMockup() {
  return (
    <div className="rounded-xl border border-border/80 bg-card p-4 md:p-5 text-xs text-right space-y-3">
      <div className="flex items-center justify-between pb-3 border-b border-border/50">
        <div className="flex items-center gap-2">
          <Bell className="h-4 w-4 text-[#002855]" />
          <span className="font-bold text-sm">سجل الإشعارات والتواصل اللحظي</span>
        </div>
        <span className="text-[10px] bg-emerald-500/10 text-emerald-600 px-2 py-0.5 rounded-full font-medium">
          إرسال تلقائي وفوري
        </span>
      </div>

      <div className="space-y-2.5">
        {/* Notification 1 */}
        <div className="p-3 rounded-lg border border-border/60 bg-muted/20 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <span className="h-2 w-2 rounded-full bg-emerald-500 mt-1.5 shrink-0"></span>
            <div>
              <div className="font-bold text-foreground">إشعار الحضور — مسح الباركود</div>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                سجل الطالب يوسف الأمين دخوله إلى القاعة 12 (حصة الرياضيات) بانتظام.
              </p>
            </div>
          </div>
          <span className="text-[10px] text-muted-foreground font-mono shrink-0">08:02</span>
        </div>

        {/* Notification 2 */}
        <div className="p-3 rounded-lg border border-border/60 bg-muted/20 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <span className="h-2 w-2 rounded-full bg-[#C88A2C] mt-1.5 shrink-0"></span>
            <div>
              <div className="font-bold text-foreground">رصد نتيجة اختبار تجريبي</div>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                حصلت الطالبة مريم بلعيد على علامة 18 / 20 في فرض مادة العلوم الطبيعية.
              </p>
            </div>
          </div>
          <span className="text-[10px] text-muted-foreground font-mono shrink-0">أمس</span>
        </div>

        {/* Notification 3 */}
        <div className="p-3 rounded-lg border border-border/60 bg-muted/20 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <span className="h-2 w-2 rounded-full bg-amber-500 mt-1.5 shrink-0"></span>
            <div>
              <div className="font-bold text-foreground">واجب منزلي جديد</div>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                نشر الأستاذ أحمد بن علي تمرين المراجعة الشاملة لمادة الرياضيات (الموعد: الأربعاء).
              </p>
            </div>
          </div>
          <span className="text-[10px] text-muted-foreground font-mono shrink-0">منذ يومين</span>
        </div>

        {/* Notification 4 */}
        <div className="p-3 rounded-lg border border-border/60 bg-muted/20 flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <span className="h-2 w-2 rounded-full bg-blue-500 mt-1.5 shrink-0"></span>
            <div>
              <div className="font-bold text-foreground">إعلان إداري من المركز</div>
              <p className="text-[11px] text-muted-foreground mt-0.5">
                فتح باب التسجيل في الحصص التدريبية المكثفة للعطلة المدرسية القادمة.
              </p>
            </div>
          </div>
          <span className="text-[10px] text-muted-foreground font-mono shrink-0">منذ 3 أيام</span>
        </div>
      </div>
    </div>
  );
}

export function MobileExperienceFrames() {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 max-w-4xl mx-auto text-right">
      
      {/* Mobile Screen 1: Student App */}
      <div className="rounded-3xl border-4 border-muted-foreground/20 bg-card p-3.5 shadow-xl text-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-border/50 text-[10px] text-muted-foreground">
          <span>09:41</span>
          <span className="h-1.5 w-10 bg-muted-foreground/30 rounded-full"></span>
          <span>4G 100%</span>
        </div>
        <div>
          <div className="text-[11px] text-[#002855] font-bold">تطبيق الطالب • روّاد</div>
          <h5 className="font-bold text-sm">مرحباً يوسف 👋</h5>
          <p className="text-[11px] text-muted-foreground">لديك حصتان اليوم وواجب واحد معلق</p>
        </div>
        <div className="p-3 rounded-xl bg-[#C88A2C]/10 border border-[#C88A2C]/20">
          <span className="text-[10px] text-[#001F3F] dark:text-[#C88A2C] font-bold">الحصة الحالية</span>
          <div className="font-bold text-xs mt-0.5">الرياضيات — قاعة 12</div>
          <span className="text-[10px] text-muted-foreground">14:00 - 16:00</span>
        </div>
        <div className="p-2.5 rounded-lg border border-border/60 text-[11px] flex justify-between">
          <span>المعدل التراكمي</span>
          <span className="font-mono font-bold text-emerald-600">16.85</span>
        </div>
      </div>

      {/* Mobile Screen 2: Parent App */}
      <div className="rounded-3xl border-4 border-muted-foreground/20 bg-card p-3.5 shadow-xl text-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-border/50 text-[10px] text-muted-foreground">
          <span>09:41</span>
          <span className="h-1.5 w-10 bg-muted-foreground/30 rounded-full"></span>
          <span>4G 100%</span>
        </div>
        <div>
          <div className="text-[11px] text-violet-600 font-bold">فضاء ولي الأمر</div>
          <h5 className="font-bold text-sm">متابعة الأبناء</h5>
          <p className="text-[11px] text-muted-foreground">إشعار حضور لحظي</p>
        </div>
        <div className="p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-[11px]">
          <span className="text-emerald-700 dark:text-emerald-300 font-bold block">✓ تم تسجيل الحضور</span>
          <span className="text-muted-foreground mt-0.5 block">وصل ابنك يوسف إلى المركز بسلام</span>
          <span className="text-[10px] text-muted-foreground font-mono block mt-1">الساعة 13:50</span>
        </div>
        <div className="p-2.5 rounded-lg border border-border/60 text-[11px] flex justify-between">
          <span>النتائج الأخيرة</span>
          <span className="font-mono font-bold text-[#002855]">18 / 20</span>
        </div>
      </div>

      {/* Mobile Screen 3: Teacher App */}
      <div className="rounded-3xl border-4 border-muted-foreground/20 bg-card p-3.5 shadow-xl text-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-border/50 text-[10px] text-muted-foreground">
          <span>09:41</span>
          <span className="h-1.5 w-10 bg-muted-foreground/30 rounded-full"></span>
          <span>4G 100%</span>
        </div>
        <div>
          <div className="text-[11px] text-emerald-600 font-bold">لوحة الأستاذ السريعة</div>
          <h5 className="font-bold text-sm">فوج 3 ثانوي رياضيات</h5>
          <p className="text-[11px] text-muted-foreground">24 طالباً مسجلاً</p>
        </div>
        <div className="p-3 rounded-xl bg-muted/40 border border-border/60 text-center">
          <div className="text-xs font-bold mb-1">مسح باركود الحضور</div>
          <span className="text-[10px] bg-[#002855] text-white px-2 py-1 rounded inline-block">
            فتح الكاميرا للمسح
          </span>
        </div>
        <div className="p-2.5 rounded-lg border border-border/60 text-[11px] flex justify-between">
          <span>الحاضرون الآن</span>
          <span className="font-mono font-bold text-emerald-600">23 / 24</span>
        </div>
      </div>

    </div>
  );
}

