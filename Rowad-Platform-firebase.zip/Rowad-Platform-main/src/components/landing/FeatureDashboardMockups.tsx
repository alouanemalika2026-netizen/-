import {
  Users,
  GraduationCap,
  School,
  ClipboardCheck,
  TrendingUp,
  Award,
  BookOpen,
  Calendar,
  CheckCircle,
  FileCheck,
  Clock,
  MessageCircle,
  BarChart2,
  ChevronLeft,
  UploadCloud,
  FileText,
  BadgeCheck,
  Heart,
  Eye,
} from "lucide-react";

// 1. Admin Center Dashboard Mockup
export function AdminDashboardMockup() {
  return (
    <div className="rounded-xl border border-border/70 bg-card shadow-lg p-4 text-xs">
      <div className="flex items-center justify-between pb-3 border-b border-border/50">
        <div className="flex items-center gap-2">
          <span className="h-2.5 w-2.5 rounded-full bg-[#002855]"></span>
          <span className="font-bold text-sm">إدارة مركز المستقبل التعليمي</span>
        </div>
        <span className="text-[11px] bg-[#F4F6F9] dark:bg-[#001428]/40 text-[#001F3F] dark:text-[#C88A2C] px-2 py-0.5 rounded font-medium border border-[#002855]/20/50">
          لوحة الإدارة
        </span>
      </div>

      <div className="grid grid-cols-3 gap-2.5 my-3.5">
        <div className="p-2.5 rounded-lg bg-muted/40 border border-border/60">
          <span className="text-[10px] text-muted-foreground block">الطلاب المسجلون</span>
          <span className="text-base font-bold font-mono text-[#002855]">540</span>
          <span className="text-[10px] text-emerald-600 block mt-0.5">↑ 14 طالب جديد هذا الأسبوع</span>
        </div>
        <div className="p-2.5 rounded-lg bg-muted/40 border border-border/60">
          <span className="text-[10px] text-muted-foreground block">هيئة التدريس</span>
          <span className="text-base font-bold font-mono">48 أستاذ</span>
          <span className="text-[10px] text-muted-foreground block mt-0.5">موزعون على 12 مادة</span>
        </div>
        <div className="p-2.5 rounded-lg bg-muted/40 border border-border/60">
          <span className="text-[10px] text-muted-foreground block">نسبة الحضور اليومي</span>
          <span className="text-base font-bold font-mono text-emerald-600">97.2%</span>
          <span className="text-[10px] text-muted-foreground block mt-0.5">مؤشر عالي الانضباط</span>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between text-[11px] font-semibold text-muted-foreground px-1">
          <span>النشاط الإداري الأخير</span>
          <span>الحالة</span>
        </div>

        <div className="flex items-center justify-between p-2 rounded-lg bg-muted/20 border border-border/40">
          <div className="flex items-center gap-2">
            <GraduationCap className="h-3.5 w-3.5 text-[#002855]" />
            <span>تأكيد تسجيل الفوج 04 للبكالوريا (شعبة علوم تجريبية)</span>
          </div>
          <span className="text-[10px] text-emerald-600 font-medium">مكتمل</span>
        </div>

        <div className="flex items-center justify-between p-2 rounded-lg bg-muted/20 border border-border/40">
          <div className="flex items-center gap-2">
            <School className="h-3.5 w-3.5 text-blue-600" />
            <span>تحديث جدول القاعات لليوم الدراسي القادم</span>
          </div>
          <span className="text-[10px] text-[#002855] font-medium">تم النشر</span>
        </div>

        <div className="flex items-center justify-between p-2 rounded-lg bg-muted/20 border border-border/40">
          <div className="flex items-center gap-2">
            <ClipboardCheck className="h-3.5 w-3.5 text-amber-600" />
            <span>إصدار بطاقات التقييم الشهري للفترة الأولى</span>
          </div>
          <span className="text-[10px] text-muted-foreground">قيد الإرسال</span>
        </div>
      </div>
    </div>
  );
}

// 2. Teacher Dashboard Mockup
export function TeacherDashboardMockup() {
  return (
    <div className="rounded-xl border border-border/70 bg-card shadow-lg p-4 text-xs">
      <div className="flex items-center justify-between pb-3 border-b border-border/50">
        <div className="flex items-center gap-2">
          <div className="h-6 w-6 rounded-full bg-violet-100 dark:bg-violet-900/50 text-violet-700 dark:text-violet-300 font-bold grid place-items-center text-[10px]">
            ع.ب
          </div>
          <div>
            <span className="font-bold text-sm block leading-none">أ. أحمد بن علي</span>
            <span className="text-[10px] text-muted-foreground">أستاذ مادة الرياضيات — أقسام النهائي</span>
          </div>
        </div>
        <span className="text-[11px] bg-violet-50 dark:bg-violet-950/40 text-violet-700 dark:text-violet-300 px-2 py-0.5 rounded font-medium border border-violet-200/50">
          لوحة الأستاذ
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3 my-3.5">
        <div className="p-3 rounded-lg border border-violet-500/20 bg-violet-500/5">
          <div className="flex justify-between items-center text-[11px] mb-1">
            <span className="font-semibold text-foreground">الحصة القادمة:</span>
            <span className="text-[10px] bg-violet-600 text-white px-1.5 py-0.2 rounded font-mono">16:00</span>
          </div>
          <p className="font-bold text-sm text-foreground">المتتاليات العددية والبرهان بالتراجع</p>
          <p className="text-[11px] text-muted-foreground mt-0.5">فوج 3 ثانوي رياضيات • 24 طالباً</p>
        </div>

        <div className="p-3 rounded-lg border border-border/60 bg-muted/20">
          <div className="flex justify-between items-center text-[11px] mb-1">
            <span className="font-semibold text-foreground">الواجبات المسلمة:</span>
            <span className="text-emerald-600 font-mono font-bold">22 / 24</span>
          </div>
          <p className="font-bold text-sm text-foreground">تطبيقات الدوال اللوغاريتمية</p>
          <p className="text-[11px] text-muted-foreground mt-0.5">تم تصحيح 18 واجباً حتى الآن</p>
        </div>
      </div>

      <div className="space-y-2">
        <div className="text-[11px] font-semibold text-muted-foreground">إجراءات سريعة للأستاذ:</div>
        <div className="grid grid-cols-3 gap-2 text-center text-[11px]">
          <div className="p-2 rounded-lg border border-border/60 bg-muted/30 font-medium text-foreground hover:bg-muted/50 cursor-default">
            تسجيل الحضور بالباركود
          </div>
          <div className="p-2 rounded-lg border border-border/60 bg-muted/30 font-medium text-foreground hover:bg-muted/50 cursor-default">
            رفع تمرين أو واجب جديد
          </div>
          <div className="p-2 rounded-lg border border-border/60 bg-muted/30 font-medium text-foreground hover:bg-muted/50 cursor-default">
            رصد درجات الفرض الفصلي
          </div>
        </div>
      </div>
    </div>
  );
}

// 3. Student Dashboard Mockup
export function StudentDashboardMockup() {
  return (
    <div className="rounded-xl border border-border/70 bg-card shadow-lg p-4 text-xs">
      <div className="flex items-center justify-between pb-3 border-b border-border/50">
        <div className="flex items-center gap-2">
          <div className="h-6 w-6 rounded-full bg-emerald-100 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 font-bold grid place-items-center text-[10px]">
            ي.أ
          </div>
          <div>
            <span className="font-bold text-sm block leading-none">يوسف الأمين</span>
            <span className="text-[10px] text-muted-foreground">3 ثانوي علوم تجريبية • فوج المتفوقين</span>
          </div>
        </div>
        <span className="text-[11px] bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 px-2 py-0.5 rounded font-medium border border-emerald-200/50">
          فضاء الطالب
        </span>
      </div>

      <div className="grid grid-cols-3 gap-2.5 my-3.5 text-center">
        <div className="p-2.5 rounded-lg bg-emerald-500/5 border border-emerald-500/20">
          <span className="text-[10px] text-muted-foreground block">معدلي الفصلي</span>
          <span className="text-base font-bold font-mono text-emerald-600">16.85</span>
          <span className="text-[10px] text-emerald-600 block mt-0.5">المرتبة 3 على الفوج</span>
        </div>
        <div className="p-2.5 rounded-lg bg-muted/30 border border-border/60">
          <span className="text-[10px] text-muted-foreground block">الحضور والانضباط</span>
          <span className="text-base font-bold font-mono">98%</span>
          <span className="text-[10px] text-muted-foreground block mt-0.5">غياب واحد بعذر</span>
        </div>
        <div className="p-2.5 rounded-lg bg-muted/30 border border-border/60">
          <span className="text-[10px] text-muted-foreground block">الواجبات المنجزة</span>
          <span className="text-base font-bold font-mono text-[#002855]">14 / 15</span>
          <span className="text-[10px] text-muted-foreground block mt-0.5">واجب واحد متبقٍ</span>
        </div>
      </div>

      <div className="space-y-2">
        <div className="text-[11px] font-semibold text-muted-foreground">جدول مواعيدي اليوم:</div>
        
        <div className="flex items-center justify-between p-2 rounded-lg bg-muted/20 border border-border/40">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
            <span className="font-semibold">تمرين الفيزياء: الكهرباء والدارات RL</span>
          </div>
          <span className="text-[10px] font-mono text-muted-foreground">اليوم قبل 20:00</span>
        </div>

        <div className="flex items-center justify-between p-2 rounded-lg bg-muted/20 border border-border/40">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 rounded-full bg-[#C88A2C]"></span>
            <span className="font-semibold">امتحان تجريبي: اللغة العربية وآدابها</span>
          </div>
          <span className="text-[10px] text-[#002855] font-medium">الثلاثاء القادم</span>
        </div>
      </div>
    </div>
  );
}

// 4. Parent Dashboard Mockup
export function ParentDashboardMockup() {
  return (
    <div className="rounded-xl border border-border/70 bg-card shadow-lg p-4 text-xs">
      <div className="flex items-center justify-between pb-3 border-b border-border/50">
        <div className="flex items-center gap-2">
          <Heart className="h-4 w-4 text-[#002855]" />
          <div>
            <span className="font-bold text-sm block leading-none">متابعة الأبناء — فضاء ولي الأمر</span>
            <span className="text-[10px] text-muted-foreground">ولي أمر الطالب: يوسف الأمين ومريم الأمين</span>
          </div>
        </div>
        <span className="text-[11px] bg-[#F4F6F9] dark:bg-[#001428]/40 text-[#001F3F] dark:text-[#C88A2C] px-2 py-0.5 rounded font-medium border border-[#002855]/20/50">
          تطبيق ولي الأمر
        </span>
      </div>

      <div className="space-y-2.5 my-3.5">
        {/* Child 1 */}
        <div className="p-3 rounded-lg border border-border/60 bg-muted/20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-full bg-[#002855]/10 text-[#001F3F] font-bold grid place-items-center text-xs">
              يوسف
            </div>
            <div>
              <div className="font-bold text-sm">يوسف • 3 ثانوي</div>
              <div className="text-[11px] text-muted-foreground">حاضر في حصة الرياضيات • القاعة 12</div>
            </div>
          </div>
          <div className="text-left font-mono">
            <span className="text-sm font-bold text-emerald-600">16.85</span>
            <span className="text-[10px] text-muted-foreground block">المعدل الفصلي</span>
          </div>
        </div>

        {/* Child 2 */}
        <div className="p-3 rounded-lg border border-border/60 bg-muted/20 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="h-8 w-8 rounded-full bg-violet-100 text-violet-700 font-bold grid place-items-center text-xs">
              مريم
            </div>
            <div>
              <div className="font-bold text-sm">مريم • 4 متوسط</div>
              <div className="text-[11px] text-muted-foreground">تم تسليم واجب العلوم الطبيعية بنجاح</div>
            </div>
          </div>
          <div className="text-left font-mono">
            <span className="text-sm font-bold text-[#002855]">17.20</span>
            <span className="text-[10px] text-muted-foreground block">المعدل الفصلي</span>
          </div>
        </div>
      </div>

      <div className="p-2.5 rounded-lg bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-between text-[11px]">
        <span className="text-emerald-700 dark:text-emerald-300 font-medium">
          ✓ إشعار فوري: وصل ابنك يوسف إلى المركز الساعة 13:50 (تسجيل الحضور الإلكتروني)
        </span>
        <span className="text-muted-foreground font-mono text-[10px]">13:51</span>
      </div>
    </div>
  );
}

