import { useState, useRef, useEffect } from "react";
import logoAsset from "@/assets/rowad-logo.asset.json";
import { cn } from "@/lib/utils";
import {
  Users,
  GraduationCap,
  CalendarDays,
  ClipboardCheck,
  TrendingUp,
  Bell,
  CheckCircle2,
  Clock,
  ChevronLeft,
  Search,
  LayoutDashboard,
  BookOpen,
  FileText,
  Building2,
  Award,
} from "lucide-react";

export function HeroProductPreview() {
  const [inView, setInView] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setInView(true);
        }
      },
      { threshold: 0.15 }
    );

    if (containerRef.current) {
      observer.observe(containerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={containerRef}
      className={cn(
        "w-full max-w-6xl mx-auto mt-12 md:mt-16 transition-all duration-700 ease-out",
        inView
          ? "opacity-100 scale-100 translate-y-0"
          : "opacity-100 scale-[0.98] translate-y-4"
      )}
    >
      {/* Browser / App Window Container - Pure Real Colors, Zero Boring Shadows, Crisp Pure Border */}
      <div className="relative rounded-2xl border-2 border-slate-200 dark:border-white/15 bg-white dark:bg-[#001F3F] overflow-hidden">
        
        {/* Top Window Bar */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-slate-200/80 dark:border-white/10 bg-slate-50 dark:bg-[#001428] text-xs">
          <div className="flex items-center gap-2">
            <span className="h-3 w-3 rounded-full bg-rose-500 inline-block"></span>
            <span className="h-3 w-3 rounded-full bg-amber-400 inline-block"></span>
            <span className="h-3 w-3 rounded-full bg-emerald-500 inline-block"></span>
            <span className="mr-3 text-slate-500 dark:text-slate-400 font-mono text-[11px] hidden sm:inline-block">
              app.rowad.edu.dz / لوحة الإدارة العامة
            </span>
          </div>

          <div className="flex items-center gap-3">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold bg-[#C88A2C]/10 text-[#C88A2C] border border-[#C88A2C]/30">
              <span className="h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
              النظام متصل ومباشر
            </span>
            <span className="text-slate-500 dark:text-slate-400 text-[11px] font-medium hidden md:inline">
              مركز النور التعليمي
            </span>
          </div>
        </div>

        {/* Real Product UI Mockup */}
        <div className="grid grid-cols-1 lg:grid-cols-12 min-h-[580px] bg-white dark:bg-[#001428] text-foreground text-right">
          
          {/* Mock Sidebar */}
          <aside className="hidden lg:flex lg:col-span-3 border-l border-slate-200/80 dark:border-white/10 bg-slate-50/50 dark:bg-[#001933] flex-col justify-between p-4">
            <div>
              {/* Logo & Brand in Sidebar */}
              <div className="flex flex-col items-center justify-center text-center px-3 py-3 mb-5 rounded-xl bg-white dark:bg-[#001F3F] border border-slate-200 dark:border-white/10 gap-2">
                <img
                  src={logoAsset.logo.url}
                  alt="شعار روّاد"
                  className="h-14 w-auto object-contain"
                />
                <span className="text-base font-black text-[#002855] dark:text-white font-display">
                  منصة روّاد
                </span>
              </div>

              {/* Navigation Items */}
              <nav className="space-y-1 text-xs">
                <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-[#002855] text-white font-medium">
                  <span className="flex items-center gap-2.5">
                    <LayoutDashboard className="h-4 w-4 text-[#C88A2C]" />
                    لوحة التحكم
                  </span>
                  <span className="text-[10px] bg-white/20 text-white px-1.5 py-0.5 rounded">رئيسي</span>
                </div>

                <div className="flex items-center justify-between px-3 py-2 rounded-lg text-muted-foreground hover:bg-muted/50 transition-colors">
                  <span className="flex items-center gap-2.5">
                    <GraduationCap className="h-4 w-4" />
                    شؤون الطلاب
                  </span>
                  <span className="text-[11px] font-mono font-bold text-[#002855] dark:text-[#C88A2C]">540</span>
                </div>

                <div className="flex items-center justify-between px-3 py-2 rounded-lg text-muted-foreground hover:bg-muted/50 transition-colors">
                  <span className="flex items-center gap-2.5">
                    <Users className="h-4 w-4" />
                    الأساتذة والمشرفون
                  </span>
                  <span className="text-[11px] font-mono font-bold">48</span>
                </div>

                <div className="flex items-center justify-between px-3 py-2 rounded-lg text-muted-foreground hover:bg-muted/50 transition-colors">
                  <span className="flex items-center gap-2.5">
                    <CalendarDays className="h-4 w-4" />
                    الجداول والحصص
                  </span>
                  <span className="text-[10px] bg-emerald-500/10 text-emerald-600 px-1.5 py-0.5 rounded font-medium">12 اليوم</span>
                </div>

                <div className="flex items-center justify-between px-3 py-2 rounded-lg text-muted-foreground hover:bg-muted/50 transition-colors">
                  <span className="flex items-center gap-2.5">
                    <ClipboardCheck className="h-4 w-4" />
                    سجل الحضور الذكي
                  </span>
                  <span className="text-[11px] font-mono font-bold">96%</span>
                </div>

                <div className="flex items-center justify-between px-3 py-2 rounded-lg text-muted-foreground hover:bg-muted/50 transition-colors">
                  <span className="flex items-center gap-2.5">
                    <FileText className="h-4 w-4" />
                    الامتحانات والنتائج
                  </span>
                </div>

                <div className="flex items-center justify-between px-3 py-2 rounded-lg text-muted-foreground hover:bg-muted/50 transition-colors">
                  <span className="flex items-center gap-2.5">
                    <BookOpen className="h-4 w-4" />
                    المكتبة الرقمية
                  </span>
                </div>
              </nav>
            </div>

            {/* Sidebar Bottom Profile */}
            <div className="pt-4 border-t border-border/60">
              <div className="flex items-center justify-between px-2 py-1.5 rounded-lg bg-card border border-border/40 text-xs">
                <div className="flex items-center gap-2">
                  <div className="h-7 w-7 rounded-full bg-[#002855]/10 dark:bg-[#001428]/60 text-[#001F3F] dark:text-[#C88A2C] grid place-items-center font-bold text-xs">
                    د.م
                  </div>
                  <div className="flex flex-col">
                    <span className="font-semibold leading-tight text-[12px]">أ. مصطفى رحماني</span>
                    <span className="text-[10px] text-muted-foreground">مدير المركز</span>
                  </div>
                </div>
                <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
              </div>
            </div>
          </aside>

          {/* Main Dashboard Area */}
          <main className="col-span-1 lg:col-span-9 p-4 sm:p-6 flex flex-col justify-between space-y-5">
            
            {/* Top Bar inside App */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-border/50">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-lg font-bold">نظرة عامة على النشاط اليومي</h3>
                  <span className="text-xs text-muted-foreground bg-muted/60 px-2 py-0.5 rounded-md">
                    الأحد، 3 سبتمبر 2026
                  </span>
                </div>
                <p className="text-xs text-muted-foreground mt-0.5">
                  جميع العمليات تسير بانتظام • تم تسجيل 96.2% نسبة حضور
                </p>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative">
                  <span className="absolute inset-y-0 right-0 flex items-center pr-2.5 pointer-events-none text-muted-foreground">
                    <Search className="h-3.5 w-3.5" />
                  </span>
                  <input
                    type="text"
                    readOnly
                    value="بحث عن طالب أو فوج..."
                    className="h-8 pr-8 pl-3 text-xs rounded-lg border border-border/80 bg-card text-muted-foreground w-40 sm:w-48 cursor-default focus:outline-none"
                  />
                </div>
                <div className="relative p-2 rounded-lg border border-border/80 bg-card text-muted-foreground">
                  <Bell className="h-3.5 w-3.5" />
                  <span className="absolute top-1.5 right-1.5 h-2 w-2 rounded-full bg-amber-500"></span>
                </div>
              </div>
            </div>

            {/* Quick Stat Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="p-3.5 rounded-xl border border-border/70 bg-card/80">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>إجمالي الطلاب</span>
                  <GraduationCap className="h-3.5 w-3.5 text-[#002855]" />
                </div>
                <div className="mt-1.5 text-xl font-bold text-foreground font-mono">542</div>
                <div className="mt-1 flex items-center gap-1 text-[11px] text-emerald-600 font-medium">
                  <TrendingUp className="h-3 w-3" />
                  <span>+18% هذا الفصل</span>
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-border/70 bg-card/80">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>نسبة الحضور</span>
                  <ClipboardCheck className="h-3.5 w-3.5 text-emerald-600" />
                </div>
                <div className="mt-1.5 text-xl font-bold text-foreground font-mono">96.4%</div>
                <div className="mt-1 text-[11px] text-muted-foreground">
                  522 طالب حاضر اليوم
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-border/70 bg-card/80">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>الحصص المكتملة</span>
                  <CalendarDays className="h-3.5 w-3.5 text-violet-600" />
                </div>
                <div className="mt-1.5 text-xl font-bold text-foreground font-mono">24 / 28</div>
                <div className="mt-1 text-[11px] text-violet-600 font-medium">
                  4 حصص جارية الآن
                </div>
              </div>

              <div className="p-3.5 rounded-xl border border-border/70 bg-card/80">
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>المعدل الفصلي</span>
                  <Award className="h-3.5 w-3.5 text-[#C88A2C]" />
                </div>
                <div className="mt-1.5 text-xl font-bold text-foreground font-mono">15.8 <span className="text-xs font-normal text-muted-foreground">/ 20</span></div>
                <div className="mt-1 text-[11px] text-emerald-600 font-medium">
                  مستوى متقدم
                </div>
              </div>
            </div>

            {/* Middle Section: Attendance Chart + Upcoming Classes */}
            <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
              
              {/* Attendance Bar Simulation */}
              <div className="md:col-span-7 p-4 rounded-xl border border-border/70 bg-card/70 flex flex-col justify-between">
                <div className="flex items-center justify-between mb-3">
                  <div>
                    <h4 className="text-xs font-bold">معدل الحضور والانضباط الأسبوعي</h4>
                    <p className="text-[11px] text-muted-foreground">مقارنة بين جميع الأفواج الدراسية</p>
                  </div>
                  <span className="text-[11px] text-[#001F3F] dark:text-[#C88A2C] font-medium bg-[#F4F6F9] dark:bg-[#001428]/40 px-2 py-0.5 rounded border border-[#002855]/20/50 dark:border-[#002855]/40">
                    الأسبوع الحالي
                  </span>
                </div>

                {/* Minimalist Visual Bars */}
                <div className="space-y-2.5 pt-2">
                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="font-medium">أفواج البكالوريا (3 ثانوي)</span>
                      <span className="font-mono text-[#002855] font-bold">98.5%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                      <div className="h-full rounded-full bg-[#002855]" style={{ width: "98.5%" }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="font-medium">أفواج 2 ثانوي (علمي ورياضي)</span>
                      <span className="font-mono text-violet-600 font-bold">94.2%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                      <div className="h-full rounded-full bg-violet-600" style={{ width: "94.2%" }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="font-medium">أفواج 4 متوسط (شهادة التعليم المتوسط)</span>
                      <span className="font-mono text-emerald-600 font-bold">96.0%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                      <div className="h-full rounded-full bg-emerald-500" style={{ width: "96.0%" }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-[11px] mb-1">
                      <span className="font-medium">أفواج اللغات والمواد الحرة</span>
                      <span className="font-mono text-amber-600 font-bold">91.8%</span>
                    </div>
                    <div className="h-2 w-full rounded-full bg-muted overflow-hidden">
                      <div className="h-full rounded-full bg-amber-500" style={{ width: "91.8%" }}></div>
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-border/50 flex items-center justify-between text-[11px] text-muted-foreground">
                  <span>تم التحديث تلقائياً عند مسح باركود الحضور</span>
                  <span className="text-[#002855] font-medium cursor-default">تقرير مفصل ←</span>
                </div>
              </div>

              {/* Upcoming Classes Feed */}
              <div className="md:col-span-5 p-4 rounded-xl border border-border/70 bg-card/70 flex flex-col justify-between">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="text-xs font-bold">حصص الفترة المسائية</h4>
                  <span className="text-[10px] text-muted-foreground font-mono">14:00 - 18:00</span>
                </div>

                <div className="space-y-2.5">
                  <div className="p-2.5 rounded-lg border border-[#C88A2C]/20 bg-[#C88A2C]/5 flex items-start justify-between gap-2">
                    <div>
                      <div className="text-xs font-bold text-foreground">رياضيات — الدوال الأصلية</div>
                      <div className="text-[11px] text-muted-foreground">أ. أحمد بن علي • قاعة 12</div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-[#002855] text-white font-medium shrink-0">
                      جارية الآن
                    </span>
                  </div>

                  <div className="p-2.5 rounded-lg border border-border/60 bg-muted/20 flex items-start justify-between gap-2">
                    <div>
                      <div className="text-xs font-bold text-foreground">فيزياء — الميكانيك النقطية</div>
                      <div className="text-[11px] text-muted-foreground">أ. سارة قاسمي • قاعة 07</div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground font-mono shrink-0">
                      15:30
                    </span>
                  </div>

                  <div className="p-2.5 rounded-lg border border-border/60 bg-muted/20 flex items-start justify-between gap-2">
                    <div>
                      <div className="text-xs font-bold text-foreground">لغة عربية — البلاغة والنقد</div>
                      <div className="text-[11px] text-muted-foreground">أ. خالد بوعزيز • قاعة 03</div>
                    </div>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-muted text-muted-foreground font-mono shrink-0">
                      17:00
                    </span>
                  </div>
                </div>

                <div className="mt-2 text-[11px] text-muted-foreground flex items-center gap-1.5">
                  <CheckCircle2 className="h-3 w-3 text-emerald-500" />
                  <span>تم إرسال تذكير الحصة لأولياء الأمور عبر الرسائل القصيرة</span>
                </div>
              </div>
            </div>

            {/* Bottom notification strip */}
            <div className="p-3 rounded-xl bg-[#001428]/5 dark:bg-[#001428]/30 border border-[#C88A2C]/20 flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2">
                <span className="h-2 w-2 rounded-full bg-[#002855]"></span>
                <span className="font-semibold text-[#001F3F] dark:text-[#002855]/20">
                  آخر نشاط مسجل:
                </span>
                <span className="text-muted-foreground">
                  تم رصد نتائج امتحان الفيزياء لفوج 3 ثانوي (متوسط الدرجات: 16.2 / 20)
                </span>
              </div>
              <span className="text-muted-foreground text-[11px] font-mono shrink-0">منذ 4 دقائق</span>
            </div>

          </main>
        </div>
      </div>
    </div>
  );
}

