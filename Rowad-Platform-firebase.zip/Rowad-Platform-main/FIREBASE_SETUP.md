# ربط منصة رواد بقاعدة بيانات Firebase

## 1) من لوحة Firebase (مرة واحدة)
1. **Authentication → Sign-in method** → فعّل **Email/Password**.
2. **Firestore Database → Create database** (اختر الموقع الأقرب، وضع Production).
3. **Project settings → Service accounts → Generate new private key** ثم احفظ الملف خارج المشروع (لا ترفعه إلى GitHub أبداً).

## 2) التثبيت والتشغيل
```bash
npm install
npm run dev
```
ملف `.env.local` موجود ويحتوي إعدادات مشروعك (`rowad-6a09d`).

## 3) نشر قواعد الأمان
```bash
npm i -g firebase-tools
firebase login
npm run deploy:rules
```
(بدون هذه الخطوة لن يستطيع أحد القراءة أو الكتابة.)

## 4) إنشاء المدير الأول
```bash
export GOOGLE_APPLICATION_CREDENTIALS=/المسار/serviceAccount.json
ADMIN_EMAIL=you@domain.com ADMIN_PASSWORD='كلمة-قوية' npm run seed
```
ثم ادخل من `/login` وأضف بقية المستخدمين من **المدير ← إدارة المستخدمين**.

للتجربة فقط (بيانات وهمية + 5 حسابات تجريبية):
```bash
npm run seed -- --demo
```
احذف الحسابات التجريبية قبل الإطلاق.

## 5) نشر الموقع (اختياري)
```bash
npm run build && firebase deploy --only hosting
```

## ما الذي أصبح حقيقياً؟
- تسجيل الدخول بـ Firebase Auth، والدور يُقرأ من `users/{uid}`، وحماية المسارات حسب الدور.
- جميع الجداول تقرأ لحظياً من Firestore، مع إضافة وتعديل وحذف وتصدير CSV حسب صلاحية الدور.
- المدير ينشئ حسابات المستخدمين من الواجهة.

## ما ينقص قبل الاستخدام الفعلي (مهم)
- **فصل بيانات المؤسسات (Multi-tenant):** حالياً كل المؤسسات ترى نفس البيانات. يلزم حقل `centerId` في كل سجل وقواعد تقيّد القراءة به.
- **ربط الطالب/ولي الأمر بسجلاته:** صفحات الطالب وولي الأمر تعرض الآن بيانات عامة (والنتائج تُفلتر بالاسم)؛ يلزم حقل `studentId`/`parentId`.
- رفع الملفات والفيديو (Firebase Storage)، والإشعارات الفعلية، وحذف حساب Auth نهائياً (يحتاج Cloud Function).
