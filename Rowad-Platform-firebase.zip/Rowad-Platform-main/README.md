<div align="center">

  <img src="public/rowad-logo.png" alt="Rowad Platform Logo" width="140" height="140" />

  # 🎓 Rowad Platform (منصة روّاد)
  ### *Accompanying Today's Students... Shaping Tomorrow's Leaders.*

  **A modern, all-in-one educational SaaS ecosystem bridging learning centers, teachers, students, and parents into a unified, high-performance digital workspace.**

  <p align="center">
    <a href="#-overview">🌟 Overview</a> •
    <a href="#-key-features">✨ Key Features</a> •
    <a href="#-user-roles--portals">👥 User Roles</a> •
    <a href="#-tech-stack">🛠️ Tech Stack</a> •
    <a href="#-getting-started">🚀 Getting Started</a> •
    <a href="#-project-architecture">📁 Architecture</a> •
    <a href="#-license">📄 License</a>
  </p>

  [![React](https://img.shields.io/badge/React-19-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)](https://react.dev/)
  [![TypeScript](https://img.shields.io/badge/TypeScript-5-007ACC?style=for-the-badge&logo=typescript&logoColor=white)](https://www.typescriptlang.org/)
  [![Tailwind CSS v4](https://img.shields.io/badge/Tailwind_CSS_v4-002855?style=for-the-badge&logo=tailwindcss&logoColor=38B2AC)](https://tailwindcss.com/)
  [![TanStack Router](https://img.shields.io/badge/TanStack_Router-1-FF4154?style=for-the-badge)](https://tanstack.com/router)
  [![Vite](https://img.shields.io/badge/Vite-6-646CFF?style=for-the-badge&logo=vite&logoColor=white)](https://vitejs.dev/)

</div>

---

## 🌟 Overview

**Rowad Platform** is a state-of-the-art educational management system designed to streamline administration, teaching, and parental supervision. By eliminating fragmented spreadsheets, paper attendance sheets, and chaotic group chats, **Rowad** centralizes all academic workflows into one cohesive cloud experience.

The platform seamlessly connects four vital educational pillars:
1. 🏢 **Learning Centers & Institutions**: Full-scale management of cohorts, classrooms, schedules, billing, and academic analytics.
2. 👨‍🏫 **Teachers & Professors**: Attendance tracking with QR/barcode support, automated grading, homework submissions, and lesson planning.
3. 🎓 **Students**: Personalized study timetables, interactive course modules, homework upload portals, and live grade reports.
4. 👨‍👩‍👧 **Parents**: Real-time attendance monitoring, academic performance indicators, and direct teacher communication.

---

## ✨ Key Features

### 🎨 Pure Brand Identity & Editorial Aesthetics
- 💎 **No Distracting Gradients**: Built exclusively on our official brand colors — Deep Navy (`#002855`) and Warm Gold (`#C88A2C`) — for a crisp, luxurious feel.
- 🔤 **Authentic Typography**: Native support for Arabic Right-to-Left (**RTL**) using premium *Thmanyah* typography.
- ☀️ **Clean Light Experience**: Crisp white sidebars and cards with subtle borders instead of dark, muddy shadows.

### ⚡ Smooth Scroll & Intelligent Micro-Animations
- 📜 **Continuous Parallax & Section Reveals**: Every section gracefully reveals itself with smooth fade-and-lift motion as you scroll into view.
- 🔢 **Live Fast-Counter Statistics**: Academic statistics smoothly ramp up from `+0` to target numbers with custom easing curves.
- 💻 **Live Product Preview Showcase**: An interactive mock dashboard that scales from 98% to 100% with real-time responsiveness.
- 🔀 **RTL-Aware Staggering**: Cards and feature items sequentially glide in from right to left, perfectly matching natural Arabic reading flow.

### 📊 Comprehensive Real-Time Analytics
- 📈 Integrated with **Recharts 3** for visual attendance rate curves, subject-by-subject distribution, and performance tracking.

### 📱 Responsive & Mobile-First
- 📱 Seamless adaptive layouts optimized across desktops, tablets, and smartphones.

---

## 👥 User Roles & Portals

| Portal | Route | Primary Responsibilities |
| :--- | :--- | :--- |
| 🏢 **Center Admin** | `/center` | Manage student & teacher rosters, classroom allocations, weekly timetables, and institution metrics. |
| 👨‍🏫 **Teacher Hub** | `/teacher` | Track daily attendance, create exams, upload lesson resources, and grade student submissions. |
| 🎓 **Student Portal** | `/student` | Check weekly timetables, download homework assignments, access video lectures, and review scores. |
| 👨‍👩‍👧 **Parent Dashboard**| `/parent` | Real-time presence notifications, behavioral reports, and transparent academic tracking for multiple children. |
| 🛡️ **Super Admin** | `/admin` | System-wide performance overview, subscription tiers, multi-branch management, and user auditing. |

---

## 🛠️ Tech Stack

- ⚛️ **Frontend Framework**: [React 19](https://react.dev/) + [TypeScript 5](https://www.typescriptlang.org/)
- ⚡ **Build Tool**: [Vite 6](https://vitejs.dev/)
- 🧭 **Routing Engine**: [TanStack Router](https://tanstack.com/router) with automatic file-based code generation
- 🎨 **Styling & Design System**: [Tailwind CSS v4](https://tailwindcss.com/)
- 🧩 **UI Component Primitives**: [Radix UI](https://www.radix-ui.com/) & [Lucide React Icons](https://lucide.dev/)
- 📈 **Data Visualization**: [Recharts 3](https://recharts.org/)
- 📋 **Form Management & Validation**: [React Hook Form](https://react-hook-form.com/) + [Zod 4](https://zod.dev/)

---

## 🚀 Getting Started

### 📋 Prerequisites
Make sure you have [Node.js](https://nodejs.org/) (version 18+ recommended) and `npm` installed.

### 💻 Installation & Setup

1. **Clone the repository**:
   ```bash
   git clone https://github.com/ikramikram2020/Rowad-Platform.git
   cd Rowad-Platform
   ```

2. **Install project dependencies**:
   ```bash
   npm install
   ```

3. **Start the local development server**:
   ```bash
   npm run dev
   ```
   Open your browser and navigate to: `http://localhost:5173/` 🚀

4. **Compile production build**:
   ```bash
   npm run build
   ```

---

## 📁 Project Architecture

```text
rawad-platform/
├── 📂 public/                 # Static assets, fonts, and brand assets
│   ├── 📂 fonts/              # Custom Thmanyah Arabic fonts (Sans & Serif)
│   └── 🖼️ rowad-logo.png      # Official platform logo
├── 📂 src/
│   ├── 📂 assets/             # Vector icons and asset descriptors
│   ├── 📂 components/         # Reusable UI component modules
│   │   ├── 📂 dashboard/      # Stat cards, charts, and table widgets
│   │   ├── 📂 landing/        # Hero previews, interactive showcase widgets
│   │   └── 📂 ui/             # Radix UI design primitives
│   ├── 📂 lib/                # Mock data fixtures and utility helpers
│   ├── 📂 routes/             # TanStack File-Based routing tree
│   │   ├── 📄 index.tsx       # Main interactive landing page
│   │   ├── 📄 login.tsx       # Unified authentication portal
│   │   ├── 📄 center.*        # Learning Center management views
│   │   ├── 📄 teacher.*       # Teacher workspace views
│   │   ├── 📄 student.*       # Student portal views
│   │   ├── 📄 parent.*        # Parent monitoring views
│   │   └── 📄 admin.*         # Platform administrator views
│   ├── 🎨 styles.css          # Design tokens, keyframe animations, & utilities
│   └── ⚡ main.tsx            # Application bootstrapping & router provider
├── 📄 index.html              # HTML5 entry document
├── 📦 package.json            # Project manifest & scripts
└── ⚙️ vite.config.ts          # Vite bundler & path alias configuration
```

---

## 📄 License

Developed with excellence as a premier academic capstone initiative and a national EdTech startup foundation.  
All Rights Reserved © 2026 **Rowad Platform**.
