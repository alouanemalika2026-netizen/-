/**
 * تهيئة قاعدة البيانات.
 *
 *   1) حمّل مفتاح حساب الخدمة: Firebase Console > Project settings > Service accounts > Generate new private key
 *   2) export GOOGLE_APPLICATION_CREDENTIALS=/المسار/إلى/serviceAccount.json
 *   3) أنشئ المدير الأول فقط:
 *        ADMIN_EMAIL=you@domain.com ADMIN_PASSWORD='كلمة-قوية' npm run seed
 *      أو أضف بيانات تجريبية + 5 حسابات تجريبية (للتطوير فقط):
 *        npm run seed -- --demo
 */
import { applicationDefault, initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";
import * as mock from "../src/lib/mock-data";

type Role = "admin" | "center" | "teacher" | "student" | "parent";

const PROJECT_ID = process.env.FIREBASE_PROJECT_ID ?? "rowad-6a09d";
initializeApp({ credential: applicationDefault(), projectId: PROJECT_ID });
const auth = getAuth();
const db = getFirestore();

const DEMO_USERS: { email: string; password: string; name: string; role: Role }[] = [
  { email: "superadmin@rowad.com", password: "admin123", name: "المدير العام", role: "admin" },
  { email: "center@rowad.com", password: "center123", name: "مؤسسة النور التعليمية", role: "center" },
  { email: "teacher@rowad.com", password: "teacher123", name: "أ. أحمد بن علي", role: "teacher" },
  { email: "student@rowad.com", password: "student123", name: "يوسف الأمين", role: "student" },
  { email: "parent@rowad.com", password: "parent123", name: "السيد كريم الأمين", role: "parent" },
];

const COLLECTIONS = [
  "monthlyStats", "subjectDistribution", "teachers", "students", "parents", "classes",
  "courses", "timetable", "attendance", "exams", "grades", "announcements", "news",
  "programs", "lessons", "videos", "documents", "notifications",
  "centers", "branches", "plans", "roles", "homework",
] as const;

async function ensureUser(u: { email: string; password: string; name: string; role: Role }) {
  let uid: string;
  try {
    uid = (await auth.getUserByEmail(u.email)).uid;
    console.log(`= موجود: ${u.email}`);
  } catch {
    uid = (await auth.createUser({ email: u.email, password: u.password, displayName: u.name })).uid;
    console.log(`+ حساب جديد: ${u.email}`);
  }
  await db.doc(`users/${uid}`).set(
    { name: u.name, email: u.email.toLowerCase(), role: u.role, status: "نشط" },
    { merge: true },
  );
}

async function seedCollection(name: (typeof COLLECTIONS)[number]) {
  let items = (mock as Record<string, unknown>)[name] as Record<string, unknown>[];
  const parentEmailOf = (parentName: unknown) =>
    mock.parents.find((p) => p.name === parentName)?.email.toLowerCase() ?? "";
  if (name === "students") {
    items = mock.students.map((s) => ({ ...s, parentEmail: parentEmailOf(s.parent) }));
  } else if (name === "teachers") {
    items = mock.teachers.map((t, i) => ({
      ...t,
      email: i === 0 ? "teacher@rowad.com" : `teacher${t.id}@rowad.com`,
    }));
  } else if (name === "parents") {
    items = mock.parents.map((p) => ({ ...p, email: p.email.toLowerCase() }));
  } else if (name === "attendance") {
    items = mock.attendance.map((a) => {
      const st = mock.students.find((s) => s.name === a.name);
      return { ...a, studentId: String(st?.id ?? ""), parentEmail: parentEmailOf(st?.parent) };
    });
  }
  const col = db.collection(name);
  for (let i = 0; i < items.length; i += 400) {
    const batch = db.batch();
    items.slice(i, i + 400).forEach((item, j) => {
      const { id, ...rest } = item;
      const docId = id !== undefined ? String(id) : String(i + j + 1);
      batch.set(col.doc(docId), { ...rest, order: i + j });
    });
    await batch.commit();
  }
  console.log(`+ ${name}: ${items.length} سجل`);
}

async function main() {
  const demo = process.argv.includes("--demo");
  if (demo) {
    for (const u of DEMO_USERS) await ensureUser(u);
    for (const c of COLLECTIONS) await seedCollection(c);
    console.warn("\n⚠️  الحسابات التجريبية كلمات مرورها معروفة. احذفها قبل الإطلاق الفعلي.");
  } else {
    const email = process.env.ADMIN_EMAIL;
    const password = process.env.ADMIN_PASSWORD;
    if (!email || !password) {
      console.error("حدد ADMIN_EMAIL و ADMIN_PASSWORD، أو استخدم --demo");
      process.exit(1);
    }
    await ensureUser({ email, password, name: "المدير العام", role: "admin" });
  }
  console.log("\nتم.");
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
